package TestGame;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Statistical;
import org.junit.Test;


public class TestGame {

	String a;
	@Before
	public void setUp() {
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		a = "m";
	}
	
	@Test
	public void test() {
		//int a = 1;
		//int b = 0;
		
		try
		{
			assertNotNull(1/0);
		}catch(Exception e)
		{
		    fail(e.getMessage(),true);
		}
		//	System.out.println("luego");
		
		
		assertEquals("xxxx", "xxxx");
		
		assertArrayEquals(new int[]{1,2,7},new int[]{1,2,7});
   		assertTrue(true);
		assertEquals(1,1);
		throw new IllegalArgumentException(
              "Comando incorrecto");
		//fail("DDD");
		
	}

	@Test
	public void delpruebas() {
		
		//assertEquals("xxxx", a);
		assertNotNull(null);
		assertEquals(0,3);
		//assertTrue(false);
		
		  
		  
		
	}
	
	@Test
	public void delpruebas3() {
		
		//assertEquals("xxxx", a);
		assertNotNull("hola");
		assertEquals(3,3);
		//assertTrue(false);
		
		  
		  
		
	}


	

}
