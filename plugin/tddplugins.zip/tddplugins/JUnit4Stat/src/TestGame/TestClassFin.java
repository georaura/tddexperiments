package TestGame;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

import org.junit.Statistical;
import org.junit.Test;

public class TestClassFin {

	@Test
	public void testFinalPrueba() {
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		//es.setNumberParameterizedTest(0);
		assertEquals("a", "a");
		assertThat(58, anyOf(equalTo(58), equalTo(67))); 
	}

}
