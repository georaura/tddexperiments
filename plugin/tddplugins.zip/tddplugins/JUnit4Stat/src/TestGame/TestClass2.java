package TestGame;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Ignore;
import org.junit.Statistical;
import org.junit.Test;

public class TestClass2 {

	@Test
	public void nuevas() {
		
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		//es.setNumberParameterizedTest(0);
		assertEquals("xxxx", "xxxxx");
		assertNotNull(null);
		assertEquals(1,3);
		assertTrue(false);
		
		
		
		  
		
	}
	
	@Ignore
	@Test
	public void Ignoradas() {
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		assertEquals("xxxx", "xxxxx");
		assertNotNull(null);
		assertEquals(1,3);
		assertTrue(false);
		
		
		
		  
		
	}
}
