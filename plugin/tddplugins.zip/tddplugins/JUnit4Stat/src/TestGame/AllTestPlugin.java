package TestGame;
import org.junit.Statistical;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class AllTestPlugin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		Result result = JUnitCore.runClasses(FibonacciTest.class,TestClass2.class,FibonacciTest2.class,TestClassFin.class);
		
	    for (Failure failure : result.getFailures()) {
		      System.out.println(failure.toString());
		    }

		

	}

}



