package TestGame;

import static org.junit.Assert.*;

import org.junit.Statistical;
import org.junit.Test;

public class TestRecursive {

	public TestRecursive(String result) {
    	
        this.result = result;
    }
	private String result;
	
	@Test
	public void test() {
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		Game g = new Game();
		System.out.println("Aqui");
		assertEquals(result,g.initGameRecursive(3));
		
	}

}
