package TestGame;

public class Game {
	
	public String  initGameRecursive(int i)
	{
		if(i == 0)
		{
			System.out.println("Fin");
		    return "Fin";
		}
		else
		{
			initGameRecursive(i-1);
			System.out.println(i-1);
		    return Integer.toString(i-1);
		}
	}

}
