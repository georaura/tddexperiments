package TestGame;

public class Fibonacci {
  public static int compute(int n)
  {
	/*if ((n == 0) || (n == 1))
		 return 1;
		 else
		 return compute(n-1) + compute(n-2);
		*/
	  return 1;
  }
}
