package TestGame;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Statistical;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized.Parameters;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)

public class FibonacciTest {
    @Parameters(name= "{index}: fib[{0}]={1}")
    public static Iterable<Object[]> data() {
        return Arrays.asList(new Object[][] { { 0, 1 }, { 1, 1 }, { 2, 1 },
                { 3, 2 }, { 4, 3 }, { 5, 5 }, { 6, 8 } });
    }

    private int fInput;

    private int fExpected;

    public FibonacciTest(int input, int expected) {
        fInput= input;
        fExpected= expected;
    }

    @Test
    public void testFibo() {
    	     
    	Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		//es.setNumberParameterizedTest(7);
    	//es.setTotalParameterizedTest(0);
   
        assertEquals(fExpected, Fibonacci.compute(fInput));
    }
}
