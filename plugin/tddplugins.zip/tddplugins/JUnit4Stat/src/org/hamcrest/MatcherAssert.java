/*  Copyright (c) 2000-2006 hamcrest.org
 */
package org.hamcrest;

import org.junit.Statistical;



public class MatcherAssert {
	private static Statistical statistical = Statistical.getInstance();
	private static String MethodName = null;
    public static <T> void assertThat(T actual, Matcher<? super T> matcher) {
        assertThat("", actual, matcher);
    }
    
    public static <T> void assertThat(String reason, T actual, Matcher<? super T> matcher) {
    	MethodName = "assertThat(" + reason +"," + actual + ")";       
    	if (!matcher.matches(actual)) {
            Description description = new StringDescription();
            description.appendText(reason)
                       .appendText("\nExpected: ")
                       .appendDescriptionOf(matcher)
                       .appendText("\n     but: ");
            matcher.describeMismatch(actual, description);
            if(statistical.getSendStatics())
            {
            	
                statistical.addTestDetail(MethodName,true, description.toString());
            }
        	else
        	{
        		throw new AssertionError(description.toString());
        	}
            
        }
    	else
    	{
    		 if(statistical.getSendStatics())
             {
             	
                 statistical.addTestDetail(MethodName,false, null);
             }
    	}
    }
    
    public static void assertThat(String reason, boolean assertion) {
        if (!assertion) {
            throw new AssertionError(reason);
        }
    }
}
