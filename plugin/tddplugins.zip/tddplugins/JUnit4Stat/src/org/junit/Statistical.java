package org.junit;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
//import java.sql.ResultSet;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import com.mysql.jdbc.PreparedStatement;

//import BDD.ConeccionBDD;

public class Statistical {
	private static Statistical instance;
	// This list allows for a pretty printing
	private List <TestClass> testClass;
	private List <TestCaseDescription> testCases;
	private List <TestCaseDetail> testDetails;
	private List<Messages>testMessages;
	private int testNumber=0;
	private int testDetailNum = 0;
	private int numberFailures = 0;
	private int numberSuccesses = 0;
	private int numberErrors = 0;
	private int numberAssertions = 0;
	private boolean isTus=false;
	private int totalTus = 0;
	private double qlty=0.0;
	private double totalQlty=0.0;
	private int totalClass=0;
	private int totalSuccesses=0;
	private int totalAssertions=0;
	private int totalFailures=0;
	private int totalErrors=0;
	private int totalTestNumber=0;
	
	//private String methodName = "";
	private String currentTestClass = "";
	
	private static String txtmsg="";
	//BDD
	//private ConeccionBDD mConexion;
	//Send Statics
	private static boolean sendStatics = false;
	
	
	private File logFile;
  
	private Statistical(){
		setTestClass(new ArrayList<TestClass>());
		setTestCases(new ArrayList<TestCaseDescription>());
		setTestDetails(new ArrayList<TestCaseDetail>());
		setTestMessages(new ArrayList<Messages>());
 
	}
	public static Statistical getInstance(){
		if(instance==null)
		  instance = new Statistical();
		
		return instance;
	}
	
	
	public void initSendStatics()
	{
		sendStatics = true;
	}
	
	public boolean getSendStatics()
	{
		return sendStatics;
	}
	
	public void addTestCase(String methodName, String testClass)
	{
		//System.out.println("First " + testClass + " " + methodName);
	    testNumber++;
	    totalTestNumber++;
		//meaningfullName = testClass.split("@")[0];
		//this.methodName = methodName.replace("-[", "[");
		testClass= testClass.split("@")[0];
		
		if(currentTestClass.compareTo(testClass)!=0)
		{
			
			currentTestClass = testClass;
		    getTestClass().add (new TestClass(currentTestClass ,isTus,qlty));
			totalClass++;
	      
		}
		
		getTestCases().add (new TestCaseDescription(methodName.replace("-[", "["), currentTestClass, testNumber));
		
		//updateTestCases(testClass.split("@")[0]);
		//getTestCases().add (new TestCaseDescription(methodName, meaningfullName, testNumber,tus));
	//	System.out.println ( );
		//System.out.println( "Test case: " + testNumber + " methodName: " + methodName + " fullName: " + meaningfullName);
		
	}
	
	public void addTestDetail(String testName, boolean fail, String message)
	{
		
		
		numberAssertions ++;
		totalAssertions++;
		//setTestDetailNum(getTestDetailNum() + 1);
		setTestDetailNum(numberAssertions);
		
		if(testName.equals("E_<>r_#r_@o_<>r"))
		{
			testName ="Error";
			//System.out.println(testName);
			fail = true;
			numberErrors ++;
			totalErrors ++;
			
		}
		else
		{
			if(fail)
			{	
				
				numberFailures ++;
				totalFailures ++;
			}
			else
			{
			   numberSuccesses++;
			   totalSuccesses++;
				
			   isTus=true;
			   
		
			}
		}
		getTestDetails().add (new TestCaseDetail(getTestDetailNum(),testName,fail, message,testNumber));
		//System.out.println( "Assertion "+  testDetailNum +": " + testName + " Fail: " + fail + " Message: " + message);
	
		
	}
	
	public double redondear( double numero, int decimales ) {
		    return Math.round(numero*Math.pow(10,decimales))/Math.pow(10,decimales);
    }
	public void updateTestCases(int idx){
		qlty = (numberSuccesses*1.0/(numberFailures + numberSuccesses + numberErrors)*100);
		getTestClass().set(idx, new TestClass(currentTestClass ,isTus,qlty));
		
	}
	public  void sendMessage(int numMessage,String message )
	{
		getTestMessages().add(new Messages(numMessage, message));
		
	}
	private void printMessage()
	{
		int reg=0;
		String auxtxt1= "";
		String auxtxt2= "";
		String auxtxt3= "";
		for(int i=0;i<this.getTestMessages().size();i++)
		{
			reg=getTestMessages().get(i).getMessageNumber();
			TestCaseDetail caso=	new TestCaseDetail(getTestDetails().get(reg).getTestDetailNumber(), getTestDetails().get(reg).getTestDetailName(),
			getTestDetails().get(reg).isFail(), getTestMessages().get(i).getMessage(),getTestDetails().get(reg).getTestNumber());
			getTestDetails().remove(reg);			
			getTestDetails().add(getTestMessages().get(i).getMessageNumber(),caso );
		
		}
	/*	for(int i=0;i<this.getTestMessages().size();i++)
		{
			getTestDetails().remove(this.getTestMessages().get(i).getMessageNumber());
		}
		*/
		
		for(int k=0;k<this.getTestClass().size();k++)
		{
			updateTestCases(k);
			auxtxt3 = auxtxt3 + "Test Class: " +getTestClass().get(k).getClassName() 
					            +" Tackled: "+ getTestClass().get(k).getTackled()
			                    +" QLTYi: "+ getTestClass().get(k).getQlti()+"%\n";
			auxtxt3 = auxtxt3 + "--------------------------------------------------------\n";
			if(getTestClass().get(k).getTackled())
				totalTus++;
			totalQlty += getTestClass().get(k).getQlti();
			for(int i=0;i<this.getTestCases().size();i++)
			{
				//System.out.println ( );
				//System.out.println( "Test case: " + getTestCases().get(i).getNumberAssertions() + " methodName: " + getTestCases().get(i).getMethodName() + " fullName: " + getTestCases().get(i).getMeaningfullName());
				auxtxt1 = auxtxt1 + "Test case: " + getTestCases().get(i).getNumberAssertions() + 
						" methodName: " + getTestCases().get(i).getMethodName() + 
						" ClassName: " + getTestCases().get(i).getMeaningfullName() + "\n";
						
				//if (getTestCases().get(i).getIsTus() && totalTus>0)
				//{
				//	totalQlty = totalQlty + ((getTestCases().get(i).getTestQlty()*1.0/totalTus)*100) ;
				//}
				for(int j=0;j<this.getTestDetails().size();j++)
				{	
					
					if(getTestDetails().get(j).getTestNumber()==getTestCases().get(i).getNumberAssertions())
					{
						String ms = getTestDetails().get(j).getMessage();
						if (ms !=null)
							ms= ms.replaceAll("[\n\r]", "");
					  auxtxt2 = auxtxt2 + "Assertion: "+  getTestDetails().get(j).getTestDetailNumber() +" " + getTestDetails().get(j).getTestDetailName() + " Fail: " + getTestDetails().get(j).isFail() + " Message: " + ms  + "\n";
					}
				}
				auxtxt1 = auxtxt1 + auxtxt2;
				auxtxt2 = "";
			}
			
			auxtxt3 = auxtxt3 +auxtxt1;
			auxtxt1 ="";
			
		}
		txtmsg = txtmsg + auxtxt3 ;
		auxtxt3 ="";
	}
	public void printResume()
	{
		
		if(!sendStatics)
			return;
			
		//txtmsg="";
		String txtmsgend = "";
		printMessage();
		
		txtmsg = txtmsg + "\nSummary1 :" + numberFailures + ": assertions FAILED :" + Math.round((double)numberFailures/(numberFailures + numberSuccesses + numberErrors)*100) + ":%\n";
		txtmsg = txtmsg + "Summary2 :" + numberSuccesses + ": assertions SUCCEDED :" + Math.round((double)numberSuccesses/(numberFailures + numberSuccesses + numberErrors)*100) + ":%\n";
		txtmsg = txtmsg + "Summary3 :" + numberErrors + ": assertions ERRORS :" + Math.round((double)numberErrors/(numberFailures + numberSuccesses + numberErrors)*100) + ":%\n";
		txtmsg = txtmsg + "Summary4 :" + (numberFailures + numberSuccesses + numberErrors) + ": RUN IN TOTAL\n";
		txtmsg = txtmsg + "Summary5 :" +  testNumber +": TOTAL TEST CASES\n";
		txtmsg = txtmsg + "---------------------------------------------------------\n\n\n";
		txtmsgend = txtmsgend + "Final metrics\n";
		txtmsgend = txtmsgend + "---------------------------------------------------------\n";
		txtmsgend = txtmsgend + "\nSummary6 :" + totalFailures + ": assertions FAILED :" + Math.round((double)totalFailures/(totalFailures + totalSuccesses + totalErrors)*100) + ":%\n";
		txtmsgend = txtmsgend + "Summary7 :" + totalSuccesses + ": assertions SUCCEDED :" + Math.round((double)totalSuccesses/(totalFailures + totalSuccesses + totalErrors)*100) + ":%\n";
		txtmsgend = txtmsgend + "Summary8 :" + totalErrors + ": assertions ERRORS :" + Math.round((double)totalErrors/(totalFailures + totalSuccesses + totalErrors)*100) + ":%\n";
		txtmsgend = txtmsgend + "Summary9 :" + (totalFailures + totalSuccesses + totalErrors) + ": ASSERTIONS RUN IN TOTAL\n";
		txtmsgend = txtmsgend + "Summary10 :" +  totalTestNumber +": TOTAL TEST CASES RUN\n\n";
				
		txtmsgend = txtmsgend + "TUS: " +totalTus +"\n";
		if(totalClass>0)
		    txtmsgend = txtmsgend + "PERTUS: " + redondear((totalTus*1.0/totalClass)*100,2) + "%\n";
		else
			txtmsgend = txtmsgend + "PERTUS: 0.00%\n";	
		if(totalTus>0)
		    txtmsgend = txtmsgend + "QLTY: " + redondear(totalQlty*1.0/totalTus,2) + "%\n";
		else
			txtmsgend = txtmsgend + "QLTY: 0.00%\n";
		if(totalAssertions>0)
		    txtmsgend = txtmsgend + "PROD: " + redondear((totalSuccesses*1.0/totalAssertions)*100,2) + "%\n";
		else
			txtmsgend = txtmsgend + "PROD: 0.00%\n";  
		//txtmsg = txtmsg + "TUS :" + totalTus + "\n";
		//txtmsg = txtmsg + "QLTY :" + totalQlty + "\n";
		//txtmsg = txtmsg + "PROD :" + redondear(((double)numberSuccesses/(numberFailures + numberSuccesses + numberErrors))*100,2) + "\n\n";
		
		
		//System.out.println ( );
		//System.out.println ( "Summary --> " + numberFailures + " assertions failed " + Math.round((double)numberFailures/(numberFailures + numberSuccesses)*100) + "%");
		//System.out.println ( "            " + numberSuccesses + " assertions succeeded " + Math.round((double)numberSuccesses/(numberFailures + numberSuccesses)*100) + "%");
		//System.out.println ( "            " + (numberFailures + numberSuccesses) + " run in total");
		//System.out.println ( "---------------------------------------------------------");
		//System.out.println ( "Total Test Cases--> " + testNumber);
		//System.out.println ( );
		 
		this.sendToText(txtmsg+txtmsgend);
		//System.out.println(txtmsg+txtmsgend);
		initVars();
		//sendStatics = false;
		//this.sendToBDD();
	}
	
	private void initVars()
	{
		numberSuccesses=0;
		numberFailures=0;
		numberSuccesses=0;
		numberErrors = 0;
		numberAssertions =0;
		
		testNumber=0;
		isTus=false;
		this.getTestMessages().clear();
		this.getTestCases().clear();
		this.getTestDetails().clear();
		this.getTestClass().clear();
	}
	
	public List <TestClass> getTestClass() {
		return testClass;
	}
	private void setTestClass(List <TestClass> testClass) {
		this.testClass = testClass;
	}
	
	public List <TestCaseDescription> getTestCases() {
		return testCases;
	}
	private void setTestCases(List <TestCaseDescription> testCases) {
		this.testCases = testCases;
	}
	
	
	public List<Messages> getTestMessages() {
		return testMessages;
	}
	private void setTestMessages(List<Messages> testMessages) {
		this.testMessages = testMessages;
	}
	public int getTestDetailNum() {
		return testDetailNum;
	}
	private void setTestDetailNum(int testDetailNum) {
		this.testDetailNum = testDetailNum;
	}

	public List <TestCaseDetail> getTestDetails() {
		return testDetails;
	}
	private void setTestDetails(List <TestCaseDetail> testDetails) {
		this.testDetails = testDetails;
	}

	private class TestClass {
		public String className;
		public boolean tackled;
		public double qlti=0.0;
		public TestClass(String className, boolean tackled, double qlti ){
			this.className = className;
			this.tackled = tackled;
			this.qlti = qlti;
		}
		
		public String getClassName() {
			return className;
		}
		public boolean getTackled() {
			return tackled;
		}
		public double getQlti() {
			return redondear(qlti,2);
		}
	}
	private class TestCaseDescription {
		
		public String methodName;
		public String meaningfullName;
		public int numberAssertions;
		
		public TestCaseDescription(String methodName, String meaningfullName,
				int numberAssertions ) {
			this.methodName = methodName;
			this.meaningfullName = meaningfullName;
			this.numberAssertions = numberAssertions;
	
		}

		public int getNumberAssertions() {
			return numberAssertions;
		}

		public String getMethodName() {
			return methodName;
		}
		
		public String getMeaningfullName() {
			return meaningfullName;
		}
	}
	
	private class TestCaseDetail {
		private int testDetailNumber;
		private String testDetailName;
		private String message;
		private boolean fail;
		private int testNumber;
		
	    public TestCaseDetail(int testDetailNumber,String testDetailName, boolean fail, String message, int test)
	    {
	    	this.setTestDetailNumber(testDetailNumber);
	    	this.setTestDetailName(testDetailName);
	    	this.setFail(fail);
	    	this.setMessage(message);
	    	this.setTestNumber(test);
    	}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public int getTestDetailNumber() {
			return testDetailNumber;
		}

		public void setTestDetailNumber(int testDetailNumber) {
			this.testDetailNumber = testDetailNumber;
		}

		public String getTestDetailName() {
			return testDetailName;
		}

		public void setTestDetailName(String testDetailName) {
			this.testDetailName = testDetailName;
		}

		public boolean isFail() {
			return fail;
		}

		public void setFail(boolean fail) {
			this.fail = fail;
		}

		public int getTestNumber() {
			return testNumber;
		}

		public void setTestNumber(int testNumber) {
			this.testNumber = testNumber;
		}
	}
	
	private class Messages
	{
		private int messageNumber;
		private String message;
		public Messages(int messN,String mes)
		{
			messageNumber=messN;
			message=mes;
		}
		public int getMessageNumber() {
			return messageNumber;
		}
		public String getMessage() {
			return message;
		}
	
	}

	
	private void sendToText(String msg)
	{
		
		 BufferedWriter writer = null;
	        try {
	            //create a temporary file
	           // String timeLog = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	        	
	        	// new File("/CollectData").mkdirs();
                 logFile = new File("TddStatics.txt");
	            // This will output the full path where the file will be written to...
	           // System.out.println(logFile.getCanonicalPath());
	            writer = new BufferedWriter(new FileWriter(logFile));
	            writer.write(msg);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                // Close the writer regardless of what happens...
	                writer.close();
	            } catch (Exception e) {
	            }
	        }
	}
	

	
	//base de datos
	/*
	public void sendToBDD()
	{
		if (sendStatics)
		{
			mConexion=new ConeccionBDD();
			
	//		System.out.println("hola"+mostrar().get(0).getNumberAssertions());
			for(int i=0;i<this.getTestCases().size();i++)
			{
				insertTs(getTestCases().get(i));
				
			}
	
			for(int i=0;i<this.getTestDetails().size();i++)
			{
				insertAs(getTestDetails().get(i));			
				
			}
			mConexion.desconectar();
		}
	}
	*/
/*    
public void insertTs(TestCaseDescription objDesc) {
    
    String query = "";
    try {
        query = "insert into test (testNumber, methodName,meaningFullName)  values('"+objDesc.getNumberAssertions()+"','" + objDesc.getMethodName() + "','" + objDesc.getMeaningfullName()
                + "')";

        PreparedStatement pstm = (PreparedStatement) mConexion.getConnection().prepareStatement(query);
        pstm.execute();
        System.out.println("Datos Correctamente Ingresados");
        pstm.close();
    } catch (SQLException e) {
        System.out.println(e);
        System.out.println("Existi� un error intente nuevamente");
    }

}
*/
/*
public List<TestCaseDescription> mostrar() {
    List<TestCaseDescription>desc=new ArrayList<Statistical.TestCaseDescription>();
      
 try {
     
 String    query = "SELECT *  FROM TEST";

        PreparedStatement pstm = (PreparedStatement) mConexion.getConnection().prepareStatement(query);
         ResultSet rs=pstm.executeQuery();
         while(rs.next())
         {
             desc.add(new TestCaseDescription(rs.getString("MEANINGFULLNAME"),rs.getString("METHODNAME"),rs.getInt("Idtest")));
         }
   rs.close();
   pstm.close();
         
 } catch (SQLException ex) {
   
 }
 return desc;
}
	
	public void insertAs(TestCaseDetail objDesc) {
    
        String query = "";
        int i=mostrar().get(0).getNumberAssertions();
        try {
            query = "insert into assertions (idtest,testDetailNum, testName,message,fail,relationtest)  values('"+i+"','" + objDesc.getTestDetailNumber() + "','" + objDesc.getTestDetailName()
                    + "', '" + objDesc.message+"','" + Boolean.toString(objDesc.isFail())+"','"+ objDesc.getTestNumber()+"')";

            PreparedStatement pstm = (PreparedStatement) mConexion.getConnection().prepareStatement(query);
            pstm.execute();
            System.out.println("Datos Correctamente Ingresados");
            pstm.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Existi� un error intente nuevamente");
        }

    }
    */
}
