package org.junit.internal;

import org.junit.Assert;

public class ExactComparisonCriteria extends ComparisonCriteria {
    @Override
    protected boolean assertElementsEqual(Object expected, Object actual) {
       return Assert.assertEqualsInit(null,expected, actual);
    }
}
