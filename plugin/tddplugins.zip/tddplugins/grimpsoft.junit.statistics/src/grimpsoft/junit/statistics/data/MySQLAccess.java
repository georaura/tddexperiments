package grimpsoft.junit.statistics.data;


import grimpsoft.junit.statistics.utils.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;

public class MySQLAccess {
  private Connection connect = null;
  private Statement statement = null;
  private PreparedStatement preparedStatement = null;
  private ResultSet resultSet = null;

  private Boolean connectToDB() throws Exception
  {
	  try {
	      // this will load the MySQL driver, each DB has its own driver
	      Class.forName("com.mysql.jdbc.Driver").newInstance();
	      // setup the connection with the DB.
	     // connect = DriverManager
	     //     .getConnection("jdbc:mysql://localhost:3306/ovd?"
	     //         + "user=root&password='root'");
	      
	    //   String connectionUrl = "jdbc:mysql://localhost:3306/ovd?";
		//      String connectionUser = "root";
		//     String pwd = "";
	    
	      //  String connectionUrl = "jdbc:mysql://lab.grimpsoft.espe.edu.ec:3306/ovd?";
	      //String connectionUser = "root";
	      //String pwd = "espe.2014";
	   // String connectionUrl = "jdbc:mysql://360likes.com:3306/thrsiyq8_ovd?";
	   // String connectionUser = "thrsiyq8_graura";
	   // String pwd = "graura1970";
	   // String connectionUser = "thrsiyq8_espeupm";
	   // String pwd = "espeupm2014";
	      FileUtil fl = new FileUtil();
	      String xmlpath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+File.separator;
	    	  
	    		  //+"grimpsoft"+File.separator+ "junit" + File.separator + "statistic" + File.separator+"data" +File.separator;
	      
	      
	      String connectionUrl = FileUtil.loadXmlData("connectionUrl","DBConfig.xml",xmlpath);
	      String connectionUser = FileUtil.loadXmlData("connectionUser","DBConfig.xml",xmlpath);
	      String pwd = FileUtil.loadXmlData("pwd","DBConfig.xml", xmlpath);
	    
	      connect = DriverManager
	              .getConnection(connectionUrl,connectionUser,pwd);
	    } catch (Exception e) {
	    	
	    	throw e;
	    	
	    } 
        return true;
  }
  public String readDataBase(String query, String table) throws Exception {
    

      connectToDB();
      try {
      // statements allow to issue SQL queries to the database
      statement = connect.createStatement();
      // resultSet gets the result of the SQL query
      resultSet = statement
          .executeQuery(query);
      
        
      return writeResultSet(resultSet,table);
      
      // preparedStatements can use variables and are more efficient
      /*
      preparedStatement = connect
          .prepareStatement("insert into  FEEDBACK.COMMENTS values (default, ?, ?, ?, ? , ?, ?)");
      // "myuser, webpage, datum, summary, COMMENTS from FEEDBACK.COMMENTS");
      // parameters start with 1
      preparedStatement.setString(1, "Test");
      preparedStatement.setString(2, "TestEmail");
      preparedStatement.setString(3, "TestWebpage");
      preparedStatement.setDate(4, new java.sql.Date(2009, 12, 11));
      preparedStatement.setString(5, "TestSummary");
      preparedStatement.setString(6, "TestComment");
      preparedStatement.executeUpdate();

      preparedStatement = connect
          .prepareStatement("SELECT myuser, webpage, datum, summary, COMMENTS from FEEDBACK.COMMENTS");
      resultSet = preparedStatement.executeQuery();
      
      */
      //writeResultSet(resultSet, table);
      /*
      // remove again the insert comment
      preparedStatement = connect
      .prepareStatement("delete from FEEDBACK.COMMENTS where myuser= ? ; ");
      preparedStatement.setString(1, "Test");
      preparedStatement.executeUpdate();
      
      resultSet = statement
      .executeQuery("select * from FEEDBACK.COMMENTS");
      writeMetaData(resultSet);
      */
    } catch (Exception e) {
      throw e;
    } finally {
      close();
    }

  }
  
  public void writeZipToDataBase(String filePath, String user, String testid) throws Exception
  {
	  //String insql = "update ulteo_tests_rawdata (testrawdata) values (?)";
	  String query = "update ulteo_tests_rawdata set testrawdata = ? where testid = ? and user = ?";
	  connectToDB();
	  InputStream inputStream = null;
	  File file = null;
		try {
			file = new File(filePath);
			inputStream = new FileInputStream(file);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   
	  try {
	      
		  preparedStatement = connect.prepareStatement(query);
		  
		  
		  preparedStatement.setString(2, testid);
		  preparedStatement.setString(3, user);
		  preparedStatement.setBinaryStream(1, inputStream,(int)file.length());
		  int row = preparedStatement.executeUpdate();
		  
	      if (row > 0) {
	          System.out.println("A zipfile was inserted..");
	      }
		  
	  } catch (Exception e) {
		  
	      throw e;
	  } finally {
	      close();
	  } 
	 
  }
  
  public void startSessionToDataBase( String user, String testid) throws Exception
  {
	  java.util.Date dt = new java.util.Date();

	  //java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

	  //String currentTime = sdf.format(dt);
	  java.sql.Timestamp sqlDate = new java.sql.Timestamp(dt.getTime());
	  //Calendar calendar = Calendar.getInstance();
      //java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
	  
	  String query = "update ulteo_tests_rawdata set startdate = ? where testid = ? and user = ?";
	  connectToDB();
	  try {
	      
		  preparedStatement = connect.prepareStatement(query);
		  preparedStatement.setString(2, testid);
		  preparedStatement.setString(3, user);
		  preparedStatement.setTimestamp(1, sqlDate);
		  int row = preparedStatement.executeUpdate();
		  
	      if (row > 0) {
	          System.out.println("Start Session at: " + dt.getTime());
	      }
		  
	  } catch (Exception e) {
		  
	      throw e;
	  } finally {
	      close();
	  } 
  }
  
  public void endSessionToDataBase( String user, String testid, int ntus, float qlty, float prod, int ntest) throws Exception
  {
	  java.util.Date dt = new java.util.Date();

	  java.sql.Timestamp sqlDate = new java.sql.Timestamp(dt.getTime());
	  
	  String query = "update ulteo_tests_rawdata set enddate = ?, isfinished = 1,"
	  		+ " ntus = ?, qlty = ?, prod = ?, ntest = ? where testid = ? and user = ?";
	  connectToDB();
	  try {
	      
		  preparedStatement = connect.prepareStatement(query);
		  preparedStatement.setTimestamp(1, sqlDate);
		  preparedStatement.setInt(2, ntus);
		  preparedStatement.setFloat(3, qlty);
		  preparedStatement.setFloat(4, prod);
		  preparedStatement.setInt(5, ntest);
		  preparedStatement.setString(6, testid);
		  preparedStatement.setString(7, user);
		  
		  int row = preparedStatement.executeUpdate();
		  
	      if (row > 0) {
	          System.out.println("End Session at: " + dt.getTime());
	      }
		  
	  } catch (Exception e) {
		  
	      throw e;
	  } finally {
	      close();
	  } 
  }


  public void writeTxtResultsToDataBase(String filePath, String user, String testid) throws Exception
  {
	  //String insql = "update ulteo_tests_rawdata (testrawdata) values (?)";
	  String query = "update ulteo_tests_rawdata set teststatistics = ? where testid = ? and user = ?";
	  connectToDB();
	  InputStream inputStream = null;
	  File file = null;
		try {
			file = new File(filePath);
			inputStream = new FileInputStream(file);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   
	  try {
	      
		  preparedStatement = connect.prepareStatement(query);
		  
		  
		  preparedStatement.setString(2, testid);
		  preparedStatement.setString(3, user);
		  preparedStatement.setAsciiStream(1, inputStream,(int)file.length());
		  int row = preparedStatement.executeUpdate();
		  
	      if (row > 0) {
	          System.out.println("A textfile was inserted..");
	      }
		  
	  } catch (Exception e) {
		  
	      throw e;
	  } finally {
	      close();
	  } 
	 
  }

  private void writeMetaData(ResultSet resultSet) throws SQLException {
    // now get some metadata from the database
    System.out.println("The columns in the table are: ");
    System.out.println("Table: " + resultSet.getMetaData().getTableName(1));
    for  (int i = 1; i<= resultSet.getMetaData().getColumnCount(); i++){
      System.out.println("Column " +i  + " "+ resultSet.getMetaData().getColumnName(i));
    }
  }
  
  

  private String writeResultSet(ResultSet resultSet, String table) throws SQLException {
    // resultSet is initialised before the first data set
     String data = null; 
    
       while (resultSet.next()) {
    	 	
      // it is possible to get the columns via name
      // also possible to get the columns via the column number
      // which starts at 1
      // e.g., resultSet.getSTring(2);
      if(table=="user")
      {
    	  String sd = "null";
    	  String ed = "null";
    	
    	 Date sdate= resultSet.getDate("startdate");
    	 if (!resultSet.wasNull())
    		 sd = sdate.toString();
    	  Date edate= resultSet.getDate("enddate");
    	 if (!resultSet.wasNull())
    		 ed = edate.toString();
    	
    	 return resultSet.getString("login") + "," 
    		    + resultSet.getString("displayname") + ","
    		    + resultSet.getString("testid")+ ","
    		    + sd+ ","
    		    + ed;
      }
      
      if(table=="testsdef")
      {
         return resultSet.getString("testid") + "," 
    		    + resultSet.getString("testname") + ","
    		    + resultSet.getString("testpath") + ","
    		    + resultSet.getString("sourcename") + ","
                + resultSet.getString("sourcepath");
      }
      
      //Date date = resultSet.getDate("datum");
      //String comment = resultSet.getString("comments");
      
      //System.out.println("Date: " + date);
      //System.out.println("Comment: " + comment);
    }
    
    return data;
  }

  // you need to close all three to make sure
  private void close() {
	  try {
	      if (resultSet != null) {
	    	  resultSet.close();
	      }
	    } catch (Exception e) {
	    // don't throw now as it might leave following closables in undefined state
	    }
	  try {
	      if (statement != null) {
	    	  statement.close();
	      }
	    } catch (Exception e) {
	    // don't throw now as it might leave following closables in undefined state
	    }
	  try {
	      if (connect != null) {
	    	  connect.close();
	      }
	    } catch (Exception e) {
	    // don't throw now as it might leave following closables in undefined state
	    }
   
  }
  
} 