package grimpsoft.junit.statistics.utils;

import java.util.Date;

public class DateTimeUtils {
	private static DateTimeUtils instance;
	private static Date startDate;
	private static Date endDate;
	private static String msg;
	
	public static DateTimeUtils getInstance(){
		if(instance==null)
		{
		  instance = new DateTimeUtils();
		  startDate = new Date();  
		}
		
		return instance;
	}
	
	private DateTimeUtils(){
			
	}
	
	public String getMsg()
	{
		return msg;
	}
	
	public void setMsg(String msg)
	{
		this.msg = msg; 
	}
	public String getStartDate()
	{
		return startDate.toString();
	}
	public String getEndDate()
	{
		return endDate.toString();
	}


	//1 minute = 60 seconds
	//1 hour = 60 x 60 = 3600
	//1 day = 3600 x 24 = 86400
	public String getDifference(){
        
		endDate = new Date();
		//milliseconds
		long different = endDate.getTime() - startDate.getTime();
 
		System.out.println("startDate : " + startDate);
		System.out.println("endDate : "+ endDate);
		System.out.println("different : " + different);
 
		long secondsInMilli = 1000;
		long minutesInMilli = secondsInMilli * 60;
		long hoursInMilli = minutesInMilli * 60;
		long daysInMilli = hoursInMilli * 24;
 
		long elapsedDays = different / daysInMilli;
		different = different % daysInMilli;
 
		long elapsedHours = different / hoursInMilli;
		different = different % hoursInMilli;
 
		long elapsedMinutes = different / minutesInMilli;
		different = different % minutesInMilli;
 
		long elapsedSeconds = different / secondsInMilli;
 
		//System.out.printf(
		//    "%d days, %d hours, %d minutes, %d seconds%n", 
		//    elapsedDays,
		//    elapsedHours, elapsedMinutes, elapsedSeconds);
		return "(hh:mm:ss) " + elapsedHours + ":" +  elapsedMinutes + ":" + elapsedSeconds ;
 
	}
	
	 
}