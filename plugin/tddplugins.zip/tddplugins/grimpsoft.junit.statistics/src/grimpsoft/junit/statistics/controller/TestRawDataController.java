package grimpsoft.junit.statistics.controller;

import grimpsoft.junit.statistics.data.MySQLAccess;
import grimpsoft.junit.statistics.model.User;

public class TestRawDataController {
	
	public boolean writeZipToDB(String filePath)
	{
		//"insert into ulteo_tests_rawdata (testrawdata) values (default, ?, ?, ?, ? , ?, ?)";
		//String filePath = "D:/Photos/Tom.jpg";
		
	    MySQLAccess zipdata = new MySQLAccess();
	    User user = new User();
		UserController usrc = new UserController();
		user = usrc.loadUser();
	    try {
		 zipdata.writeZipToDataBase(filePath, user.getLogin(),user.getCurrentTest());
		 
	    } catch (Exception e) {
		// TODO Auto-generated catch block
		 e.printStackTrace();
	    }

	   return true;
	}
	
	public boolean writeResultToDB(String filePath)
	{
		
	    MySQLAccess zipdata = new MySQLAccess();
	    User user = new User();
		UserController usrc = new UserController();
		user = usrc.loadUser();
	    try {
		 zipdata.writeTxtResultsToDataBase(filePath, user.getLogin(),user.getCurrentTest());
		 
	    } catch (Exception e) {
		// TODO Auto-generated catch block
		 e.printStackTrace();
		 return false;
	    }

	   return true;
	}
	
	public boolean startSession()
	{
		MySQLAccess startS = new MySQLAccess();
	    User user = new User();
		UserController usrc = new UserController();
		user = usrc.loadUser();
		try {
    		startS.startSessionToDataBase(user.getLogin(),user.getCurrentTest());
		 } catch (Exception e) {
				// TODO Auto-generated catch block
				 e.printStackTrace();
				 return false;
	    }

		   return true;
	}
	
	public boolean endSession(int ntus, float qlty, float prod, int ntest)
	{
		MySQLAccess startS = new MySQLAccess();
	    User user = new User();
		UserController usrc = new UserController();
		user = usrc.loadUser();
		try {
    		startS.endSessionToDataBase(user.getLogin(),user.getCurrentTest(),ntus,qlty,prod,ntest);
		 } catch (Exception e) {
				// TODO Auto-generated catch block
				 e.printStackTrace();
				 return false;
	    }

		   return true;
	}
	
	
}
