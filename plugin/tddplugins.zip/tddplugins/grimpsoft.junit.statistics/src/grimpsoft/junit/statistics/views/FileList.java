package grimpsoft.junit.statistics.views;
import grimpsoft.junit.statistics.utils.FileUtil;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

import org.eclipse.swt.widgets.Display;

public class FileList {
	private static final int COLUMNS = 2;
    private static Dimension size;
    private static SelectionView svframe;
    private static JFrame frame;

    public static void FilesInTheJList() {
    	FileUtil finit = new FileUtil();
    	
    	File fc = new File(finit.getEclipseDir()+"testdata/");
        final JList list = new JList(fc.listFiles()) {

            private static final long serialVersionUID = 1L;

            @Override
            public Dimension getPreferredScrollableViewportSize() {
                if (size != null) {
                    return new Dimension(size);
                }
                return super.getPreferredScrollableViewportSize();
            }
        };
        list.setFixedCellHeight(20);
        list.setFixedCellWidth(130);
        size = list.getPreferredScrollableViewportSize();
        size.width *= COLUMNS;
        list.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        list.setCellRenderer(new MyCellRenderer());
        list.setVisibleRowCount(0);
        list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        
        JPanel panel = new JPanel();
		panel.add(new JScrollPane(list));
		
        JButton registerButton = new JButton("Select");
		registerButton.setBounds(100, 110, 110, 25);
		
		
		registerButton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		    	
	          // this.sendData();	   
			}

			private void sendData() {
				new Thread(new Runnable() {
				      public void run() {
				         while (true) {
				            try { Thread.sleep(1000); } catch (Exception e) { }
				            Display.getDefault().asyncExec(new Runnable() {
				               public void run() {
				   				svframe.addAllClases();
				               }
				            });
				         }
				      }
				   }).start();

				frame.dispose();
						
			}
		});
        
		panel.add(registerButton);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		
			
        frame = new JFrame("Files In the List");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
        frame.add(panel);
        frame.pack();
        frame.setSize(300,260 );   
        frame.setResizable(false);
        frame.setVisible(true);
    }

    public static void initFileList(SelectionView sv) {
    	
       	FileList fITJL = new FileList();
       	sv.addAllClases();
      // 	svframe = new SelectionView();
      // 	svframe = sv;
       	
    	FileList.FilesInTheJList();
    	
        
    }

    private static class MyCellRenderer extends JLabel implements ListCellRenderer {

        private static final long serialVersionUID = 1L;

      
        public Component getListCellRendererComponent(JList list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {
            if (value instanceof File) {
                File file = (File) value;
                setText(file.getName());
                setIcon(FileSystemView.getFileSystemView().getSystemIcon(file));
                if (isSelected) {
                    setBackground(list.getSelectionBackground());
                    setForeground(list.getSelectionForeground());
                } else {
                    setBackground(list.getBackground());
                    setForeground(list.getForeground());
                }
                setPreferredSize(new Dimension(250, 25));
                setEnabled(list.isEnabled());
                setFont(list.getFont());
                setOpaque(true);
            }
            return this;
        }
    }

}
