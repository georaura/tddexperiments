package grimpsoft.junit.statistics.controller;


import grimpsoft.junit.statistics.data.MySQLAccess;
import grimpsoft.junit.statistics.model.User;
import grimpsoft.junit.statistics.utils.UserLogged;

public class UserController {
	
	
	public User loadUser()
	{
	   MySQLAccess usrdata = new MySQLAccess();
	   UserLogged usrl = new UserLogged();
	   String userLogged = usrl.getUserLogged();
	   //Comment for Production
	   if (userLogged == null)
	       userLogged = "georaura";
	   
	   User usr = new User();
	   String[] usrd = null;
	   String usrdataaux = null;
	   String sql= "select login, displayname, testid, startdate, enddate from ulteo_user"
	   		+ " LEFT JOIN ulteo_tests_rawdata"
	   		+ " ON ulteo_tests_rawdata.user=ulteo_user.login"
	   		+ " where user = '" + userLogged +"' and secuence ="
	   		+ " (select min(secuence) from ulteo_tests_rawdata"
	   		+ " where user='" + userLogged +"' and isfinished=0)" ;
	   
	   try {
	
		usrdataaux = usrdata.readDataBase(sql, "user");
		if(usrdataaux != null)
		usrd=usrdataaux.split(",");
		else
			return null;
		
		
		if(usrd!=null)
		{	
			
			usr.setName(usrd[1]);
			usr.setLogin(usrd[0]);
			usr.setCurrentTest(usrd[2]);
			if(!usrd[3].equals("null") && usrd[4].equals("null"))
			  usr.setIsUserTestFinished(false);
			if(!usrd[3].equals("null") && !usrd[4].equals("null"))
			  usr.setIsUserTestFinished(true);
			if(usrd[3].equals("null") && usrd[4].equals("null"))
					
			  usr.setIsUserTestFinished(true);
			
			return usr;
		}
		return null;
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
	
	}
	
	
	
}
