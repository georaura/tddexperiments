package grimpsoft.junit.statistics.controller;

import grimpsoft.junit.statistics.utils.FileUtil;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

public class ClassController {

	private static List<Class<?>> classes;
	private String pathf ;
	private String javaClassNameWithoutExtension;
	
	public List<Class<?>> addClassToList()
	{
		
		//setContentDescription(javaClassNameWithoutExtension); 	
		String binpath = null;
   	    binpath = pathf.split("src")[0] + "bin/"; 
   	
		File f = new File(binpath);
   	    Class clazz = null;
   	    
		if (classes == null)
			classes=new ArrayList<Class<?>>();
		try
		{
		URL[] cp = {f.toURI().toURL()};
		URLClassLoader urlcl = new URLClassLoader(cp,Thread.currentThread().getContextClassLoader());
		
		clazz = clazz.forName(javaClassNameWithoutExtension,true,urlcl);
		
		 classes.add(clazz);	
		// showItems(classes.toArray(),"n");
		return classes;
		     
	   } catch (ClassNotFoundException e) {
		   // TODO Auto-generated catch block
		  // setContentDescription("Class Not Found " + e.getMessage());
		   e.printStackTrace();
		   return null;
	   } catch (MalformedURLException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
		  return null;
	   }

	}
	
	public List<Class<?>> addAllClassToList()
	{
		FileUtil fu = 	new FileUtil();
		if (classes == null)
			classes=new ArrayList<Class<?>>();
		classes=fu.getAllClasses();
		return classes;
		//showItems(classes.toArray(),"n");
		
	}


}
