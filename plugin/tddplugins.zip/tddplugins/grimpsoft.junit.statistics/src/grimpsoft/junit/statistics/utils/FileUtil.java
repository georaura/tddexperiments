package grimpsoft.junit.statistics.utils;

import grimpsoft.junit.statistics.controller.TestDefController;
import grimpsoft.junit.statistics.model.TestDef;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;



import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;


public class FileUtil {
	
	public String getWorkSpace()
	{
		
		//get object which represents the workspace  
		IWorkspace workspace = ResourcesPlugin.getWorkspace();  
		  
		//get location of workspace (java.io.File)  
		File workspaceDirectory = workspace.getRoot().getLocation().toFile();
		try {
			
			return workspaceDirectory.getCanonicalPath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public String getEclipseDir()
	{
		return System.getProperty("eclipse.launcher").replace("eclipse.exe", "").replace("Eclipse.exe", "").replace("eclipse/", "");
		//String url = ResourcesPlugin.getWorkspace().getRoot().getLocation().toString();
		//return url;
	}
	
	public ArrayList<Class<?>> getAllClasses()  {
		//List<Class<?>> arrayListOfClasses = new ArrayList<>();
		ArrayList<Class<?>> arrayListOfClasses = new ArrayList<Class<?>>();

		//File dir = new File(getEclipseDir()+"testdata/"+"test1");
	    //File[] filesList = dir.listFiles();
		TestDefController otdefctr = new TestDefController();
		TestDef otdef = new TestDef();
		otdef = otdefctr.loadTestDef();
		
		String javaClassNameWithoutExtension = "";
		 String sourcename = otdef.getSourcename();
		 String testname = otdef.getTestname();
		//Windows String testpath = getEclipseDir() + otdef.getTestpath();
		 String testpath = getEclipseDir() + File.separator+ otdef.getTestpath();
		 
     	File trgDir = new File(getWorkSpace() +File.separator+sourcename+File.separator+"bin"+File.separator+testname);
     	File srcDir = new File(testpath + testname);
        
	    try {
			FileUtils.copyDirectory(srcDir, trgDir);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   
	    //File f = new File(getEclipseDir()+"testdata/"+"test1/BSKAcceptanceTests/bowlingtest/");
	    //File f = new File(getWorkSpace()+"\\BowlingScoreKeeper-master\\bin\\bowlingtest\\");
	    File[] filesList = trgDir.listFiles();
	    //File fc = new File(getEclipseDir()+"testdata/"+"test1/BSKAcceptanceTests/");
	    File fc = new File(getWorkSpace()+File.separator+sourcename+File.separator+"bin");
	    //Class clazz = null;
    	URLClassLoader urlcl = null;
    	 
   	    try
		{
		   URL[] cp = {fc.toURI().toURL()};
	       urlcl = new URLClassLoader(cp,Thread.currentThread().getContextClassLoader());
	     
		} catch (MalformedURLException e) {
			  // TODO Auto-generated catch block
			  e.printStackTrace();
		}
   	 
	    for (File file : filesList) {
	    					 
	        if (file.isFile()) {
	        	javaClassNameWithoutExtension = testname+"."+file.getName().split(".class")[0];
	           
	          	 
				try {
					Class c;
					c = Class.forName(javaClassNameWithoutExtension,true,urlcl);

					//c = Class.forName(javaClassNameWithoutExtension);
					arrayListOfClasses.add(c);
					Object a = c.newInstance();
	
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	        
	        }
	    }
	    
	    return arrayListOfClasses;
	}
	
	
		
   public static String loadXmlData(String data, String filename, String dirname){
		
		String d=null;
	     					        
		File file = new File(dirname,
				filename);
		
	
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
			        .newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document;
			document = documentBuilder.parse(file);
			if(data!="")
				d = document.getElementsByTagName(data).item(0).getTextContent();
    		return d.trim();

		
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}



}
