package grimpsoft.junit.statistics.model;

public class User {
	private String login;
	private String name;
	private String currentTest;
	private boolean isUserTestFinished;

		
	public boolean getIsUserTestFinished() {
		return isUserTestFinished;
	}
	
	public void setIsUserTestFinished(boolean isUserTestFinished) {
       this.isUserTestFinished = isUserTestFinished;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrentTest() {
		return currentTest;
	}

	public void setCurrentTest(String currentTest) {
		this.currentTest = currentTest;
	}

}
