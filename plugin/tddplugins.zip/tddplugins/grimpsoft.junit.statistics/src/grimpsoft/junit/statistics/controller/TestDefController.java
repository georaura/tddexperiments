package grimpsoft.junit.statistics.controller;

import grimpsoft.junit.statistics.data.MySQLAccess;
import grimpsoft.junit.statistics.model.TestDef;
import grimpsoft.junit.statistics.model.User;

public class TestDefController {

	public TestDef loadTestDef()
	{
	   MySQLAccess usrdata = new MySQLAccess();
	   User user = new User();
	   UserController usrc = new UserController();
	   String[] testdef = null;
	   TestDef otdef = new TestDef();
	   user = usrc.loadUser();
	   if(user != null)
			try {
				//usrd=usrdata.readDataBase("Select * from ulteo_user where login='" + userLogged +"'", "user").split(",");
				testdef=usrdata.readDataBase("Select * from ulteo_testsdef "
						+ "where testid='"+user.getCurrentTest()+"'", "testsdef").split(",");
				if(testdef!=null)
				{	
					otdef.setTestid(testdef[0]);
					otdef.setTestname(testdef[1]);
					otdef.setTestpath(testdef[2]);
					otdef.setSourcename(testdef[3]);
					otdef.setSourcepath(testdef[4]);
					otdef.setIsTestFinished(user.getIsUserTestFinished());
					
					
				}
				return otdef;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
	    else
		   return null;
	
	}
}
