package grimpsoft.junit.statistics.data;

import grimpsoft.junit.statistics.controller.TestDefController;
import grimpsoft.junit.statistics.model.TestDef;
import grimpsoft.junit.statistics.utils.FileUtil;
import grimpsoft.junit.statistics.utils.UserLogged;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.*;

public class Zip {
   static final int BUFFER = 2048;
   List<String> filesListInDir = new ArrayList<String>();
  
   /**
    * This method zips the directory
    * @param dir
    * @param zipDirName
    */
   private void zipDirectory(File dir, String zipDirName) {
       try {
           populateFilesList(dir);
           //now zip files one by one
           //create ZipOutputStream to write to the zip file
           FileOutputStream fos = new FileOutputStream(zipDirName);
           ZipOutputStream zos = new ZipOutputStream(fos);
           for(String filePath : filesListInDir){
               System.out.println("Zipping "+filePath);
               //for ZipEntry we need to keep only relative file path, so we used substring on absolute path
               ZipEntry ze = new ZipEntry(filePath.substring(dir.getAbsolutePath().length()+1, filePath.length()));
               zos.putNextEntry(ze);
               //read the file and write to ZipOutputStream
               FileInputStream fis = new FileInputStream(filePath);
               byte[] buffer = new byte[1024];
               int len;
               while ((len = fis.read(buffer)) > 0) {
                   zos.write(buffer, 0, len);
               }
               zos.closeEntry();
               fis.close();
           }
           zos.close();
           fos.close();
       } catch (IOException e) {
           e.printStackTrace();
       }
   }
    
   /**
    * This method populates all the files in a directory to a List
    * @param dir
    * @throws IOException
    */
   private void populateFilesList(File dir) throws IOException {
       File[] files = dir.listFiles();
       for(File file : files){
           if(file.isFile()) filesListInDir.add(file.getAbsolutePath());
           else populateFilesList(file);
       }
   }

   /**
    * This method compresses the single file to zip format
    * @param file
    * @param zipFileName
    */
   private static void zipSingleFile(File file, String zipFileName) {
       try {
           //create ZipOutputStream to write to the zip file
           FileOutputStream fos = new FileOutputStream(zipFileName);
           ZipOutputStream zos = new ZipOutputStream(fos);
           //add a new Zip Entry to the ZipOutputStream
           ZipEntry ze = new ZipEntry(file.getName());
           zos.putNextEntry(ze);
           //read the file and write to ZipOutputStream
           FileInputStream fis = new FileInputStream(file);
           byte[] buffer = new byte[1024];
           int len;
           while ((len = fis.read(buffer)) > 0) {
               zos.write(buffer, 0, len);
           }
            
           //Close the zip entry to write to zip file
           zos.closeEntry();
           //Close resources
           zos.close();
           fis.close();
           fos.close();
           System.out.println(file.getCanonicalPath()+" is zipped to "+zipFileName);
            
       } catch (IOException e) {
           e.printStackTrace();
       }

   }


   public  void zipfile () {
      
	   UserLogged usrl = new UserLogged();
	   FileUtil fdir = new FileUtil();
	   String userLogged = usrl.getUserLogged();
	   String fpath = fdir.getWorkSpace();
	   try {
    	    
	         BufferedInputStream origin = null;
	         System.out.println("PATH: "+fpath+File.separator+userLogged+".zip");		
	         FileOutputStream dest = new  FileOutputStream(fpath+File.separator+userLogged+".zip");
	         ZipOutputStream out = new ZipOutputStream(new 
	           BufferedOutputStream(dest));
	         //out.setMethod(ZipOutputStream.DEFLATED);
	         byte data[] = new byte[BUFFER];
	         // get a list of files from current directory
	         //File f = new File(".");
	         String fname= fpath+File.separator+"MarsRoverAPI";
	         File f = new File(fname);
	         String files[] = f.list();
	
	         for (int i=0; i<files.length; i++) {
	           // System.out.println("Adding: "+files[i]);
	            FileInputStream fi = new  FileInputStream(fname +File.separator+files[i]);
	            origin = new  BufferedInputStream(fi, BUFFER);
	            System.out.println("Adding: "+files[i]);
	            ZipEntry entry = new ZipEntry(files[i]);
	            out.putNextEntry(entry);
	            int count;
	            
	            while((count = origin.read(data, 0, 
	              BUFFER)) != -1) {
	               out.write(data, 0, count);
	            }
	            origin.close();
	         }
	         out.close();
	   } catch(Exception e) {
         e.printStackTrace();
      }
   }
   
   
     public String createZipArchive(String srcFolder) {
    	
    	 //File file = new File("/Users/pankaj/sitemap.xml");
         //String zipFileName = "/Users/pankaj/sitemap.zip";
    	 //zipSingleFile(file, zipFileName);
    	 String userLogged = null;
    	 String zipDirName = null;
    	 
    	 if (srcFolder == null)
    	 {
    		 TestDefController otdefctr = new TestDefController();
 			 TestDef otdef = new TestDef();
 			 otdef = otdefctr.loadTestDef();
    		 UserLogged usrl = new UserLogged();
    	  	 FileUtil fdir = new FileUtil();
    	  	 userLogged = usrl.getUserLogged();
    	  	 String fpath = fdir.getWorkSpace();
    	  	 srcFolder= fpath+File.separator+ otdef.getSourcename();;
    		 zipDirName = srcFolder+"-"+userLogged+".zip";
    	 }
    	 else
    	 {
    		 zipDirName = srcFolder+".zip";
         }
    	 File dir = new File(srcFolder);
    	 Zip zipFiles = new Zip();
         zipFiles.zipDirectory(dir, zipDirName);
       return zipDirName;
   }   
} 