package grimpsoft.junit.statistics;

import grimpsoft.junit.statistics.controller.TestDefController;
import grimpsoft.junit.statistics.controller.TestRawDataController;
import grimpsoft.junit.statistics.model.TestDef;
import grimpsoft.junit.statistics.utils.FileUtil;
import grimpsoft.junit.statistics.views.SelectionView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.eclipse.core.internal.resources.ProjectDescription;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchListener;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

public class StartupHelper implements IStartup {
	public static boolean isTestAsigned = false;
	private static final class DirtyHookRunnable implements Runnable {
		private IWorkspaceRoot workspaceRoot;
		FileUtil fl = new FileUtil();
		
		

		private DirtyHookRunnable(final IWorkspaceRoot workspaceRoot) {
			this.workspaceRoot = workspaceRoot;
		}

		public void run() {
			System.out.println("Starting Grimpsoft Statistics");
			
			String isdb = FileUtil.loadXmlData("isdb","credentials.xml",fl.getEclipseDir());
			if(isdb=="false")
			{
				 System.out.println("Starting Grimpsoft Statistics from xml");
				   initFromFile();
			}
			else
			{
				 System.out.println("Starting Grimpsoft Statistics from Data Base");
				 initFromDB();
					
			}
                    
		}
		
		private void deleteProjects(IProgressMonitor monitor)
		{
			// delete existing projects
			IProject[] projects = this.workspaceRoot.getProjects();

			for (IProject project : projects) {
				// don't delete the content
				try {
					project.delete(false, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		private void initFromDB()
		{
			IPath workspaceLocation = this.workspaceRoot.getLocation();
        	IProgressMonitor monitor = new NullProgressMonitor();
        	ProjectDescription projectDescription = new ProjectDescription();
        	
        	
			TestRawDataController otrawctr = new TestRawDataController();
			TestDefController otdefctr = new TestDefController();
			TestDef otdef = new TestDef();
			
			otdef = otdefctr.loadTestDef();
			
			if(otdef==null)
			{
				System.out.println("Grimpsoft Not Test assigned");
				deleteProjects(monitor);
				IProject project = this.workspaceRoot
						.getProject("You dont have any Projects");
				
				projectDescription.setName("You dont have any Projects");
				try {
					project.create(projectDescription, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// project.create(monitor);
				try {
					project.open(monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				isTestAsigned  = false;
				return;
			}
			
			
			
		   if(!otdef.getIsTestFinished())
		   {
			   isTestAsigned = true;
			   return;
		   }
		   System.out.println("user:" + otdef.getIsTestFinished());
		   try {
			    String eclipsepath = System.getProperty("eclipse.launcher").replace("eclipse.exe", "").replace("Eclipse.exe", "").replace("eclipse/", "");
			    String sourcename = otdef.getSourcename();
			    //String sourcepath = eclipsepath +  otdef.getSourcepath();
			    String sourcepath = eclipsepath + File.separator+ otdef.getSourcepath();
			   
			
	        	//JDK7 ONLY
	        	File trgDir = new File(workspaceLocation.toOSString()+File.separator+sourcename);
	        	File srcDir = new File(sourcepath + sourcename);

	        	FileUtils.copyDirectory(srcDir, trgDir);
	        	deleteProjects(monitor);
	        	IProject project = this.workspaceRoot
						.getProject((String) sourcename);

				
				projectDescription.setName((String) sourcename);
				
				
				//String location = workspaceLocation.toOSString()+"\\"+sourcename;
				//IPath locationPath = new org.eclipse.core.runtime.Path(location);
				//projectDescription.setLocation(locationPath);
				project.create(projectDescription, monitor);

				// project.create(monitor);
				project.open(monitor);

				otrawctr.startSession();
				isTestAsigned = true;
		
		   } catch (Exception e) {
				IStatus status = new Status(IStatus.INFO, Activator.PLUGIN_ID,
						0, "unable to load new projects", null);
				Activator.getDefault().getLog().log(status);
			}

		}
		
		private void initFromFile ()
		{
			ProjectDescription projectDescription = new ProjectDescription();
			try {
				  
				 FileUtil fl = new FileUtil();
				 IProgressMonitor monitor = new NullProgressMonitor();
				 IPath workspaceLocation = this.workspaceRoot.getLocation();
				 String sourcename = FileUtil.loadXmlData("sourcename","credentials.xml",fl.getEclipseDir());
							     					        
				 String eclipsepath = System.getProperty("eclipse.launcher").replace("eclipse.exe", "").replace("Eclipse.exe", "").replace("eclipse/", "");
				   
				 String sourcepath = eclipsepath + File.separator+ FileUtil.loadXmlData("sourcepath","credentials.xml",fl.getEclipseDir());
				   
				
		        	//JDK7 ONLY
		        	File trgDir = new File(workspaceLocation.toOSString()+File.separator+sourcename);
		        	File srcDir = new File(sourcepath + sourcename);

		        	FileUtils.copyDirectory(srcDir, trgDir);
		        	deleteProjects(monitor);
		        	IProject project = this.workspaceRoot
							.getProject((String) sourcename);

					
					projectDescription.setName((String) sourcename);
					
					
					//String location = workspaceLocation.toOSString()+"\\"+sourcename;
					//IPath locationPath = new org.eclipse.core.runtime.Path(location);
					//projectDescription.setLocation(locationPath);
					project.create(projectDescription, monitor);

					// project.create(monitor);
					project.open(monitor);
					isTestAsigned = true;
			
			} catch (Exception e) {
				IStatus status = new Status(IStatus.INFO, Activator.PLUGIN_ID,
						0, "unable to load new projects", null);
				Activator.getDefault().getLog().log(status);
			}
		}


	}
	



	
	public StartupHelper() {
		super();
	}

	public final void earlyStartup() {

		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkspaceRoot workspaceRoot = ResourcesPlugin.getWorkspace().getRoot();

		workbench.getDisplay().asyncExec(new DirtyHookRunnable(workspaceRoot));
		
		workbench.addWorkbenchListener(new IWorkbenchListener() {
			//@Override
			public void postShutdown(IWorkbench workbench) {}
			
			//@Override
			public boolean preShutdown(IWorkbench workbench, boolean forced) {
				IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
				
				IWorkbenchPage page = workbenchWindow.getActivePage();
				SelectionView sv = null;
				IViewPart part = null;
				try {
				     part = page.showView("grimpsoft.junit.statistics.views.SelectionView");
				   
				     sv = (SelectionView) part;
					
				} catch (PartInitException e1) {
					// TODO Auto-generated catch block
					System.out.println("ERROR AL CARGAR EL PLUGIN");
					e1.printStackTrace();
				}
				
				if(!StartupHelper.isTestAsigned)
			    {
					return true;
			    }
				
				boolean close  =  MessageDialog.openQuestion(Display.getDefault().getActiveShell(), "TDD Statistics", "Do you have finished? If YES, the TEST REPORT will be recorded and the session will close (You can not make changes once the session closed).. If NO, the session is closed and can continue after..");
				if(close) 
				{
					sv.runTest();
				    
					//Display.getDefault().asyncExec(new Runnable(){
				   //	public void run() {
				   //		sv.runTest();
				   // 	}
				   // 	});
				}
				return true;
				
			}
		});
	}
	
		
	
	
}