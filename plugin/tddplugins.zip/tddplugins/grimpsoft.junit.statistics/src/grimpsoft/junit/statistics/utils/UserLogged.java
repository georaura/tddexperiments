package grimpsoft.junit.statistics.utils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class UserLogged {
	
	public String getUserLogged()
	{
		   Class<?> c = null;
	       Object   o = null;
	       Method  method = null;  
	       String credentials = loadCredentials();

	       if(credentials!=null)
	    	   return credentials;
	       if(System.getProperty("os.name").toLowerCase().contains("windows")){

	           try {
				c = Class.forName("com.sun.security.auth.module.NTSystem");
				o = Class.forName("com.sun.security.auth.module.NTSystem").newInstance();
				method = c.getDeclaredMethod ("getName");
	           } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
	        	   e.printStackTrace();
	           } catch (InstantiationException e) {
				// TODO Auto-generated catch block
	        	   e.printStackTrace();
	           } catch (IllegalAccessException e) {
	        	// TODO Auto-generated catch block
	        	   e.printStackTrace();
	           } catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
	        	   e.printStackTrace();
	           } catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	           }
		
	       }

	       if(System.getProperty("os.name").toLowerCase().contains("linux")){

	           try {
				c = Class.forName("com.sun.security.auth.module.UnixSystem");
				o = Class.forName("com.sun.security.auth.module.UnixSystem").newInstance();
	            method = c.getDeclaredMethod ("getUsername");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	          

	       }

	       if(System.getProperty("os.name").toLowerCase().contains("solaris")){

	           try {
				   c = Class.forName("com.sun.security.auth.module.SolarisSystem");
	 	           o = Class.forName("com.sun.security.auth.module.SolarisSystem").newInstance();
     	           method = c.getDeclaredMethod ("getUsername");

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	       }

	       if(c != null){
	            try {
					return (String) method.invoke(o);
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	       }
	       return null;
		
	}
	
    public String loadCredentials(){
		
		FileUtil fl = new FileUtil();
		
	     					        
		File file = new File(fl.getEclipseDir(),
				"credentials.xml");
		
	
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
			        .newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document;
			document = documentBuilder.parse(file);
			String usr = document.getElementsByTagName("user").item(0).getTextContent();
			String pwd = document.getElementsByTagName("password").item(0).getTextContent();
			return usr;
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}


}
