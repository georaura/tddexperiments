package grimpsoft.junit.statistics.views;

import grimpsoft.junit.statistics.controller.UserController;
import grimpsoft.junit.statistics.data.MySQLAccess;
import grimpsoft.junit.statistics.model.User;
import grimpsoft.junit.statistics.utils.DateTimeUtils;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.Workbench;
import org.junit.internal.TextListener;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.eclipse.ui.part.FileEditorInput;
















import javax.swing.*;



public class GeneralInfo {
	
	private String filePath;
	private static Action action1;
	private static Action action2;
	private static JFrame frame;
	
	public Container createContentPane (){
	
		JPanel panel = new JPanel();
		placeComponents(panel);
		
		return panel;
	}
	
	
	
	public static void createAndShowGUI(Action act1,Action act2){
		action1 = act1;
		action2 = act2;
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		
		frame = new JFrame("User Information");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
		GeneralInfo info = new GeneralInfo(); 
		frame.setContentPane(info.createContentPane());
		//frame.setBounds(140, 130, 100, 20);
		frame.setSize(300,280 );   
		frame.setVisible(true);
		frame.setResizable(false);
	
		frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
	}
	private static void placeComponents(JPanel panel) {
		
		UserController ouserctr = new UserController();
		User ousr = new User();
		ousr = ouserctr.loadUser();
		
		panel.setLayout(null);

		JLabel UserLoginLabel = new JLabel("User Login:");
		UserLoginLabel.setBounds(10, 10, 80, 25);
		panel.add(UserLoginLabel);

		final JTextField UserLoginText = new JTextField(20);
		UserLoginText.setText(ousr.getLogin());
		UserLoginText.setEditable(false);
		UserLoginText.setBounds(100, 10, 160, 25);
		panel.add(UserLoginText);
		
		JLabel UserNameLabel = new JLabel("User Name:");
		UserNameLabel.setBounds(10, 40, 80, 25);
		panel.add(UserNameLabel);

		final JTextField UserNameText = new JTextField(20);
		UserNameText.setText(ousr.getName());
		UserNameText.setEditable(false);
		UserNameText.setBounds(100, 40, 160, 25);
		panel.add(UserNameText);

		JLabel EmailNameLabel = new JLabel("Email:");
		EmailNameLabel.setBounds(10, 70, 80, 25);
		panel.add(EmailNameLabel);

		final JTextField EmailNameText = new JTextField(20);
		EmailNameText.setEditable(false);
		EmailNameText.setBounds(100, 70, 160, 25);
		panel.add(EmailNameText);
		
		JLabel OrganizationLabel = new JLabel("Organization:");
		OrganizationLabel.setBounds(10, 100, 80, 25);
		panel.add(OrganizationLabel);

		final JTextField OrganizationText = new JTextField(20);
		OrganizationText.setEditable(false);
		OrganizationText.setBounds(100, 100, 160, 25);
		panel.add(OrganizationText);
		
		
		JLabel userCurrentTestLabel = new JLabel("Current Test:");
		userCurrentTestLabel.setBounds(10, 130, 80, 25);
		panel.add(userCurrentTestLabel);

		final JTextField userCurrentTestText = new JTextField(20);
		userCurrentTestText.setBounds(100, 130, 160, 25);
		userCurrentTestText.setEditable(false);
		userCurrentTestText.setText(ousr.getCurrentTest());
		panel.add(userCurrentTestText);
		
		/*
		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setBounds(10, 160, 80, 25);
		panel.add(passwordLabel);

		JPasswordField passwordText = new JPasswordField(20);
		passwordText.setBounds(100, 160, 160, 25);
		panel.add(passwordText);
        
		JButton Register = new JButton("Register");
		Register.setBounds(10, 200, 110, 25);
		panel.add(Register);
		
		Register.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		    	this.getFilePath();
			}
		    private void getFilePath()
			{
				IWorkbench workbench = PlatformUI.getWorkbench();
				IWorkbenchWindow window = workbench == null ? null : workbench.getActiveWorkbenchWindow();
				
				IWorkbenchPage activePage =  window == null ? null : window.getActivePage();
				IEditorPart editor =  activePage == null ? null : activePage.getActiveEditor();
				
				
				IEditorInput input =  editor == null ? null : editor.getEditorInput();
				IPath path = input instanceof FileEditorInput ? ((FileEditorInput)input).getPath()  : null;
				if (path != null)
				{
				    // Do something with path.
					userText.setText(path.toString());
				}
				
				
			}	    
		    
		});
		
		*/
		
		JButton registerButton = new JButton("Close");
		registerButton.setBounds(100, 200, 110, 25);
		panel.add(registerButton);
		
		registerButton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
	           this.sendData();	   
			}

			private void sendData() {
				//final File f = new File(MyClass.class.getProtectionDomain().getCodeSource().getLocation().getPath());
			//	SelectionView.action3.setEnabled(false);
				
				DateTimeUtils da = 	DateTimeUtils.getInstance();
			//	da.getInstance();
				String msg;
				msg = da.getStartDate() + "\n" + UserLoginText.getText() + ":" + UserNameText.getText() + ":" + EmailNameText.getText() + ":" + userCurrentTestText.getText() + ":" +  OrganizationText.getText() ;
				da.setMsg(msg);	
				action1.setEnabled(true);
				action1.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
						getImageDescriptor(ISharedImages.IMG_ETOOL_SAVE_EDIT));
				
			//	action2.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			//			getImageDescriptor(ISharedImages.IMG_TOOL_COPY_DISABLED));
			//	action2.setEnabled(false);
				frame.dispose();
				
				UserController dao = new UserController();
				User u = new User();
			    u = dao.loadUser();
			    System.out.println("USUARIO"+u.getName()+u.getCurrentTest());
								
			}
		});
		
		
		

	}
	
	public void  getCurrentProject(){    
        ISelectionService selectionService =     
            Workbench.getInstance().getActiveWorkbenchWindow().getSelectionService();    

        ISelection selection = selectionService.getSelection();    

        //IProject project = null;    
        if(selection instanceof IStructuredSelection) {    
            Object element = ((IStructuredSelection)selection).getFirstElement();    

            /*
            if (element instanceof IResource) {    
                project= ((IResource)element).getProject();    
            } else if (element instanceof PackageFragmentRootContainer) {    
                IJavaProject jProject =     
                    ((PackageFragmentRootContainer)element).getJavaProject();    
                project = jProject.getProject();    
            } else if (element instanceof IJavaElement) {    
                IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
                project = jProject.getProject();    
            } 
            */   
        }     
        //return project;    
    }

}

