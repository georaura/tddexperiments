package grimpsoft.junit.statistics.model;

public class TestDef {

	private String testid;
	private String testname;
	private String testpath;
	private String sourcename;
	private String sourcepath;
	private boolean isTestFinished;

	
	public boolean getIsTestFinished() {
		return isTestFinished;
	}
	
	public void setIsTestFinished(boolean isTestFinished) {
       this.isTestFinished = isTestFinished;
	}
	
	public String getTestid() {
		return testid;
	}
	public void setTestid(String testid) {
		this.testid = testid;
	}
	public String getTestname() {
		return testname;
	}
	public void setTestname(String testname) {
		this.testname = testname;
	}
	public String getTestpath() {
		return testpath;
	}
	public void setTestpath(String testpath) {
		this.testpath = testpath;
	}
	public String getSourcename() {
		return sourcename;
	}
	public void setSourcename(String sourcename) {
		this.sourcename = sourcename;
	}
	public String getSourcepath() {
		return sourcepath;
	}
	public void setSourcepath(String sourcepath) {
		this.sourcepath = sourcepath;
	}
	

}
