package grimpsoft.junit.statistics.views;


import grimpsoft.junit.statistics.controller.TestRawDataController;
import grimpsoft.junit.statistics.data.Zip;
import grimpsoft.junit.statistics.utils.DateTimeUtils;
import grimpsoft.junit.statistics.utils.FileUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IMarkSelection;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.core.resources.IFile;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.PageBook;
import org.eclipse.ui.part.ViewPart;
import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;




/**
 * This view simply mirrors the current selection in the workbench window.
 * It works for both, element and text selection.
 */
public class SelectionView extends ViewPart {

	private PageBook pagebook;
	private TableViewer tableviewer;
	private TableViewer tableviewer2;
	
	private TextViewer textviewer;
	private Action action1;
	private Action action2;
	private Action action3;
	private Action action4;
	private Action action5;
	
	private Action doubleClickAction;
	private String pathf ;
	private String javaClassNameWithoutExtension;
	private static List<Class<?>> classes;
	
	public static boolean close = false;
	
	
	
	class ViewContentProvider implements IStructuredContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}
		public void dispose() {
		}
		public Object[] getElements(Object parent) {
		
			if(classes == null)
				return new String[] { "Empty"};
			String o="";
			
			for(int i = 0;i<classes.toArray().length; i++){
				o = o+ classes.toArray()[i] + ",";
			}
			String it[] = o.split(",");
			if (it[0]== "")
				return new String[] { "Empty"};
			//return new String[] { "One", "Two", "tres" };
			return it;
		}
	}
	
	class ViewLabelProvider extends LabelProvider implements ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			return getText(obj);
		}
		public Image getColumnImage(Object obj, int index) {
			return getImage(obj);
		}
		
		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().
					getSharedImages().getImage(ISharedImages.IMG_OBJ_ELEMENT);
		}
	}
	class NameSorter extends ViewerSorter {
	}

	// the listener we register with the selection service 
	private ISelectionListener listener = new ISelectionListener() {
		public void selectionChanged(IWorkbenchPart sourcepart, ISelection selection) {
			// we ignore our own selections
			if (sourcepart != SelectionView.this) {
			    showSelection(sourcepart, selection);
			    
			  
			}
		}
	};
	
	/**
	 * Shows the given selection in this view.
	 */
	public void showSelection(IWorkbenchPart sourcepart, ISelection selection) {
		setContentDescription(sourcepart.getTitle() + " (" + selection.getClass().getName() + ")");
		/*
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection ss = (IStructuredSelection) selection;
			showItems(ss.toArray(),"n");
			if (selection instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) selection;
				//getFilePath(sourcepart,ts);	
			}
			Object firstElement = ss.getFirstElement();
	        
			if (firstElement instanceof IAdaptable)
	        {
	            IProject project = (IProject)((IAdaptable)firstElement).getAdapter(IProject.class);
	            IPath path = project.getFullPath();
	          //  setContentDescription(path.toOSString());
	        }
			
			//Object obj = ss.getFirstElement();
			//IResource selectedFile;
			//String pt;
			//selectedFile=(IResource)obj;
			//pt = selectedFile.getLocation().toString().replace(" ","%20");
			 
			
			 
		}
		*/
		if (selection instanceof ITextSelection) {
			ITextSelection ts  = (ITextSelection) selection;
			//showText(ts.getText());
			getFilePath(sourcepart,ts);
			
		}
		if (selection instanceof IMarkSelection) {
			IMarkSelection ms = (IMarkSelection) selection;
			try {
			    showText(ms.getDocument().get(ms.getOffset(), ms.getLength()));
			    
			} catch (BadLocationException ble) { }
		}
		
		
	}
	
	private void showItems(Object[] items, String s) {
		
		System.out.println("Muestra Items");		
		//showText(o);
		tableviewer.setInput(items);
		pagebook.showPage(tableviewer.getControl());
		System.out.println("SALE Muestra Items");
	}
	
	private void showText(String text) {
		textviewer.setDocument(new Document(text));
		pagebook.showPage(textviewer.getControl());
	}
	
	public void createPartControl(Composite parent) {
		//System.setProperty("java.home", "C:\\Program Files\\Java\\jdk1.8.0_05\\jre");
		
		  
		// the PageBook allows simple switching between two viewers
		pagebook = new PageBook(parent, SWT.NONE);
		
		tableviewer2 = new TableViewer(parent, SWT.MULTI |SWT.NONE);
		
		tableviewer = new TableViewer(pagebook, SWT.FULL_SELECTION
                | SWT.H_SCROLL | SWT.V_SCROLL | SWT.NONE);
		
		//tableviewer.setLabelProvider(new WorkbenchLabelProvider());
		//tableviewer.setContentProvider(new ArrayContentProvider());
		
		//tableviewer = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		tableviewer.setContentProvider(new ViewContentProvider());
		tableviewer.setLabelProvider(new ViewLabelProvider());
		//tableviewer.setSorter(new NameSorter());
		tableviewer.setInput(getViewSite());
		
		/*
		Color c = new Color(null, 255, 0, 0);
		Label searchLabel = new Label(parent, SWT.NONE);
	    searchLabel.setText("Search: ");
	    searchLabel.setBackground(c);
	    searchLabel.setSize(200, 80);
	   
	    final Text searchText = new Text(parent, SWT.BORDER | SWT.SEARCH);
	    searchText.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL
	        | GridData.HORIZONTAL_ALIGN_FILL));
	    */
		// we're cooperative and also provide our selection
		// at least for the tableviewer
		
		getSite().setSelectionProvider(tableviewer);
		
		textviewer = new TextViewer(pagebook, SWT.H_SCROLL | SWT.V_SCROLL);
		textviewer.setEditable(false);
		
		getSite().getWorkbenchWindow().getSelectionService().addSelectionListener(listener);
		makeActions();
		contributeToActionBars();
	}

	public void setFocus() {
		pagebook.setFocus();
	}

	public void dispose() {
		// important: We need do unregister our listener when the view is disposed
		getSite().getWorkbenchWindow().getSelectionService().removeSelectionListener(listener);
		super.dispose();
	}
	
	
	private void makeActions() {
		action1 = new Action() {
			public void run() {
				

				// Compile source file.
			/*	
				JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
				if (compiler != null)
				showMessage("aqui" + compiler.toString());
				else
					showMessage("compilador nulo" + System.getProperty("java.home"));	
				if(pathf!=null)
				try {	
					 String p = "C:/Geovanny/tddworkspace/MarsRoverAPI/src/upm/tdd/training/MarsRover.java";
	        */
				 // compiler.run(null, null, null, p);
				
				addClases();  
				
				
				 
			}
		};
		action1.setText("Add current Test Class");
		action1.setToolTipText("Add current Test Class");
		action1.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJ_ADD));
		
		action2 = new Action() {
			public void run() {
				removeClass();
			}
		};
		action2.setText("Remove Test class");
		action2.setToolTipText("Remove Test Class");
		action2.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_TOOL_DELETE));
		
		action3 = new Action() {
			public void run() {
				
				runTest();
				action3.setEnabled(false);
			}
		};
		action3.setText("Save Report Tests");
		action3.setToolTipText("Save Report Tests");
		//action3.setEnabled(false);
		action3.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_ETOOL_SAVEALL_EDIT));
		
		
		action4 = new Action() {
			public void run() {
				new GeneralInfo();	
				GeneralInfo.createAndShowGUI(action3,action4);
			}
		};
		action4.setText("User Information");
		action4.setToolTipText("User Information");
		action4.setEnabled(true);
		action4.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_TOOL_COPY));
		
		action5 = new Action() {
			public void run() {
				//new FileList();	
				//FileList.initFileList(SelectionView.this);
				addAllClases();
				
			}
		};
		action5.setText("Load Test Library");
		action5.setToolTipText("Load Test Library");
		//action5.setEnabled(true);
		action5.setEnabled(false);
		
		action5.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJ_FOLDER));
		
		
		doubleClickAction = new Action() {
			public void run() {
				ISelection selection = tableviewer.getSelection();
				Object obj = ((IStructuredSelection)selection).getFirstElement();
				showMessage("Double-click detected on "+obj.toString());
			}
		};
	}
	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		//manager.add(action1);
		//manager.add(new Separator());
		//manager.add(action2);
		//manager.add(new Separator());
		manager.add(action3);
		manager.add(new Separator());
		//manager.add(action4);
		//manager.add(new Separator());
		//manager.add(action5);
	}

	private void fillContextMenu(IMenuManager manager) {
		//manager.add(action1);
		//manager.add(action2);
		manager.add(action3);
		//manager.add(action4);
		//manager.add(action5);
		// Other plug-ins can contribute there actions here
		manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		//manager.add(action1);
		//manager.add(action2);
		//manager.add(action5);
		manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
		//manager.add(action4);
		manager.add(action3);
		
		
	}
	private void showMessage(String message) {
		MessageDialog.openInformation(
				tableviewer.getControl().getShell(),
			"Sample View",
			message);
	}
	
	public void runTest()
	{
		    addAllClases();
			
		    if(classes==null || classes.isEmpty())
			{
				setContentDescription("Class list is Empty,.. Please add Classes (use + button)");
				return;
			}
   	        //currentPackageName = linea.split("package")[0];
   	        JUnitCore core=new JUnitCore();
   	       
   	        
			try {
				
				
				 PrintStream writetoEngineer = new PrintStream(new File ("Engineer.txt"));
					
				core.addListener(new TextListener(System.out));
				core.addListener(new TextListener(writetoEngineer));
				 Result result;
				 setContentDescription("Before run classes");
				if(classes!=null)
				{
					setContentDescription("Run classes " + classes.size());
					result=core.run(true,classes.toArray(new Class<?>[0]));
                    
				}
				else
				{
					setContentDescription("Empty Class list...");
					return;
				}
			    classes.clear();
			    classes = null;
			    DateTimeUtils da = 	DateTimeUtils.getInstance();
			   
				 BufferedWriter writer = null;
			        try {
			           File  logFile = new File("TddStatics.txt");
			            writer = new BufferedWriter(new FileWriter(logFile,true));
			            writer.write(da.getMsg() + "\n"+ da.getDifference());
			            
			        } catch (Exception e) {
			        	setContentDescription("File Not open Error " + e.getMessage());
			            e.printStackTrace();
			        } finally {
			            try {
			                // Close the writer regardless of what happens...
			                writer.close();
			            } catch (Exception e) {
			            }
			        }
				//c = Class.forName(javaClassNameWithoutExtension);
				//Object a = clazz.newInstance();
				// setContentDescription("pp" + a.getClass().getName());
			   
			    getReport();
			    
			   
			    
			    //setContentDescription( da.getMsg().replace(":", " ") + "\nElapsed time " + da.getDifference());
			    
			    action3.setEnabled(false);
				action3.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
						getImageDescriptor(ISharedImages.IMG_ETOOL_SAVE_EDIT_DISABLED));
				
				
				close = MessageDialog.open(MessageDialog.INFORMATION,Display.getDefault().getActiveShell()
					    , "TDD Statistics", "End Process.. thanks  for your colaboration",0);
			   
				
			    
			    
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
  
	}
	
	public void addAllClases()
	{
		FileUtil fu = 	new FileUtil();
		if (classes == null)
			classes=new ArrayList<Class<?>>();
		classes=fu.getAllClasses();
		showItems(classes.toArray(),"n");
		
	}
	private void addClases()
	{
		
		setContentDescription(javaClassNameWithoutExtension); 	
		String binpath = null;
   	    binpath = pathf.split("src")[0] + "bin/"; 
   	
		File f = new File(binpath);
   	    Class clazz = null;
   	    
		if (classes == null)
			classes=new ArrayList<Class<?>>();
		try
		{
		URL[] cp = {f.toURI().toURL()};
		URLClassLoader urlcl = new URLClassLoader(cp,Thread.currentThread().getContextClassLoader());
		
		clazz = clazz.forName(javaClassNameWithoutExtension,true,urlcl);
		
		 classes.add(clazz);	
		 showItems(classes.toArray(),"n");
		
		     
	   } catch (ClassNotFoundException e) {
		   // TODO Auto-generated catch block
		   setContentDescription("Class Not Found " + e.getMessage());
		   e.printStackTrace();
	   } catch (MalformedURLException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
	   }

	}
	
	private void removeClass()
	{
		if (classes != null && !classes.isEmpty())
		{
		   classes.remove( classes.size()-1);
		   showItems(classes.toArray(),"n");
		}
	}
	
	private void getFilePath(IWorkbenchPart sourcepart, ITextSelection selection)
	{
		/*
		//IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchPartSite workbench = sourcepart.getSite();
		//IWorkbenchWindow window = workbench == null ? null : workbench.getActiveWorkbenchWindow();
		IWorkbenchPage activePage =  workbench == null ? null : workbench.getPage();
		IEditorPart editor =  activePage == null ? null : activePage.getActiveEditor();
		
		
		IEditorInput input =  editor == null ? null : editor.getEditorInput();
		IPath path = input instanceof FileEditorInput ? ((FileEditorInput)input).getPath()  : null;
		if (path != null)
		{
		    // Do something with path.
			
		}
		*/
		
		// TreeSelection treeSelection = (TreeSelection) selection;
        // TreePath[] treePaths = treeSelection.getPaths();
        // TreePath treePath = treePaths[0];
         
        // ISelectionService service = getSite().getWorkbenchWindow().getSelectionService();
        // IStructuredSelection structured = (IStructuredSelection) service
     //		.getSelection("org.eclipse.jdt.ui.PackageExplorer");
      //   IFile file = (IFile) structured.getFirstElement();
       //  IPath path = file.getLocation();
       //  setContentDescription(path.toPortableString());
              
        // Object lastSegmentObj = treePath.getLastSegment();
        // Class currClass = lastSegmentObj.getClass();
         //setContentDescription(currClass.getName());
       
        // IFile file = (IFile) treeSelection.getFirstElement();
        
        // IPath path = file.getLocation();
        // setContentDescription("Gio" + path.toPortableString());
         
         /*    
         Object firstElement = treeSelection.getFirstElement(); 
         if (firstElement instanceof IAdaptable) {
        	 IFile file = (IFile) ((IAdaptable) firstElement).getAdapter(IFile.class);
        	    if(file != null) {
               	 String pathf = "File=" + file.getName() + "path: " + file.getRawLocation().toOSString();
                    setContentDescription(pathf);
                }
         }
         */
         /*
         if(lastSegmentObj instanceof IAdaptable) {
        	 
             IFile file = (IFile) ((IAdaptable) lastSegmentObj).getAdapter(IFile.class);
             if(file != null) {
            	 String pathf = "File=" + file.getName() + "path: " + file.getRawLocation().toOSString();
                 setContentDescription(pathf);
             }
         }
         */
         IWorkbenchPart workbenchPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActivePart(); 
         IFile file = (IFile) workbenchPart.getSite().getPage().getActiveEditor().getEditorInput().getAdapter(IFile.class);
         File archivo = null;
         if (file != null)
         {
        	
            pathf = file.getRawLocation().toOSString();
            pathf =  file.getRawLocation().toString();
            String currentPackageName = null;           
            archivo = new File (pathf);
            FileReader fr = null;
            String linea;
            
			try {
				fr = new FileReader (archivo);
				BufferedReader br = new BufferedReader(fr);
				  
		         while((linea=br.readLine())!=null)
		        	 if (linea.contains("package"))
		        	 {
		        		 
		        		 currentPackageName = linea.substring(8).trim();
		        		 currentPackageName = currentPackageName.split(";")[0];
		        		 
		        		 break;
		        	 }
		        		  
		         if( null != fr ){   
		               fr.close();     
		         }
		         
		        
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
			         	   
     	  javaClassNameWithoutExtension = file.getName().split(".java")[0];
     	  javaClassNameWithoutExtension = currentPackageName + "." + javaClassNameWithoutExtension;
     	 
     	   	   
     	   
         
         }
         //String currentDir  = new java.io.File("").toURI().toString().split("file:/")[1];
        // setContentDescription(currentDir);
   	  
	}
	
	private void getReport()
	{
		
		int ntus=0;
		float qlty=0;
		float prod=0;
		int ntest=0;
		
        tableviewer.setContentProvider(ArrayContentProvider.getInstance());

        tableviewer.getTable().setLayoutData(
                new GridData(SWT.LEFT, SWT.LEFT, true, true));
		Color c = new Color(null, 207, 222, 238);
		final Table table = tableviewer.getTable();
        table.setBackground(c);
        
        List<TestData> rows = new ArrayList<TestData>();
        List<TestSummary> rows2 = new ArrayList<TestSummary>();
        
        tableviewer2.setContentProvider(ArrayContentProvider.getInstance());

        tableviewer2.getTable().setLayoutData(
                new GridData(SWT.LEFT, SWT.LEFT, true, true));
        Color c2 = new Color(null, 180, 205, 230);
        tableviewer2.getTable().setBackground(c2);

       
       /* 
        TableViewerColumn colResumeName = new TableViewerColumn(tableviewer2, SWT.NONE);
        colResumeName.getColumn().setWidth(200);
        colResumeName.getColumn().setText("SUMMARY");
        colResumeName.setLabelProvider(new StyledCellLabelProvider() {
            @Override
            public void update(ViewerCell cell) {
                cell.setImage(getImages(table.getDisplay(),80,0xFF0000));
               // cell.setText((String) cell.getElement());

            }
          
          });
        
        */
        TableViewerColumn colResumeName = new TableViewerColumn(tableviewer2, SWT.NONE);
        colResumeName.getColumn().setWidth(350);
        colResumeName.getColumn().setText("SUMMARY");
        colResumeName.setLabelProvider(new ColumnLabelProvider() {
        	@Override
            public String getText(Object element) {
        		TestSummary t = (TestSummary)element;
                return String.valueOf(t.getKey());
            }
        	@Override
            public Image getImage(Object element) {
        		TestSummary t = (TestSummary)element;
                return getImages(table.getDisplay(),50,t.value2);
            }
        	
          });
        
        
        TableViewerColumn colClassName = new TableViewerColumn(tableviewer, SWT.NONE);
        colClassName.getColumn().setWidth(150);
        colClassName.getColumn().setText("CLASS NAME");
        colClassName.setLabelProvider(new ColumnLabelProvider() {
        	@Override
            public String getText(Object element) {
        		TestData t = (TestData)element;
                return t.getClassName();
            }
        	
          });
        
        TableViewerColumn colFirstName = new TableViewerColumn(tableviewer, SWT.NONE);
        colFirstName.getColumn().setWidth(150);
        colFirstName.getColumn().setText("TEST CASES");
        colFirstName.setLabelProvider(new ColumnLabelProvider() {
        	@Override
            public String getText(Object element) {
                TestData t = (TestData)element;
                return t.getTestCase();
            }
        	
          });
        
        
        TableViewerColumn colSecondName = new TableViewerColumn(tableviewer, SWT.NONE);
        colSecondName.getColumn().setWidth(400);
        colSecondName.getColumn().setText("ASSERTIONS");
        colSecondName.setLabelProvider(new ColumnLabelProvider() {
        	@Override
            public String getText(Object element) {
                TestData t = (TestData)element;

                return t.getAssertions();
            }
        	@Override
            public Image getImage(Object element) {
        		TestData t = (TestData)element;
        		if(t!=null && t.fail>0)
                    return getImages(table.getDisplay(),50,t.fail);
        		else
        			return getImages(table.getDisplay(),50,0xCFDEEE);
            }
          });
        
		 File archivo = null;
		   archivo = new File ("TddStatics.txt");
           FileReader fr = null;
           String linea;
           String content ="";
           
			try {
				fr = new FileReader (archivo);
				BufferedReader br = new BufferedReader(fr);
				
			     String []fields;
			  
			     TestSummary ts1 = new TestSummary();
	        		ts1.setKey("");
	           		ts1.setValue1(1);
	        		ts1.setValue2(0xB4CDE6);
	        		rows2.add(ts1);
			    
	        	String cnl = "";
	        	String act = "";
		        while((linea=br.readLine())!=null)
		        {
		        	TestData td =null;
		        	linea=linea.trim();
		        	if(!linea.isEmpty())
		        	{
		        		
		        		if(linea.startsWith("Test Class:"))
		        		{
		        			
		        			   td = new TestData();			        			
			        			TestData td2 = new TestData();
			        			cnl = act;
			        		    td2.setClassName(linea.split("Test Class:")[1]);
			        		    rows.add(td2);
			        		
		        		}
			        	if (linea.startsWith("Test case:"))
			        	{
			        		 td = new TestData();
			        		String ln = linea.replaceAll("(Test Number )(\\d+)", "( )").replace("Test case:","").replace("methodName:", ":");
			        		
			        		td.setTestCase(ln.split("ClassName:")[0]);
			        	}
			        	else if (linea.startsWith("Assertion"))
			        	{	
			        		 td = new TestData();
			        		if(linea.contains("Fail: true"))
			        			if (linea.contains("Error"))
			        				td.setFail(0xFAD000);
			        			else
			        			    td.setFail(0xFF0000);
			        		else if (linea.contains("Fail: false"))
			        			td.setFail(0x00FF00);
			        	
			        		else
			        			td.setFail(0xCFDEEE);
			        		td.setAssertions(linea.replace("Assertion:", "").replace("Fail: true", "").replace("Fail: false", "").replace("null", ""));
			        	
			        	}
			        	else if (linea.startsWith("Summary6"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ts.setKey(linea);
			        		ts.setValue1(Integer.parseInt(fields[1]));
			        		ts.setKey(linea.substring(9).replace(":", ""));
					        //ts.setValue2(Integer.parseInt(fields[3]));
			        		ts.setValue2(0xFF0000);
			        		
			        		rows2.add(ts);
			        		
			        	}
			        	else if (linea.startsWith("Summary7"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ts.setKey(linea.substring(9).replace(":", ""));
					        ts.setValue1(Integer.parseInt(fields[1]));
			        		//ts.setValue2(Integer.parseInt(fields[3]));
			        		ts.setValue2(0x00FF00);
			        		
			        		rows2.add(ts);
			        	}
			        	else if (linea.startsWith("Summary8"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ts.setKey(linea.substring(9).replace(":", ""));
					        ts.setValue1(Integer.parseInt(fields[1]));
			        		//ts.setValue2(Integer.parseInt(fields[3]));
			        		ts.setValue2(0xFAD000);
			        		
			        		rows2.add(ts);
			        	}
			        	else if (linea.startsWith("Summary9"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ts.setKey(linea.substring(9).replace(":", ""));
			        		ts.setValue1(Integer.parseInt(fields[1]));
			        		ts.setValue2(0xD5D5D5);
			        		rows2.add(ts);
			        	}
			        	else if (linea.startsWith("Summary10"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ts.setKey(linea.substring(9).replace(":", ""));
			           		ts.setValue1(Integer.parseInt(fields[1]));
			           		ntest = Integer.parseInt(fields[1]);
			        		ts.setValue2(0x3399FF);
			        		rows2.add(ts);	
			        	}
			        	else if (linea.startsWith("TUS:"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		fields = linea.split(":");
			        		ntus = Integer.parseInt(fields[1].trim());
			        		ts.setKey(linea);
			           		ts.setValue1(0);
			        		ts.setValue2(0x3399FF);
			        		rows2.add(ts);	
			        	}
			        	else if (linea.startsWith("PERTUS:"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		//fields = linea.split(":");
			        		
			        		ts.setKey(linea);
			           		ts.setValue1(0);
			        		ts.setValue2(0x3399FF);
			        		rows2.add(ts);	
			        	}
			        	else if (linea.startsWith("QLTY:"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		ts.setKey(linea);
			        		fields = linea.split(":");
			        		qlty = Float.parseFloat(fields[1].replace("%", "").trim());
			           		ts.setValue1(0);
			        		ts.setValue2(0x3399FF);
			        		rows2.add(ts);	
			        	}
			        	else if (linea.startsWith("PROD:"))
			        	{
			        		TestSummary ts = new TestSummary();
			        		ts.setKey(linea);
			        		fields = linea.split(":");
			        		prod = Float.parseFloat(fields[1].replace("%", "").trim());
			           		ts.setValue1(0);
			        		ts.setValue2(0x3399FF);
			        		rows2.add(ts);	
			        	}
			        	if(td!=null)
			        	{
			        	  rows.add(td);
			        	}
			        	td = null;
			        	
			        }
		        	content=content+linea+"\n";
		            
		        }
		        
		        TestSummary ts3 = new TestSummary();
        		ts3.setKey("");
           		ts3.setValue1(1);
        		ts3.setValue2(0xB4CDE6);
        		rows2.add(ts3);
        		
        		TestSummary ts4 = new TestSummary();
        		ts4.setKey("JUnit Statistics CopyRight (c) 2014, by Grimpsoft");
           		ts4.setValue1(1);
        		ts4.setValue2(0xB4CDE6);
        		rows2.add(ts4);
        		rows2.add(ts3);
		        tableviewer.setInput(rows);
		        tableviewer2.setInput(rows2);
		          
		        //showText(content);
		         if( null != fr ){   
		               fr.close();     
		            }
		        } catch (FileNotFoundException e1) {
		    				// TODO Auto-generated catch block
		    				e1.printStackTrace();
		        } catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	 
            
            
           
         // create a column for the first name
           
			tableviewer2.getTable().setHeaderVisible(true);
			
           table.setHeaderVisible(true);
           table.setLinesVisible(false);
           
           TestRawDataController trwd = new TestRawDataController();
		    
		    Zip zf = new Zip();
		    String zif = zf.createZipArchive(null);
		   
		    if(zif!=null)
		       trwd.writeZipToDB(zif);
		    
		   trwd.writeResultToDB("TddStatics.txt");
		   trwd.endSession(ntus, qlty, prod, ntest);
	        
			//tableviewer.setInput(button);
			//textviewer.setDocument(new Document(text));
			//pagebook.showPage(textviewer.getControl());
           
	}
	
	// make a little green square
    private static Image getImages(Display display, int width, int colortype) {
        Image  image = null;
            PaletteData palette = new PaletteData(0xFF0000,0xFF00,0xFF);
            ImageData imageData = new ImageData(width, 16, 24, palette);

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < 16; y++) {
                    imageData.setPixel(x, y, colortype);
                }
            }
            ;
            image = new Image(display, imageData);
        return image;
    }
    
    
    private static class TestData
    {
        String className;
        String testCase;
        String assertions;
        int fail;
        TestData()
        {

        }

        public int getFail() {
        	return fail;
        }
        public String getTestCase() {
            return testCase;
        }

        public String getAssertions() {
            return assertions;
        }

        public void setTestCase(String testCase) {
            this.testCase = testCase;
        }

        public void setAssertions(String assertions) {
            this.assertions = assertions;
        }
        
        public void setFail(int fail) {
        	this.fail = fail;
        }
        public String getClassName(){
    		return this.className;
    	}
    	public void setClassName(String className){
    		this.className = className;
    	}

    }
    
    private static class TestSummary
    {

        String key;
        int value1;
        int value2;
        

        TestSummary()
        {

        }

        public String getKey() {
            return key;
        }

        public int getValue1() {
            return value1;
        }
        
        public int getValue2() {
            return value2;
        }
        
        
        public void setKey(String key) {
            this.key = key;
        }
        
        public void setValue1(int value1) {
            this.value1 = value1;
        }

        public void setValue2(int value2) {
            this.value2 = value2;
        }
    }

	

}
