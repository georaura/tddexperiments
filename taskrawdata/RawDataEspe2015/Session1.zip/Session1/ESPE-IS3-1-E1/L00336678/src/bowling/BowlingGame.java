package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames;
    private static int MAX_FRAMES = 10;
    private static int MAX_PINS = 10;
    private int frameCounter = 0;
    private int strikeCounter = 0;
    private static int ALL_STRIKE_SCORE = 300;
    private Frame bonus;

	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		//to be implemented
		
		getCurrentFrame();

        if (frame.isDone()) {

            // new bonus frame
            if(isLastFrame() && (frame.isSpare() || frame.isStrike())) {
                Frame bonus = new Frame();
                frames.add(bonus);
                frameCounter++;
                //return bonus;
            }

            frameCounter++;
            if (frameCounter == MAX_FRAMES || isBonusFrame()) {
                //return null;
            }

            frame = getCurrentFrame();
        }

        //return frame;
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
		/*scores[noAttempts++] = score;
        noOfPins -= score;
        if (score == MAX_PINS) {
            Frame.this.isStrike() = true;
            strikeCounter++;
        }*/
	}
	
	public int score(){
		//to be implemented
		int score;

        // first frame
        if (frameCounter == 0) {

            Frame curr = getCurrentFrame();
            return curr.score();

        } else {

            // score 300, strikes for all frames
            if (isLastFrame() && isAllStrikes()) {
                return ALL_STRIKE_SCORE;
            }

            Frame curr = getCurrentFrame();
            Frame prev = getPreviousFrame();

            // only add previous last frame to current score
            if (isBonusFrame()) {
                return prev.score() + curr.score();
            }

            score = curr.score();

            if(prev.isSpare()) {
                score += (prev.score() + curr.getFirstScore());
            }

            if(prev.isStrike()) {
                score += (prev.score() + curr.getFirstScore() +  curr.getSecondScore());
            }

        }

        return score;
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return false;
	}
	
	private Frame getPreviousFrame() {
        return frames.get(frameCounter-1);
    }

    private Frame getCurrentFrame() {
        return frames.get(frameCounter);
    }

    private boolean isAllStrikes() {
    return strikeCounter == MAX_FRAMES ;
    }

    private boolean isBonusFrame() {
        return frames.size() > MAX_FRAMES;
    }

    private boolean isLastFrame() {
        return frameCounter == MAX_FRAMES - 1;
    }
}
