package bowling;


public class Frame {
	private int firstThrow;
	private int secondThrow;
    private static int MAX_ATTEMPTS_PER_FRAME = 2;
    private int frameCounter = 0;
	private int[] scores = new int[MAX_ATTEMPTS_PER_FRAME];
    private int noOfPins = 10;
    private int noAttempts = 0;
    private boolean isStrike = false;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		this.secondThrow = secondThrow;
	}
	//getters
	 public int getThrow1() {
	        return firstThrow;
	    }

	    public int getThrow2() {
	        return secondThrow;
	    }
	//the score of a single frame
	public int score(){
		//to be implemented
		return scores[0] + scores[1];
	}
	
	public int getFirstScore() {
        return scores[0];
    }

    public int getSecondScore() {
        return scores[1];
    }
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		//to be implemented
		return noOfPins == 0 && noAttempts == MAX_ATTEMPTS_PER_FRAME && isStrike;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		//to be implemented
		return noOfPins == 0 && noAttempts == MAX_ATTEMPTS_PER_FRAME && !isStrike;
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		//to be implemented
		return noOfPins == 0 && noAttempts == MAX_ATTEMPTS_PER_FRAME && frameCounter==9;
	}

	//bonus throws
	public int bonus(){
		//to be implemented
		return getThrow1()+getThrow2();
	}
	
	public boolean isDone(){
		return noAttempts == MAX_ATTEMPTS_PER_FRAME;
	}
}
