package bowlingtest;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import bowling.BowlingGame;

public class TestBowlingScoreKeeper {
	
	private BowlingGame game;
    private static final int MAX_ATTEMPTS = 20;

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testScoreNoSpareOrStrike() {

        game.addFrame();

        int score  = game.score();
        Assert.assertEquals(8, score);

    }
	
	@Test
	public void testSpare() {

        game.addFrame();

        int score  = game.score();
        Assert.assertEquals(10, score);

    }
	
}
