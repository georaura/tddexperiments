package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		//to be implemented
		frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
			bonus =new Frame(firstThrow,secondThrow);
			
	}
	
	public int score(){
		//to be implemented
		if(frames.size()!=1)
		{
			if(isNextFrameBonus())
				return frames.get(frames.size()-2).score()+frames.get(frames.size()-1).getThrow1()+frames.get(frames.size()-1).getThrow2()+bonus.bonus();
			else
				return frames.get(frames.size()-2).score()+frames.get(frames.size()-1).getThrow1()+frames.get(frames.size()-1).getThrow2();
		}
		else
			return frames.get(frames.size()-1).getThrow1()+frames.get(frames.size()-1).getThrow2();
		
			
			/*int acum=0;
			 for(int i=0;i<frames.size();i++)
			{
				acum=acum+frames.get(i).score();
			}
			 if(frames.size()!=1)
				{
					if(isNextFrameBonus())
						return acum+bonus.bonus();
					else 
						return acum;
				}
				else
					return frames.get(frames.size()-1).getThrow1()+frames.get(frames.size()-1).getThrow2();*/
			//System.out.println(acum);
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		if(frames.get(frames.size()-1).isSpare()||frames.get(frames.size()-1).isStrike())
			return true;
		else
			return false;
	}
}
