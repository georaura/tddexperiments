package bowlingtest;
import static org.junit.Assert.*;

import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;

public class TestBowlingScoreKeeper {

	private static BowlingGame juego=new BowlingGame();
	
	@Test
	public void Frame1P1S4() {
		
		Frame frame=new Frame(1,4);
		juego.addFrame(frame);
        juego.setBonus(0, 0);
        assertEquals(5,juego.score());
	}
	@Test
	public void Frame2P4S5() {
		Frame frame=new Frame(4,5);
		juego.addFrame(frame);
        juego.setBonus(0, 0);
        assertEquals(14,juego.score());
	}
	
	@Test
	public void Frame3P6S4() {
		Frame frame=new Frame(6,4);
		juego.addFrame(frame);
        juego.setBonus(5, 5);
        assertEquals(29,juego.score());
	}
	
	@Test
	public void Frame4P5S5() {
		Frame frame=new Frame(5,5);
		juego.addFrame(frame);
        juego.setBonus(10, 0);
        assertEquals(49,juego.score());
	}
}
