package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		this.frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
	}
	
	public int score(){
		int scoreaux=0;
		for(int i=0;i<this.frames.size();i++){
			if (frames.get(i).isStrike() && i<(this.frames.size()-1)) {
				
					scoreaux += frames.get(i).score() + frames.get(i+1).score();
					
				
				
			} else if (frames.get(i).isSpare() && i<(this.frames.size()-1)) {
				
					scoreaux += frames.get(i).score() + frames.get(i+1).getThrow1();
					
			} else {
				scoreaux+=frames.get(i).score();
			}
			
		}
		return scoreaux;
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return false;
	}
}
