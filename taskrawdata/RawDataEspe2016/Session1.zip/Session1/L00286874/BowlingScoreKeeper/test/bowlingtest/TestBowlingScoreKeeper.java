package bowlingtest;

import static org.junit.Assert.*;

import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;

public class TestBowlingScoreKeeper {

	// Test para el score con la primera = 0 y la segunda = 3
	@Test
	public void testScore() {
		Frame g = new Frame();
		assertEquals(3, g.score());
		
		//fail("Not yet implemented");
	}
	
	// Test para el stike con la primera = 10
	@Test
		public void testStike() {
			Frame g = new Frame();
			assertEquals(true, g.isStrike());
			
			//fail("Not yet implemented");
		}
	
	// Test para el spare con la primera = 0 y segunda = 3
		@Test
			public void testSpare() {
				Frame g = new Frame();
				assertEquals(true, g.isSpare());
				
				//fail("Not yet implemented");
			}

}
