package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	private static final int TOTAL_FRAMES = 10;


	
	public BowlingGame(){
		
	
	}
	
	public void addFrame(Frame frame){
		//to be implemented
		
		frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
	}
	
	public int score(){
		//to be implemented
	    return 0;
	     	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return false;
	}
///////////////////////////////

	public boolean roll(int noOfPins) throws Exception
    {
        if (isGameOver())
            return false;

        if (!bonus.isRollValid(noOfPins))
            throw new Exception("Numero de pinos a�adidos (" + noOfPins +
                    ") son invalidos. " +
                    " pinos validos: " + bonus.validNumPinsForNextRoll());

        //bonus.addRoll(noOfPins);

        if (bonus.validNumPinsForNextRoll() == 0 && !isGameOver())
           // addFrame();

        return true;
        
		return false;
    }
	 private boolean isGameOver()
	    {
	        if (frames.size() == TOTAL_FRAMES && (bonus.validNumPinsForNextRoll() == 0))
	        {
	            return true;
	        }

	        return false;
	    }

	  
}
