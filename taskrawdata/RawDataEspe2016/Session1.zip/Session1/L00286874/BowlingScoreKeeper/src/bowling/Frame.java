package bowling;


public class Frame {
	private int firstThrow;
	private int secondThrow;
	//
	public int MAX_PIN_VALUE = 10;
    public static final int MIN_PIN_VALUE = 0;
	private int resto;
	//
	protected Frame nextFrame;
    protected Frame previousFrame;
    protected int frameScore;

    protected int index;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
		this.resto=0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		if(this.firstThrow<10)
			this.secondThrow = secondThrow;
		else
			this.secondThrow=0;
	}
	
	 //getters
	 public int getThrow1() {
	        return firstThrow;
	    }

	    public int getThrow2() {
	        return secondThrow;
	    }
	//the score of a single frame
	public int score(){
		//to be implemented
		firstThrow = 0;
		secondThrow = 3;		
		if(this.firstThrow>=0 && this.firstThrow<=10 && this.secondThrow>=0 && this.secondThrow<=10){
			resto = this.firstThrow+this.secondThrow;
			return resto;
		}
		else
			return 0;
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		//to be implemented
		firstThrow = 10;
		if (firstThrow == 10)
		{
			return true;
		}else
			return false;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		//to be implemented
		firstThrow = 0;
		secondThrow = 3;
		 resto = this.firstThrow + this.secondThrow;
		 if(resto==10 && this.firstThrow!=10)
				return true;
			else
		return false;
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		//to be implemented
		return false;
	}

	//bonus throws
	public int bonus(){
		//to be implemented
		return 0;
	}
//
	public boolean isRollValid(int numOfPins)
    {
        // Any kind of roll must yield a value between 0-10
        if (numOfPins < MIN_PIN_VALUE || numOfPins > MAX_PIN_VALUE)
            return false;

        if (validNumPinsForNextRoll() == 0)
            return false;

        if (numOfPins > validNumPinsForNextRoll())
            return false;

        return true;
    }
	public int validNumPinsForNextRoll()
    {
        int validNumPins = MAX_PIN_VALUE;

        return validNumPins;
    }
	public void setNextFrame(Frame nextFrame)
    {
        this.nextFrame = nextFrame;
    }

    public void setPreviousFrame(Frame previousFrame)
    {
        this.previousFrame = previousFrame;
    }

    public Frame getNextFrame()
    {
        return nextFrame;
    }
}
	