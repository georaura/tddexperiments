package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private static int max_frames = 10;//MAX_FRAMES 
    private int cont_frame = 0; //frameCounter
    private int cont_strike = 0; //strikeCounter
    private static final int ALL_STRIKE_SCORE = 300;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		//to be implemented
        frames = new ArrayList<Frame>(max_frames);

        for (int i = 0; i < max_frames; i++) {
            frames.add(new Frame());
        }
	}

	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
	}
	
	public int score(){
		int score;

        // first frame
        if (cont_frame == 0) {

            Frame curr = getCurrentFrame();
            return curr.score();

        } else {

            // score 300, strikes for all frames
            if (isLastFrame() && isAllStrikes()) {
                return ALL_STRIKE_SCORE;
            }

            Frame curr = getCurrentFrame();
            Frame prev = getPreviousFrame();

            // only add previous last frame to current score
            if (isBonusFrame()) {
                return prev.score() + curr.score();
            }

            score = curr.score();

        }

        return score;
		
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return false;
	}
    private Frame getPreviousFrame() {
        return frames.get(cont_frame-1);
    }

    private Frame getCurrentFrame() {
        return frames.get(cont_frame);
    }

    private boolean isAllStrikes() {
    return cont_strike == max_frames ;
}

    private boolean isBonusFrame() {
        return frames.size() > max_frames;
    }

    private boolean isLastFrame() {
        return cont_frame == max_frames - 1;
    }

    
}
