package bowlingtest;
import bowling.Frame;


import static org.junit.Assert.*;

import org.junit.Test;

public class TestBowlingScoreKeeper {

	@Test
	public void test() {
		//fail("Not yet implemented");
		Frame obj1 = new Frame(2,5);
		obj1.getThrow1();
		obj1.getThrow2();
		assertEquals(0,obj1.score());
		
		/*Frame obj2 = new Frame(10,0);
		obj1.getThrow1();
		obj1.getThrow2();
		assertEquals(0,obj1.score());
		*/
	
		
		

	}
	


}
