package marsrovertest;

import static org.junit.Assert.*;
import marsrover.MarsRover;

import org.junit.Test;


public class TestRover {
	private MarsRover r;

	@Test
	public void createPlanetyObstaculos() {
		r=new MarsRover(100, 100, "(3,5) (8,4)");
	}
	@Test
	public void landig() {
		r=new MarsRover(100, 100, "");
		assertEquals("0,0,N",r.executeCommand(""));
	}
	@Test
	public void turningLeft() {
		r=new MarsRover(100, 100, "");
		assertEquals("(0,0,E)",r.executeCommand("l"));
	}
	@Test
	public void movingForward() {
		r=new MarsRover(100, 100, "");
		r.setX(7);
		r.setY(6);
		r.setFacing('N');
		assertEquals("(7,7,N)",r.executeCommand("f"));
	}
	@Test
	public void movingAndTurningCombined (){
		r=new MarsRover(100, 100, "");
		r.setX(0);
		r.setY(0);
		r.setFacing('N');
		assertEquals("(1,3,E)",r.executeCommand("frff"));
	}
	
}
