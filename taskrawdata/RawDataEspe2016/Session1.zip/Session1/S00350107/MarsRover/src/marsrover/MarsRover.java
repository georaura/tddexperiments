package marsrover;

public class MarsRover {
	
	private int xTam;
	private int yTam;
	private int x;
	private int y;
	private String obstacles;
	private char [] coordenadas;
	private char direction;
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	 this.x=0;
	 this.y=0;
	 this.direction='N';
	 this.obstacles=obstacles;
	 this.xTam=x;
	 this.yTam=y;
	 coordenadas=new char[obstacles.length()];
	int j=0;
	 for(int i=0;i<obstacles.length();i++)
	{
		if(obstacles.charAt(i)>47&&obstacles.charAt(i)<49)
		{
			coordenadas[j]=obstacles.charAt(i);
			System.out.println(obstacles.charAt(i));
			j++;
		}
	}
	
		 
		
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		String aux=null;
		boolean var=false;
		char c;
		for(int i=0;i<command.length();i++)
		{
			if(command.charAt(i)=='f'||command.charAt(i)=='b'||command.charAt(i)=='l'|command.charAt(i)=='r')
				var=true;
		}
		
		if(!var)
		{
			this.x=0;
			this.y=0;
			this.direction='N';
			aux=("0,0,N");
		}
		else
		{
			for(int i=0;i<command.length();i++)
			{
				c=command.charAt(i);
				if(c=='f')
				{
					direction='N';
					y++;
										
				}else
					if(c=='b')
					{
						direction='S';
						y--;
					}else
						if(c=='l')
						{
							direction='E';
							x--;
						}else
						{
							direction='O';
							x++;
						}
				
				aux="("+String.valueOf(x)+","+String.valueOf(y)+","+String.valueOf(direction)+")";
			}
			
		}
		
		
		return aux;
		
	}
	
	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		this.x=x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
	this.y=y;
	}	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		this.direction=direction;
	}
	
}

