package marsrover;


public class prin {

	public static void main(String[] args) {
		MarsRover r;
		r=new MarsRover(100, 100, "");
		r.setX(0);
		r.setY(0);
		r.setFacing('S');
		System.out.println(r.executeCommand("frff"));

	}

}
