package marsrovertest;

import static org.junit.Assert.*;
import marsrover.MarsRover;

import org.junit.Ignore;
import org.junit.Test;

public class TestRover {

	@Ignore
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void primermovimiento() {
		MarsRover obj = new MarsRover(100, 100, "");
		assertEquals("(2,2,E)", obj.executeCommand("ffrff"));
	}
	
	@Test
	public void MovimientoPorBorde() {
		MarsRover obj = new MarsRover(100, 100, "");
		assertEquals("(2,2,E)", obj.executeCommand("bbffrbff"));
	}
	
	@Test
	public void pruebaEjemplo1MovimientoCorrecto() {
		MarsRover obj = new MarsRover(3, 3, "");
		assertEquals("(1,2,E)", obj.executeCommand("ffrf"));
	}
	
	@Test
	public void pruebaEjemplo2Obstaculo() {
		MarsRover obj = new MarsRover(3, 3, "(0,2)");
		assertEquals("(1,1,E)(0,2)", obj.executeCommand("ffrf"));
	}
	
	@Test
	public void pruebaEjemploVariosObstaculos() {
		MarsRover obj = new MarsRover(3, 3, "(0,2)(2,1)");
		assertEquals("(1,2,E)(0,2)(2,1)(0,2)", obj.executeCommand("ffrfflfrfbb"));
	}
}
