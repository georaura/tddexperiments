package marsrover;

public class MarsRover {
	private int posx;
	private int posy;
	private char facing;
	private String obstacle;
	private int maxX;
	private int maxY;
	
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		setX(0);
		setY(0);
		setFacing('N');
		this.maxX = x-1;
		this.maxY = y-1;
		this.obstacle = obstacles;
	}
	
	public String executeCommand(String command){
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		int count = 0;
		String obstaculoAnalizado = "";
		String obstaculoEvitado = "";
		
		while(count<command.length()){
			if(command.charAt(count)=='f'){
				if(getFacing()=='N'){
					if(getY()!= maxY){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+getX()+","+(getY()+1)+")")){
									setY(getY()-1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado;
								}
							}	
						}
						setY(getY()+1);
					}
				}
				else if(getFacing()=='S'){
					if(getY()!= 0){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+getX()+","+(getY()-1)+")")){
									setY(getY()+1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setY(getY()-1);
					}
				}
				else if(getFacing()=='E'){
					if(getX()!= maxX){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+(getX()+1)+","+getY()+")")){
									setX(getX()-1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setX(getX()+1);
					}
				}
				else{
					if(getX()!= 0){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+(getX()-1)+","+(getY()+1)+")")){
									setX(getX()+1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setX(getX()-1);
					}
				}
			}
			else if(command.charAt(count)=='b'){
				if(getFacing()=='N'){
					if(getY()!= 0){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+getX()+","+(getY()-1)+")")){
									setY(getY()+1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setY(getY()-1);
					}
				}
				else if(getFacing()=='S'){
					if(getY()!= maxY){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+getX()+","+(getY()+1)+")")){
									setY(getY()-1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setY(getY()+1);
					}
				}
				else if(getFacing()=='E'){
					if(getX()!= 0){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+(getX()-1)+","+getY()+")")){
									setX(getX()+1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setX(getX()-1);
					}
				}
				else{
					if(getX()!= maxX){
						if(this.obstacle != null && !this.obstacle.equals("")){
							for(int i=0; i<this.obstacle.length(); i=i+5){
								obstaculoAnalizado = this.obstacle.substring(i, i+5);
								if(obstaculoAnalizado.equals("("+(getX()+1)+","+getY()+")")){
									setX(getX()-1);
									obstaculoEvitado = obstaculoEvitado+obstaculoAnalizado; 
								}
							}	
						}
						setX(getX()+1);
					}
				}
			}
			else if(command.charAt(count)=='r'){
				if(getFacing()=='N') setFacing('E');
				else if(getFacing()=='E') setFacing('S');
				else if(getFacing()=='S') setFacing('W');
				else setFacing('N');
			} 
			else{
				if(getFacing()=='N') setFacing('W');
				else if(getFacing()=='W') setFacing('S');
				else if(getFacing()=='S') setFacing('E');
				else setFacing('N');
			}
			count++;
		}
		if(obstaculoEvitado.equals("")) return "("+getX()+","+getY()+","+getFacing()+")";
		else return "("+getX()+","+getY()+","+getFacing()+")"+obstaculoEvitado;
	}
	
	//set the Rover in column X
	public void setX(int x) {
		this.posx = x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		this.posy = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		this.facing = direction;
	}
	
	public char getFacing(){
		return this.facing;
	}
	
	public int getX(){
		return this.posx;
	}
	
	public int getY(){
		return this.posy;
	}
	
}

