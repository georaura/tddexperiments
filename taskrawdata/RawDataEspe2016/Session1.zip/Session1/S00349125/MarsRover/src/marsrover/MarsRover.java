package marsrover;

import java.util.StringTokenizer;

public class MarsRover {
	private int x;
	private int y;
	private char facing;
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces.
	 *
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8)
	 */
	}

	public String executeCommand(String command){

		int a=0,b=0;
		char fac='N';
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example:
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.

		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		String coordenada="";
		if(command.equals(""))
		{
			setX(0);
			setY(0);
			setFacing('N');
		}
		if(command.equals("r"))
			fac='E';
		if(command.equals("l"))
			fac='W';
		if(command.equals("b"))
			a=x-1;
		if(command.equals("f"))
			b=y+1;
		if(command.length()>2)
		{
			for(int i=0;i<command.length();i++)
			{
				if(command.charAt(i)=='r')
					fac='E';
				if(command.charAt(i)=='l')
					fac='W';
				if(command.charAt(i)=='b'&&fac=='N')
					a=a-1;
				if(command.charAt(i)=='f'&&fac=='N')
					b=b+1;
				if(command.charAt(i)=='b'&&fac=='E')
					b=b+1;
				if(command.charAt(i)=='f'&&fac=='E')
					a=a+1;
				if(command.charAt(i)=='b'&&fac=='W')
					b=b-1;
				if(command.charAt(i)=='f'&&fac=='W')
					a=a-1;
	       }
		}
		coordenada=String.valueOf(a+","+b+","+fac);
		return coordenada;
	}

	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		this.x=x;
	}

	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
		this.y=y;
	}

	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		facing=direction;
	}



}

