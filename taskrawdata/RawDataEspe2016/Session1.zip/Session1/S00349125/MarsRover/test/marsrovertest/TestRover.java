package marsrovertest;
import marsrover.MarsRover;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestRover {

	@Test
	public void test() {
		//fail("Not yet implemented");
		MarsRover obj=new MarsRover(100,100,"");
		assertEquals("0,0,N",obj.executeCommand(""));
		assertEquals("0,0,E",obj.executeCommand("r"));
		assertEquals("0,0,W",obj.executeCommand("l"));
		assertEquals("0,1,N",obj.executeCommand("f"));
		assertEquals("-1,0,N",obj.executeCommand("b"));
		assertEquals("2,2,E",obj.executeCommand("ffrff"));
	}

}
