package marsrover;

public class MarsRover {
	
	 
	 private int[][] matriz;
	 int point1,point2;
	 String facing=null;
	 String posFinal=null;
	 char d;
	 
	 
	  public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		
		  matriz=new int[x][y];
		  
		  
		  for(int f=0;f<x;f++) {
              for(int c=0;c<y;c++) {
                  matriz[f][c]=0;
              }
          }
		  point1=0;
		  point2=0;
		  
	}
	 
	public String executeCommand(String command){
		
		String posFinal=null;
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		
		if(command.equals("f")){
			point2+=1;
			d='N';
			posFinal="("+String.valueOf(point1)+","+String.valueOf(point2)+")"+d;
			
		}
         if (command.equals("b")){
        	  point2-=1;
        	  d='S';
        	  posFinal="("+String.valueOf(point1)+","+String.valueOf(point2)+")"+d;
        	  
          }  
         if (command.equals("l")){
       	  point1-=1;
       	d='W';
       	  posFinal="("+String.valueOf(point1)+","+String.valueOf(point2)+")"+d;
       	
 		
         }
         
         if (command.equals("r")){
          	  point1+=1;
          	d='E';
          	  posFinal="("+String.valueOf(point1)+","+String.valueOf(point2)+")"+d;
          	}
		return posFinal;
		
		/*if(command.equals("")){
			for (char commands : command.toCharArray()) {
	            if (!receiveSingleCommand(commands)) {
	            	 posFinal="("+String.valueOf(point1)+","+String.valueOf(point2)+")"+d;
	            	 return posFinal;
	            }
	               break;
	         }
			return posFinal;
		}*/
         
         
	}
	
	
		
	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		x=point1;
		
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
		y=point2;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		
        direction=d;
	}

	 public boolean receiveSingleCommand(char command)throws Exception  {
	        switch(Character.toUpperCase(command)) {
	            case 'f':
	            	point2+=1;
	    			d='N';
	                return true;
	            case 'b':
	            	point2-=1;
	          	  d='S';
	                return true;
	            case 'l':
	            	 point1-=1;
	                	d='W';
	                return true;
	            case 'r':
	            	 point1+=1;
	               	d='E';
	                return true;
	            default:
	                throw new Exception("Command " + command + " no encontrado.");
	        }
	       }
}

