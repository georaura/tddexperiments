package marsrovertest;
import  marsrover.MarsRover;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestRover {
	MarsRover rover;
	
	@Before
	 public void beforeRoverTest() {
		rover=new MarsRover(3,3,"(2,1)");
    }

		
	@Test
	public void test() {
		//fail("Not yet implemented");
		
		assertEquals("(0,1)N",rover.executeCommand("f"));
		
		
		
		
	}

}
