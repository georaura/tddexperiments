package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		if(frames.size()<=10)
			frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		if(this.isNextFrameBonus() && frames.get(9).isSpare()){
			bonus=new Frame(firstThrow,0);
		}
		else{
			if(this.isNextFrameBonus() && frames.get(9).isStrike()){
				bonus=new Frame(10+firstThrow,secondThrow);
			}
		}
	}
	
	public int score(){
		int totalscore=0;
		int auxS=0;
		int auxSp=0;
		for(int i=0;i<10;i++){
			
			if(frames.get(i).isSpare() && !this.isNextFrameBonus()){
				auxSp=frames.get(i).score()+frames.get(i+1).getThrow1();
				totalscore+=auxSp;
			}
			else{
			if(frames.get(i).isStrike() && !frames.get(i+1).isStrike() && !this.isNextFrameBonus()){
				auxS=frames.get(i).score()+frames.get(i+1).score();
				totalscore+=auxS;
			}
			else{
				if(frames.get(i).isStrike() && frames.get(i+1).isStrike() && !this.isNextFrameBonus() ){
					auxS=frames.get(i).score()+frames.get(i+1).score()+frames.get(i+2).getThrow1();
					totalscore+=auxS;
				}
				else
				totalscore+=frames.get(i).score();
			}
			}
		}
		if(this.isNextFrameBonus())
			totalscore+=bonus.score();
		return totalscore;
	}
	
	public boolean isNextFrameBonus(){
		if(frames.get(9).isSpare() || frames.get(9).isStrike())
			return true;
		else
			return false;
	}
}
