package bowling;


public class Frame {
	private int firstThrow;
	private int secondThrow;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		if(this.firstThrow<10)
			this.secondThrow = secondThrow;
		else
			this.secondThrow=0;
	}
	//getters
	 public int getThrow1() {
	        return firstThrow;
	    }

	    public int getThrow2() {
	        return secondThrow;
	    }
	    
	    
	//the score of a single frame
	public int score(){
		if(this.firstThrow>=0 && this.firstThrow<=10 && this.secondThrow>=0 && this.secondThrow<=10)
			return (this.firstThrow+this.secondThrow);
		else
			return 0;
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		if(this.firstThrow==10 && this.secondThrow==0)
			return true;
		else
			return false;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		if((this.firstThrow + this.secondThrow==10) && this.firstThrow!=10)
			return true;
		else
		return false;
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		
		return false;
	}

	//bonus throws
	public int bonus(){
		
		return 0;
	}


}
