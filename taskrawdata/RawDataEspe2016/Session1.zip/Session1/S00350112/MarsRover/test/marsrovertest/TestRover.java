package marsrovertest;

import static org.junit.Assert.*;
import marsrover.MarsRover;

import org.junit.Before;
import org.junit.Test;

public class TestRover {

	MarsRover r;
	
	@Before
	public void in()
	{
		 r = new MarsRover(10,10,"5,2,2,3");
		 r.setFacing('N');
		 r.setX(0);
		 r.setY(0);
	}
	@Test
	public void inicio()
	{
		MarsRover y = new MarsRover(10,10,"5,2,2,3");
	}
	@Test
	public void testFacing() {
		//Debe dar una excepcion
		r.setFacing('O');
	}
	@Test
	public void testCommand() {
		assertEquals("(0,1)",r.executeCommand("b"));
	}
	

}
