package marsrover;

public class MarsRover {
	
	private int x, x2;
	private int y, y2;
	private char direction;
	private Integer[][] grid;
	
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		x2=x;
		y2=y;
		grid = new Integer[x][y];
		
		for(int i=0;i<x;i++)
		{
			for(int j=0;j<y;j++)
			{
				grid[i][j]=1;
				//System.out.print(grid[i][j]);
			}
			//System.out.println();
		}
		
		String[] a;
		String sep=",";
		//obstacles=obstacles.replaceAll("(", sep);
		//obstacles=obstacles.replaceAll(")", sep);
		a=obstacles.split(sep);
		
		for(int i=0; i<a.length; i+=2)
		{
			grid[Integer.parseInt(a[i])-1][Integer.parseInt(a[i+1])-1] = 0;
		}
		
		for(int i=0;i<x;i++)
		{
			for(int j=0;j<y;j++)
			{
				System.out.print(grid[j][i]);
			}
			System.out.println();
		}
		
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		String coord="";
		
		for(int i=0;i<command.length();i++)
		{
			if(this.direction=='N')
			{
				if(command.charAt(i)=='f') coord=coord.concat("(0,"+(y2-1)+")");
				else if(command.charAt(i)=='b') coord=coord.concat("(0,1)");
				else if(command.charAt(i)=='l') coord=coord.concat("(0,"+(x2-1)+")");
				else if(command.charAt(i)=='r') coord=coord.concat("(1,0)");
			}
			
			else if(this.direction=='S')
			{
				if(command.charAt(i)=='f') coord=coord.concat("(0,1)");
				else if(command.charAt(i)=='b') coord=coord.concat("(0,"+(y2-1)+")");
				else if(command.charAt(i)=='l') coord=coord.concat("(1,0)");
				else if(command.charAt(i)=='r') coord=coord.concat("(0,"+(x2-1)+")");
			}
			
			else if(this.direction=='W')
			{
				if(command.charAt(i)=='l') coord=coord.concat("(0,1)");
				else if(command.charAt(i)=='r') coord=coord.concat("(0,"+(y2-1)+")");
				else if(command.charAt(i)=='b') coord=coord.concat("(1,0)");
				else if(command.charAt(i)=='f') coord=coord.concat("(0,"+(x2-1)+")");
			}
			
			else if(this.direction=='E')
			{
				if(command.charAt(i)=='r') coord=coord.concat("(0,1)");
				else if(command.charAt(i)=='l') coord=coord.concat("(0,"+(y2-1)+")");
				else if(command.charAt(i)=='f') coord=coord.concat("(1,0)");
				else if(command.charAt(i)=='b') coord=coord.concat("(0,"+(x2-1)+")");
			}
		}
		
		return coord;
	}
	
	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		this.x = x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
		this.y = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		if(direction=='N'||direction=='S'||direction=='E'||direction=='W')
		{
			this.direction = direction;
		}
		else
			throw new IllegalArgumentException("Not allowed");
	}
	
}

