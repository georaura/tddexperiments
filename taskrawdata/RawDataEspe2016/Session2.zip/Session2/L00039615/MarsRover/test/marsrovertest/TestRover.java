package marsrovertest;

import static org.junit.Assert.*;
import marsrover.MarsRover;

import org.junit.Ignore;
import org.junit.Test;

public class TestRover {

	@Test
	public void testplanetgrid() {
		MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
		int grid[][]=new int[5][5];
		assertEquals(grid, a.getGrid());
	}
	
	@Test
	public void testplanetgridconobstaculos() {
		MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
		assertEquals(false,a.getObst().containsValue(5));
		assertEquals(false,a.getObst().containsValue(4));
		assertEquals(false,a.getObst().containsKey(3));
		assertEquals(false,a.getObst().containsKey(2));
	}
	
	@Ignore
	public void testplanetcommand() {
		MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
		assertEquals("(1,0,S)", a.executeCommand("lrfbb"));
	}

    @Test 
    public void MoverFrenteFRegresa1() throws Exception {
    	MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
        a.executeCommand("f");
        assertEquals(1,a.getPosroverx());
    }
    @Test 
    public void MoverAtrasBRegresaN() throws Exception {
    	MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
        a.executeCommand("b");
        assertEquals('N',a.getFdir());
    }
    @Test 
    public void MoverAladoOesteLRegresaW() throws Exception {
    	MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
        a.executeCommand("l");
        assertEquals('W',a.getFdir());
    }
    @Test 
    public void MoverAladoEsteRRegresaE() throws Exception {
    	MarsRover a=new MarsRover(5,5,"(3,5)(2,4)");
        a.executeCommand("r");
        assertEquals('E',a.getFdir());
    }
    @Test 
    public void MoverCommandoffrfRegresa12E() throws Exception {
    	MarsRover a=new MarsRover(3,3,"");
        assertEquals("(1,2,E)",a.executeCommand("ffrf"));
    }
    
    @Test 
    public void MoverCommandoffrfRegresa11E02() throws Exception {
    	MarsRover a=new MarsRover(3,3,"(0,2)");
        assertEquals("(1,1,E)(0,2)",a.executeCommand("ffrf"));
    }

}
