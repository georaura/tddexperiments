package marsrover;

import java.util.LinkedHashMap;
import java.util.Map;

public class MarsRover {
	private int grid[][];
	private int posroverx=0, posrovery=0;
	private char fdir='N';
	private Map<Integer, Integer> obst = new LinkedHashMap<Integer, Integer>();
	public MarsRover(int x, int y, String obstacles){
		grid=new int[x][y];
		int posxobst=0, posyobst=0;
		for(int i=0;i<obstacles.length();i++){
			if((obstacles.charAt(i)<=57 && obstacles.charAt(i)>=48) && obstacles.charAt(i-1)=='(')
				posxobst=obstacles.charAt(i);
			else
				if(obstacles.charAt(i)==')' && (obstacles.charAt(i-1)<=57 && obstacles.charAt(i-1)>=48) && i>=5){
					posyobst=obstacles.charAt(i);
					obst.put(posxobst, posyobst);
					posxobst=0; posyobst=0;
				}
		}				
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	}
	

	public Map<Integer, Integer> getObst() {
		return obst;
	}

	public String executeCommand(String command){
		for(int i=0;i<command.length();i++){
			if(command.charAt(i)=='f' && this.fdir=='N')
				setY(this.posrovery+1);
			else
				if(command.charAt(i)=='f' && this.fdir=='S')
					setY(this.posrovery-1);
				else
					if(command.charAt(i)=='f' && this.fdir=='W')
						setX(this.posroverx-1);
					else
						if(command.charAt(i)=='f' && this.fdir=='E')
							setX(this.posroverx+1);
						else
							if(command.charAt(i)=='b' && this.fdir=='N')
								setY(this.posrovery-1);
							else
								if(command.charAt(i)=='b' && this.fdir=='S')
									setY(this.posrovery+1);
								else
									if(command.charAt(i)=='b' && this.fdir=='W')
										setX(this.posroverx-1);
									else
										if(command.charAt(i)=='b' && this.fdir=='E')
											setX(this.posroverx+1);
										else
											if(command.charAt(i)=='l' && this.fdir=='N')
												setFacing('W');
												else
													if(command.charAt(i)=='l' && this.fdir=='E')
														setFacing('N');
													else
														if(command.charAt(i)=='l' && this.fdir=='S')
															setFacing('E');
														else
															if(command.charAt(i)=='r' && this.fdir=='N')
																setFacing('E');
															else
																if(command.charAt(i)=='r' && this.fdir=='W')
																	setFacing('N');
																	else
																		if(command.charAt(i)=='l' && this.fdir=='S')
																			setFacing('W');
		}
								
		String pos=""+"("+this.posrovery+","+this.posroverx+","+this.fdir+")";		
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */	
		return pos;
	}
	
	public int getPosroverx() {
		return posroverx;
	}


	public int getPosrovery() {
		return posrovery;
	}


	public char getFdir() {
		return fdir;
	}


	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		this.posroverx=x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
		this.posroverx=y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		this.fdir=direction;
	}

	public int[][] getGrid() {
		return grid;
	}
	
	
}

