package bowlingtest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;

public class TestBowlingScoreKeeper {
	
	@Test
	public void frame1knocks10en1Tiro() {
		Frame f = new Frame(10,0);
		assertEquals(10, f.getThrow1()+f.getThrow2());
	}
	
	@Test
	public void frame1knocks10en2Tiros(){
		Frame f = new Frame(7,3);
		assertEquals(10, f.getThrow1()+f.getThrow2());
	}
	
	@Test
	public void frame1NoTiraTodos(){
		Frame f = new Frame(5,3);
		assertEquals(8,f.getThrow1()+f.getThrow2());
	}
	
	@Test
	public void scoreSinStrikesNiSpares(){
		Frame f = new Frame(1,8);
		assertEquals(9,f.score());
	}
	
	@Test
	public void totalFramesEs10(){
		BowlingGame g = new BowlingGame();
		for(int i=0;i<10;i++)
	    g.addFrame(new Frame());
		assertEquals(10,g.totalFrames());
	}
	
	@Test
	public void segundoFrameTira5(){
		Frame f1 = new Frame(0,0);
		Frame f2 = new Frame(3,2);
		assertEquals(5,f2.getThrow1()+f2.getThrow2());
	}
	
	@Test
	public void primerFrameStrike(){
		Frame f1 = new Frame(10,0);
		Frame f2 = new Frame(3,2);
		assertTrue(f1.isStrike());
	}
	
	@Test
	public void primerFrameStrikeBonus1(){
		Frame f1 = new Frame(10,0);
		Frame f2 = new Frame(3,2);
		f1.setB1(f2.getThrow1()); f1.setB2(f2.getThrow2());
		assertEquals(5,f1.bonus());
	}
	
	@Test
	public void primerFrameSpare(){
		Frame f1 = new Frame(2,8);
		Frame f2 = new Frame(3,2);
		assertTrue(f1.isSpare());
	}
	
	@Test
	public void primerFrameSpareBonus7(){
		Frame f1 = new Frame(6,4);
		Frame f2 = new Frame(7,1);
		f1.setB1(f2.getThrow1()); f1.setB2(f2.getThrow2());
		assertEquals(7,f1.bonus());
	}
	
	@Test
	public void scoreTotal2FrameConBonus5es20(){
		Frame f1 = new Frame(5,4);
		Frame f2 = new Frame(7,3);
		Frame f3 = new Frame(1,0);
		f2.setB1(f1.getThrow1()+f3.getThrow1()+f1.getThrow2()); 
		f2.setB2(f3.getThrow2());
		assertEquals(20,f2.score()+f2.bonus());
	}

}
