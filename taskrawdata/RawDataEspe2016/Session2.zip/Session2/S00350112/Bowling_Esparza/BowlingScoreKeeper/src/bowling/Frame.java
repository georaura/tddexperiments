package bowling;


public class Frame {
	private int firstThrow;

	private int secondThrow;
	private int b1;
	private int b2;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		this.secondThrow = secondThrow;
	}
	//getters
	 public int getThrow1() {
	        return firstThrow;
	    }

	    public int getThrow2() {
	        return secondThrow;
	    }
		
	public void setB1(int b1) {
			this.b1 = b1;
		}

		public void setB2(int b2) {
			this.b2 = b2;
		}

	//the score of a single frame
	public int score(){
		return this.firstThrow+this.secondThrow;
		//return 0;
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		//to be implemented
		if(firstThrow==10)
			return true;
		else return false;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		//to be implemented
		if(firstThrow!=10)
			return true;
		else return false;
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		//to be implemented
		return false;
	}

	//bonus throws
	public int bonus(){
		//to be implemented
		if(isStrike())
			return b1+b2;
		else if(isSpare()) return b1;
		else return 0;
	}


}
