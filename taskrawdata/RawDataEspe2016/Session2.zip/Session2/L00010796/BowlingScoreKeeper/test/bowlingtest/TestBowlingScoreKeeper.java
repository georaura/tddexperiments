package bowlingtest;

import static org.junit.Assert.*;
import bowling.*;

//import org.junit.Ignore;
import org.junit.Test;

public class TestBowlingScoreKeeper {


	@Test
	public void testFrame2_4Scores6() {
		Frame a=new Frame(2,4);
		assertEquals(6,a.score());
	}
	
	@Test
	public void testFrame2_14Scores0() {
		Frame a=new Frame(2,14);
		assertEquals(0,a.score());
	}
	@Test
	public void testFrameminus1_10Scores0() {
		Frame a=new Frame(-1,10);
		assertEquals(0,a.score());
	}
	@Test
	public void testFramemax10() {
		Frame a=new Frame(1,10);
		BowlingGame b=new BowlingGame();
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
		b.addFrame(a);
	}
	
	@Test
	public void testGameScore81() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(1,5));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(81,b.score());
	}
	
	@Test
	public void testisStrike_10_0() {
		Frame a=new Frame(10,0);
		assertEquals(true,a.isStrike());
	}
	
	@Test
	public void testisnotStrike_10_2() {
		Frame a=new Frame(10,2);
		assertEquals(10,a.getThrow1());
		assertEquals(0,a.getThrow2());
		assertEquals(true,a.isStrike());
	}
	
	@Test
	public void testGameScore94() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(94,b.score());
	}
	
	@Test
	public void testisSpare_4_6() {
		Frame a=new Frame(4,6);
		assertEquals(4,a.getThrow1());
		assertEquals(6,a.getThrow2());
		assertEquals(true,a.isSpare());
	}
	
	@Test
	public void testisnotSpare_3_6() {
		Frame a=new Frame(3,6);
		assertEquals(3,a.getThrow1());
		assertEquals(6,a.getThrow2());
		assertEquals(false,a.isSpare());
	}
	
	@Test
	public void testGameScore88() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(1,9));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(88,b.score());
	}
	
	@Test
	public void testGameScore103() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(4,6));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(103,b.score());
	}
	
	@Test
	public void testGameScore112() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(112,b.score());
	}
	
	@Test
	public void testGameScore98() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(8,2));
		b.addFrame(new Frame(5,5));
		b.addFrame(new Frame(7,2));
		b.addFrame(new Frame(3,6));
		b.addFrame(new Frame(4,4));
		b.addFrame(new Frame(5,3));
		b.addFrame(new Frame(3,3));
		b.addFrame(new Frame(4,5));
		b.addFrame(new Frame(8,1));
		b.addFrame(new Frame(2,6));
		assertEquals(98,b.score());
	}
	
	@Test
	public void testBestGameScore300() {
		BowlingGame b=new BowlingGame();
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,0));
		b.addFrame(new Frame(10,10));
		assertEquals(300,b.score());
	}

}
