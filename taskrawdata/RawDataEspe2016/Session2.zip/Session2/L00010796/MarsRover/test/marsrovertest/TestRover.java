package marsrovertest;

import static org.junit.Assert.*;
import marsrover.MarsRover;

import org.junit.Test;

public class TestRover {

	@Test
    public void testComandoError(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(0,0,N)", Rover.executeCommand("(i.e.:\"\")"));
	}
	@Test
    public void testComandoVacio(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(0,0,N)", Rover.executeCommand(""));
	}
	@Test
    public void testComandoRenN(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(0,0,E)", Rover.executeCommand("R"));
	}
	@Test
    public void testComandoLenE(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('E');
		assertEquals("(0,0,N)", Rover.executeCommand("L"));
	}
	@Test
    public void testComandoRenE(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('E');
		assertEquals("(0,0,S)", Rover.executeCommand("R"));
	}
	@Test
    public void testComandoLenS(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('S');
		assertEquals("(0,0,E)", Rover.executeCommand("L"));
	}
	@Test
    public void testComandoRenS(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('S');
		assertEquals("(0,0,W)", Rover.executeCommand("R"));
	}
	@Test
    public void testComandoLenW(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('W');
		assertEquals("(0,0,S)", Rover.executeCommand("L"));
	}
	@Test
    public void testComandoRenW(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('W');
		assertEquals("(0,0,N)", Rover.executeCommand("R"));
	}
	@Test
    public void testComandoLenN(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(0,0,W)", Rover.executeCommand("L"));
	}
	@Test
    public void testComandofPosicion76n(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(7);
		Rover.setY(6);
		Rover.setFacing('N');
		assertEquals("(7,7,N)", Rover.executeCommand("f"));
	}
	@Test
    public void testComandobPosicion76n(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(7);
		Rover.setY(6);
		Rover.setFacing('N');
		assertEquals("(7,5,N)", Rover.executeCommand("b"));
	}
	@Test
    public void testComandofPosicion76s(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(7);
		Rover.setY(6);
		Rover.setFacing('S');
		assertEquals("(7,5,S)", Rover.executeCommand("f"));
	}
	@Test
    public void testComandobPosicion76s(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(7);
		Rover.setY(6);
		Rover.setFacing('S');
		assertEquals("(7,7,S)", Rover.executeCommand("b"));
	}
	@Test
    public void testComandoFPosicion58e(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(5);
		Rover.setY(8);
		Rover.setFacing('E');
		assertEquals("(6,8,E)", Rover.executeCommand("F"));
	}
	@Test
    public void testComandobPosicion58e(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(5);
		Rover.setY(8);
		Rover.setFacing('E');
		assertEquals("(4,8,E)", Rover.executeCommand("b"));
	}
	@Test
    public void testComandoFPosicion58W(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(5);
		Rover.setY(8);
		Rover.setFacing('W');
		assertEquals("(4,8,W)", Rover.executeCommand("F"));
	}
	@Test
    public void testComandobPosicion58W(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setX(5);
		Rover.setY(8);
		Rover.setFacing('W');
		assertEquals("(6,8,W)", Rover.executeCommand("b"));
	}
	@Test
    public void testComandoffrffPosicionInicio(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(2,2,E)", Rover.executeCommand("ffrff"));
	}
	@Test
    public void testComandobPosicionInicio(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		assertEquals("(0,99,N)", Rover.executeCommand("b"));
	}
	@Test
    public void testComandobPosicionInicioDirecionW(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setFacing('W');
		assertEquals("(99,0,W)", Rover.executeCommand("f"));
	}
	@Test
    public void testComandofPosicionMaxYdireccionN(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setY(99);
		assertEquals("(0,0,N)", Rover.executeCommand("f"));
	}
	@Test
    public void testComandofPosicionMaxYdireccionW(){
		
		MarsRover Rover = new MarsRover (100,100, "(5,5) (7,8)");
		Rover.setY(99);
		Rover.setFacing('W');
		assertEquals("(99,99,W)", Rover.executeCommand("f"));
	}
	
}
