package marsrover;

public class MarsRover {
	int Xaux;
	int Yaux;
	char Position ;
	int TamanioX;
	int TamanioY;
	public MarsRover(int x, int y, String obstacles){
		Xaux=0;
		Yaux=0;
		Position='N';
		TamanioX=x;
		TamanioY=y;
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	}
	
	public String executeCommand(String command){
		String aux="("+Xaux+","+Yaux+","+Position+")";
		String comman="";
		int Stado=0;
		for(int i=0;i<command.length();i++){
			comman=""+command.charAt(i);
			if(comman.equalsIgnoreCase("R") && Position=='N' && Stado==0){
				Position='E';
				Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("L") && Position=='N'&& Stado==0){
				Position='W';
				Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("R") && Position=='E'&& Stado==0){
				Position='S';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("L") && Position=='S'&& Stado==0){
				Position='E';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("R") && Position=='S'&& Stado==0){
				Position='W';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("L") && Position=='E'&& Stado==0){
				Position='N';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("R") && Position=='W'&& Stado==0){
				Position='N';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("L") && Position=='W'&& Stado==0){
				Position='S';
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			//mover
			if(comman.equalsIgnoreCase("f") && Position=='N' && Stado==0){
				 Stado=1;
				 if(Yaux==TamanioY-1){
						Yaux=0;
				}else{
					Yaux=Yaux+1;
				}
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("b") && Position=='N' && Stado==0){
				Stado=1;
				if(Yaux==0){
					Yaux=TamanioY-1;
				}else{
				Yaux=Yaux-1;
				}
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("f") && Position=='S' && Stado==0){
				Yaux=Yaux-1;
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("b") && Position=='S' && Stado==0){
				Yaux=Yaux+1;
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("f") && Position=='E' && Stado==0){
				Xaux=Xaux+1;
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("b") && Position=='E' && Stado==0){
				Xaux=Xaux-1;
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("f") && Position=='W' && Stado==0){
				Stado=1;
				if(Xaux==0){
					Xaux=TamanioX-1;
				}else{
					Xaux=Xaux-1;
				}
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			if(comman.equalsIgnoreCase("b") && Position=='W' && Stado==0){
				Xaux=Xaux+1;
				 Stado=1;
				aux="("+Xaux+","+Yaux+","+Position+")";
				
			}
			Stado=0;
		}
		

		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		
		return aux;
	}
	
	//set the Rover in column X
	public void setX(int x) {
		Xaux=x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		Yaux=y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		Position=direction;
		//to be implemented
	}
	
}

