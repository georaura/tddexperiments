package bowlingtest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import bowling.Frame;
import junit.framework.Assert;
import bowling.BowlingGame;

public class TestBowlingScoreKeeper {

	private BowlingGame game;
	
	@Before
	public void createMatch() 
	{
		
		game = new BowlingGame();
	}
	
	@Test
	public void test2y6da8() {


        int score;
		game.setBonus(2,6);
		score=game.score();
        assertEquals(8, score);
	}
	
	@Test
	public void test0y9da9() {


        int score;
		game.setBonus(0,9);
		score= game.score();
        assertEquals(9, score);
	}
	
	@Test
	public void SingleGame() {
	
		int score;
		
		game.setBonus(1,5);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(7,2);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(4,4);
		score= game.score();
		
		game.setBonus(5,3);
		score= game.score();
		
		game.setBonus(3,3);
		score= game.score();
		
		game.setBonus(4,5);
		score= game.score();
		
		game.setBonus(8,1);
		score= game.score();
		
		game.setBonus(2,6);
		score= game.score();
		
		assertEquals(81, score);
		
	}
	
	@Test
	public void MultipleStrike() {
	
		int score;
		
		game.setBonus(10,0);
		score= game.score();
		
		game.setBonus(10,0);
		score= game.score();
		
		game.setBonus(7,2);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(4,4);
		score= game.score();
		
		game.setBonus(5,3);
		score= game.score();
		
		game.setBonus(3,3);
		score= game.score();
		
		game.setBonus(4,5);
		score= game.score();
		
		game.setBonus(8,1);
		score= game.score();
		
		game.setBonus(2,6);
		score= game.score();
		
		assertEquals(112, score);
		
	}
	
	/*@Test
	public void MultipleSpare() {
	
		int score;
		
		game.setBonus(8,2);
		score= game.score();
		
		game.setBonus(5,5);
		score= game.score();
		
		game.setBonus(7,2);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(4,4);
		score= game.score();
		
		game.setBonus(5,3);
		score= game.score();
		
		game.setBonus(3,3);
		score= game.score();
		
		game.setBonus(4,5);
		score= game.score();
		
		game.setBonus(8,1);
		score= game.score();
		
		game.setBonus(2,6);
		score= game.score();
		
		assertEquals(98, score);
		
	}*/
	
	
	@Test
	public void SpareistheLastFrame() {
	
		int score;
		
		game.setBonus(1,5);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(7,2);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(4,4);
		score= game.score();
		
		game.setBonus(5,3);
		score= game.score();
		
		game.setBonus(3,3);
		score= game.score();
		
		game.setBonus(4,5);
		score= game.score();
		
		game.setBonus(8,1);
		score= game.score();
		
		game.setBonus(2,8);
		score= game.score();
		
		assertEquals(90, score);
		
	}
	
	@Test
	public void StrikeistheLastFrame() {
	
		int score;
		
		game.setBonus(1,5);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(7,2);
		score= game.score();
		
		game.setBonus(3,6);
		score= game.score();
		
		game.setBonus(4,4);
		score= game.score();
		
		game.setBonus(5,3);
		score= game.score();
		
		game.setBonus(3,3);
		score= game.score();
		
		game.setBonus(4,5);
		score= game.score();
		
		game.setBonus(8,1);
		score= game.score();
		
		game.setBonus(2,8);
		score= game.score();
		
		assertEquals(92, score);
		
	}
	

}
