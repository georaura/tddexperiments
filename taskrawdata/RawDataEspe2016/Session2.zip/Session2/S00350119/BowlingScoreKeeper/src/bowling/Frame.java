package bowling;



public class Frame {
  

	private int firstThrow;
	private int secondThrow;
	private int score1;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		this.secondThrow = secondThrow;
	}
	//getters
	 public int getThrow1() {
	        return firstThrow;
	    }

	    public int getThrow2() {
	        return secondThrow;
	    }
	//the score of a single frame
	public int score(){
		score1+=getThrow1()+getThrow2();
		return score1;
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		//to be implemented
		return false;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		//to be implemented
		return false;
	}

	 private boolean isAllStrikes() {
		    return false ;
		}
	 
	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		//to be implemented
		return false;
	}

	//bonus throws
	public int bonus(){
		//to be implemented
		return 0;
	}


}
