package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	private static final int MAX_FRAMES = 10;
    private static final int MAX_PINS = 10;
    private static final int MAX_ATTEMPTS_PER_FRAME = 2;
    private  int frameCounter = 0;
    private  int strikeCounter = 0;
    private static final int ALL_STRIKE_SCORE = 300;
    private Frame play=new Frame();
	private  int score=0;
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		//to be implemented
		 

         for (int i = 0; i < MAX_FRAMES; i++) {
             frames.add(new Frame());
         }
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		
		if(frameCounter<=MAX_FRAMES)
		{
			frameCounter++;
			if(firstThrow==MAX_PINS||secondThrow==MAX_PINS)
			{
				strikeCounter++;
				play=new Frame(firstThrow,secondThrow);
				frames.add(play);

			}
			else
			{
				play=new Frame(firstThrow,secondThrow);		
				frames.add(play);

			}
		}
		
	}
	
	public int score(){
		//to be implemented

		if(strikeCounter>1&&frameCounter<4)
		{
			//score+=frames
			score=10+10+play.getThrow1()+10+play.getThrow1()+play.getThrow2()
			+play.getThrow1()+play.getThrow2();			
			return score;
			
		}
		else{
			
			if(frameCounter==1)
			{
				return score+=play.getThrow1()+play.getThrow2();
					
			}
			if(frameCounter>1)
			{
				if(frameCounter==10&&play.getThrow1()+play.getThrow2()==10)
				{
					score+=play.getThrow1()+play.getThrow2()+7;
					
				}
				//if(frameCounter==10&&(play.getThrow1()==10)||play.getThrow2()==10)
					//score+=19;
				
				else	
					score+=play.getThrow1()+play.getThrow2();
			
			}
		
	        return score;
		}
        
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return false;
	}
}
