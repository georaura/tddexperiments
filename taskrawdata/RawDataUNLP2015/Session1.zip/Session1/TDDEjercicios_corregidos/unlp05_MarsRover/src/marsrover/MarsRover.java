package marsrover;

import java.util.ArrayList;
import java.util.List;

public class MarsRover {
	
	public int posX, posY;
	private List<List<Boolean>> obstacles = new ArrayList<List<Boolean>>();
	private List<Coordinate> reportedObstacles = new ArrayList<Coordinate>();
	public int width, height;
	public char direction;
	
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		width = x;
		height = y;
		for (int i = 0; i < height; i++) {
			this.obstacles.add(new ArrayList<Boolean>());
			for (int j = 0; j < width; j++) {
				this.obstacles.get(i).add(false);
			}
		}
		posX = 0;
		posY = 0;
		direction = 'N';
		if (!obstacles.equals("")) {
			obstacles = obstacles.replaceAll("\\(", "");
			obstacles = obstacles.replaceAll("\\)", ",");
			String[] obs = obstacles.split(",");
			for (int i = 0; i < obs.length; i += 2) {
				int obsX = Integer.parseInt(obs[i]);
				int obsY = Integer.parseInt(obs[i+1]);
				if (obsX > 0 && obsX < width && obsY > 0 && obsY < height) {
					this.obstacles.get(obsX).set(obsY, true);
				}
			}
		}
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		String status = "(" + posX + "," + posY + "," + direction + ")";
		for (int i = 0; i < command.length(); i++){
		    char c = command.charAt(i);        
		    
		    switch (c){
		    	case 'l':
		    		turnLeft();
		    		break;
		    	case 'r':
		    		turnRight();
		    		break;
		    	case 'f':
		    		String newStatusFw = moveForward();
		    		if (!newStatusFw.equals("")) {
		    			status = status + newStatusFw;
		    		}
		    		break;
		    	case 'b':
		    		String newStatusBw = moveBackwards();
		    		if (!newStatusBw.equals("")) {
		    			status = status + newStatusBw;
		    		}
		    		break;
		    }
		}
		
		return "("+posX+","+posY+","+direction+")";
	}
	
	//set the Rover in column X
	public void setX(int x) {
		posX = x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		posY = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		this.direction = direction;
	}
	
	private void turnLeft() {
		if (direction == 'N') {
			setFacing('W');
		} else if (direction == 'W') {
			setFacing('S');
		} else if (direction == 'S') {
			setFacing('E');
		} else {
			setFacing('N');
		}
	}
	
	private void turnRight() {
		if (direction == 'N') {
			setFacing('E');
		} else if (direction == 'E') {
			setFacing('S');
		} else if (direction == 'S') {
			setFacing('W');
		} else {
			setFacing('N');
		}
	}
	
	private String moveForward() {
		switch (direction) {
			case 'N':
				if (posY < height-1) {
					return checkObstacleAndMove(posX, posY+1);
				} else {
					return checkObstacleAndMove(posX, 0);
				}
			case 'S':
				if (posY > 0) {
					return checkObstacleAndMove(posX, posY-1);
				} else {
					return checkObstacleAndMove(posX, height-1);
				}
			case 'W':
				if (posX > 0) {
					return checkObstacleAndMove(posX-1, posY);
				} else {
					return checkObstacleAndMove(width-1, posY);
				}
			case 'E':
				if (posX < width-1) {
					return checkObstacleAndMove(posX+1, posY);
				} else {
					return checkObstacleAndMove(0, posY);
				}
			default:
				return "";
		}
	}
	
	private String moveBackwards() {
		switch (direction) {
			case 'N':
				if (posY > 0) {
					return checkObstacleAndMove(posX, posY-1);
				} else {
					return checkObstacleAndMove(posX, height-1);
				}
			case 'S':
				if (posY < height-1) {
					return checkObstacleAndMove(posX, posY+1);
				} else {
					return checkObstacleAndMove(posX, 0);
				}
			case 'W':
				if (posX < width-1) {
					return checkObstacleAndMove(posX+1, posY);
				} else {
					return checkObstacleAndMove(0, posY);
				}
			case 'E':
				if (posX > 0) {
					return checkObstacleAndMove(posX-1, posY);
				} else {
					return checkObstacleAndMove(width-1, posY);
				}
			default:
				return "";
		}
	}
	
	public String checkObstacleAndMove(int x, int y) {
		if (canMove(x, y)) {
			setX(x);
			setY(y);
			return "";
		} else if (!reported(x, y)) {
			return reportObstacle(x, y);
		} else {
			return "";
		}
	}
	
	public boolean canMove(int x, int y) {
		return !obstacles.get(x).get(y);
	}
	
	public boolean reported(int x, int y) {
		for (int i = 0; i < reportedObstacles.size(); i++) {
			Coordinate coord = reportedObstacles.get(i);
			if (coord.x == x && coord.y == y) {
				return true;
			}
		}
		return false;
	}
	
	public String reportObstacle(int x, int y) {
		Coordinate coord = new Coordinate(x, y);
		reportedObstacles.add(coord);
		String status = "(" + x + "," + y + ")";
		return status;
	}
	
	public Boolean isObstacle(int x, int y){
		return obstacles.get(x).get(y);
	}
}

