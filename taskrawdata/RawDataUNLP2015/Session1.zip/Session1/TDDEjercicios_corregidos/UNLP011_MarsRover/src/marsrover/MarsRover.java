package marsrover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MarsRover {
	
	private int xAxisLength;
	private int yAxisLength;
	private boolean[][] obstacles;
	
	private int currentX;
	private int currentY;
	private char currentDir;
	


	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		this.xAxisLength = x;
		this.yAxisLength = y;
	//	this.obstacles = getGrid(x, y, obstacles);
		
		this.currentX = 0;
		this.currentY = 0;
		this.currentDir = 'N';
	}
	
	private boolean[][] getGrid(int dimX,int dimY,String obstacles) {
		
		boolean[][] world = new boolean[dimX][dimY];
		if(obstaclesStringHasCorrectFormat(obstacles))
		{
			List<String> splitedObstacles = splitObstacles(obstacles);
			for (String obstacle : splitedObstacles) {
				int coordX = getCoordXofObstacle(obstacle);
				int coordY = getCoordYofObstacle(obstacle);
				world[coordY][coordX] = true;
			}
		}
		return world;
		
	}
	
	public boolean areAnyObstacles()
	{
		for (int x = 0; x < this.xAxisLength; x++) 
		{
			for (int y = 0; y < this.yAxisLength; y++) 
			{
				if(this.obstacles[y][x] == true)
				{
					return true;
				}
			}
		}
		
		return false;
	}
	

	private boolean obstaclesStringHasCorrectFormat(String obstacles) {
		return obstacles!=null;
	}

	private int getCoordYofObstacle(String obstacle) {
		String yCoord = obstacle.substring(3,4); 
		return Integer.parseInt(yCoord);
	}

	private int getCoordXofObstacle(String obstacle) {
		String xCoord = obstacle.substring(1,2); 
		return Integer.parseInt(xCoord);
	}

	private List<String> splitObstacles(String obstacles) {
		String obstaclesToParse = obstacles;
		ArrayList<String> parsedObstacles = new ArrayList<String>();
		while(!"".equals(obstaclesToParse))
		{
			String obstacle = obstaclesToParse.substring(0,5);
			obstaclesToParse = obstaclesToParse.substring(5);
			parsedObstacles.add(obstacle);
		}
		return parsedObstacles;
	}

	public String executeCommand(String command) {
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		
		char[] commands = command.toCharArray();
		String output = null;
		try {
			output = executeASetOfCommands(commands);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "("+currentX+","+currentY+","+currentDir+")";
	}
	
	private String executeASetOfCommands(char[] commands) throws Exception {
		List<String> output = new ArrayList<String>();
		for (int i = 0; i < commands.length; i++) {
			String commandOutput = executeSingleCommand(commands[i]);
			output.add(commandOutput);
		}
		output.add(String.format("(%d,%d,%s)",currentX,currentY,currentDir));
		return printLog(output);
	}

	private String printLog(List<String> output) {
		Collections.reverse(output);
		
		StringBuilder builder = new StringBuilder();
		for(String s : output) {
		    builder.append(s);
		}
		return builder.toString();
	}



	private String executeSingleCommand(char command) throws Exception {
		switch (command) {
		case 'l':
			return turnLeft();
		case 'r':
			return turnRight();
		case 'f':
			return moveForward();
		case 'b':
			return moveBackwards();
		default:
			throw new Exception("unknown command: " + command);
		}
	}

	private String moveForward() {
		int nextY = currentY;
		int nextX = currentX;
		switch (currentDir) {
		case 'N':
			nextY = currentY==yAxisLength ? 0: currentY+1;
			break;
		case 'S':
			nextY = (currentY==0) ? yAxisLength: currentY-1;
			break;
		case 'E':
			nextX = currentX==xAxisLength ? 0: currentX-1;
			break;
		default:
			nextX= currentX==xAxisLength ? 0: currentX+1;
			break;
		}
		
		if(hasObstacleIn(nextX, nextY))
		{
			return String.format("(%d,%d)",nextX,nextY);
		}
		else
		{
			currentX = nextX;
			currentY = nextY;
			return "";
		}
		
	}
	
	private String moveBackwards() {
		int nextY = currentY;
		int nextX = currentX;
		switch (currentDir) {
		case 'N':
			nextY = currentY==0 ? yAxisLength: currentY-1;
			break;
		case 'S':
			nextY = currentY==yAxisLength ? 0: currentY+1;
			break;
		case 'E':
			nextX = currentX==xAxisLength ? 0: currentX+1;
			break;
		default:
			nextX = currentX==0 ? yAxisLength: currentX-1;
			break;
		}
		
		if(hasObstacleIn(nextX, nextY))
		{
			return String.format("(%d,%d)",nextX,nextY);
		}
		else
		{
			currentX = nextX;
			currentY = nextY;
			return "";
		}
		
	}

	private String turnRight() {
		char nextDir = currentDir;
		switch (currentDir) {
			case 'N':
				nextDir = 'E';
				break;
			case 'S':
				nextDir = 'W';
				break;
			case 'E' :
				nextDir = 'S' ;
				break;
			default:
				nextDir = 'N';
				break;
		}
		currentDir = nextDir;
		return "";
	}

	private String turnLeft() {
		char nextDir = currentDir;
		switch (currentDir) {
			case 'N':
				nextDir = 'W';
				break;
			case 'S':
				nextDir = 'E';
				break;
			case 'E' :
				nextDir = 'N' ;
				break;
			default:
				nextDir = 'S';
				break;
		}
		
		currentDir = nextDir;
		return "";
		
	}

	//set the Rover in column X
	public void setX(int x) {
		currentX = x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		currentY = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		currentDir = direction;
	}

	public boolean hasObstacleIn(int x, int y) {
		return obstacles[y][x];
	}
	
}

