package marsroveracceptancetest;

import marsrover.MarsRover;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class US04
{

    public US04()
    {
    }
    
    @Before
    public void startUp()
    {
        rover = new MarsRover(100, 100, "");
    }

    @Test
    public void theRoverMovesBackwardNorthBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("b");
        try
        {
            MatcherAssert.assertThat("(0,6,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("bbb"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,5,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverMovesBackwardSouthBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("ll");
        try
        {
            MatcherAssert.assertThat("(0,15,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("bbbbb"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,16,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverMovesBackwardWestBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("l");
        MatcherAssert.assertThat("(3,10,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("bbb"))));
    }

    @Test
    public void theRoverMovesBackwardEastBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("r");
        rover.executeCommand("fffff");
        try
        {
            MatcherAssert.assertThat("(2,10,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("bbb"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(1,10,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    private String generateCommand(int times, String symbol)
    {
        String command = "";
        for(int i = 0; i < times; i++)
            command = (new StringBuilder(String.valueOf(command))).append(symbol).toString();

        return command;
    }

    MarsRover rover;
}