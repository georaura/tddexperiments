package marsroveracceptancetest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ US01.class,
		US02.class, US03.class,US04.class,US05.class,US06.class,US07.class,US08.class,
		US09.class,US10.class,US11.class})
public class AllTests {

}
