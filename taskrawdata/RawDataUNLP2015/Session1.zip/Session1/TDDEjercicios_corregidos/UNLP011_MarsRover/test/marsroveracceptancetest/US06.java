package marsroveracceptancetest;

import marsrover.MarsRover;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US06
{

    public US06()
    {
    }

    @Before
    public void setUp()
    {
        rover = new MarsRover(100, 100, "");
    }

    @Test
    public void theRoverShouldSpawnOnTheBottomSideWhenCrossingNorth()
    {
        MarsRover rover = new MarsRover(100, 100, "");
        rover.executeCommand(generateCommand(99, "f"));
        MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void roverShouldSpawnOnThebottomWhenCrossingNorthBackwards()
    {
        MarsRover rover2 = new MarsRover(100, 100, "");
        rover2.executeCommand(generateCommand(99, "f"));
        rover2.executeCommand("ll");
        MatcherAssert.assertThat("(0,0,S)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand("b"))));
    }

   
    private String generateCommand(int times, String symbol)
    {
        String command = "";
        for(int i = 0; i < times; i++)
            command = (new StringBuilder(String.valueOf(command))).append(symbol).toString();

        return command;
    }

    @Test
    public void theRoverShouldSpawnOnTheNorthSideWhenCrossingSouth()
    {
        MarsRover rover = new MarsRover(100, 100, "");
        rover.executeCommand("ll");
        MatcherAssert.assertThat("(0,99,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void theRoverShouldSpawnOnTheNorthSideWhenCrossingSouthBackwards()
    {
        MarsRover rover2 = new MarsRover(100, 100, "");
        MatcherAssert.assertThat("(0,99,N)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand("b"))));
    }

    @Test
    public void theRoverShouldSpawnOnTheRightSideWhenCrossingLeft()
    {
        MarsRover rover = new MarsRover(100, 100, "");
        rover.executeCommand("l");
        MatcherAssert.assertThat("(99,0,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void theRoverShouldSpawnOnTheRightSideWhenCrossingLeftBackward()
    {
        MarsRover rover2 = new MarsRover(100, 100, "");
        rover2.executeCommand("r");
        MatcherAssert.assertThat("(99,0,E)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand("b"))));
    }

    @Test
    public void theRoverShouldSpawnOnTheLeftSideWhenCrossingRight()
    {
        MarsRover rover = new MarsRover(100, 100, "");
        rover.executeCommand("r");
        rover.executeCommand(Commons.generateCommand(99, "f"));
        MatcherAssert.assertThat("(0,0,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void theRoverShouldSpawnOnTheLeftSideWhenCrossingRightBackwards()
    {
        MarsRover rover2 = new MarsRover(100, 100, "");
        rover2.executeCommand("r");
        rover2.executeCommand(Commons.generateCommand(99, "f"));
        rover2.executeCommand("ll");
        MatcherAssert.assertThat("(0,0,W)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand("b"))));
    }

    MarsRover rover;
}