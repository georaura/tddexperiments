package marsroveracceptancetest;

import marsrover.MarsRover;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US08
{

    public US08()
    {
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheCornersOfThePlanetWhileMovingBackwardsLeft()
    {
        String topLeftCornerObstacle = Commons.generateObstacleInPosition(0, 99);
        MarsRover roverL = new MarsRover(100, 100, topLeftCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(0,98,S)(0,99)", Matchers.is(Matchers.equalToIgnoringCase(roverL.executeCommand(Commons.goToTopLeftCornerFromSouthBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover roverR = new MarsRover(100, 100, topLeftCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(1,99,E)(0,99)", Matchers.is(roverR.executeCommand((new StringBuilder(String.valueOf(Commons.goToTopRightCornerFromSouth()))).append("r").append(Commons.generateCommand(99, "b")).toString())));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingBackwardRighTop()
    {
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(50,98,S)(50,99)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToMiddleTopBorderFromSouthBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(50,1,N)(50,0)", Matchers.is(Matchers.equalToIgnoringCase(roverB.executeCommand(Commons.goToMiddleBottomBorderFromNorthBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleInTheMiddleOfThePlanetWhileMovingBackward()
    {
        String middleObstacle = Commons.generateObstacleInPosition(50, 50);
        MarsRover rover1 = new MarsRover(100, 100, middleObstacle);
        MarsRover rover2 = new MarsRover(100, 100, middleObstacle);
        try
        {
            MatcherAssert.assertThat("(50,51,N)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover1.executeCommand(Commons.goToMiddleOfPlanetFromNorthBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(50,49,S)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand(Commons.goToMiddleOfPlanetFromSouthBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersSevenObstaclesOnATourAroundThePlanet()
    {
        String obstacle1 = Commons.generateObstacleInPosition(0, 50);
        String obstacle2 = Commons.generateObstacleInPosition(0, 99);
        String obstacle3 = Commons.generateObstacleInPosition(50, 99);
        String obstacle4 = Commons.generateObstacleInPosition(99, 99);
        String obstacle5 = Commons.generateObstacleInPosition(99, 50);
        String obstacle6 = Commons.generateObstacleInPosition(99, 0);
        String obstacle7 = Commons.generateObstacleInPosition(50, 0);
        MarsRover rover3 = new MarsRover(100, 100, (new StringBuilder(String.valueOf(obstacle1))).append(obstacle2).append(obstacle3).append(obstacle4).append(obstacle5).append(obstacle6).append(obstacle7).toString());
        try
        {
            MatcherAssert.assertThat(rover3.executeCommand((new StringBuilder(String.valueOf(Commons.goToMiddleLeftBorderCommandFromSouthBackwards()))).append("rblbblbr").append(Commons.generateCommand(48, "b")).append("rblbr").append(Commons.generateCommand(49, "b")).append("rblbblbr").append(Commons.generateCommand(48, "b")).append("rblbr").append(Commons.generateCommand(48, "b")).append("rblbblbr").append(Commons.generateCommand(49, "b")).append("rblbr").append(Commons.generateCommand(48, "b")).append("rblbblbr").append(Commons.generateCommand(49, "b")).append("l").toString()), Matchers.anyOf(Matchers.equalToIgnoringCase("(0,0,N)(0,50)(0,99)(50,99)(99,99)(99,50)(99,0)(50,0)"), Matchers.equalToIgnoringCase("(0,49,S)(0,50)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover rover4 = new MarsRover(100, 100, (new StringBuilder(String.valueOf(obstacle7))).append(obstacle6).append(obstacle5).append(obstacle4).append(obstacle3).append(obstacle2).append(obstacle1).toString());
        try
        {
            MatcherAssert.assertThat(rover4.executeCommand((new StringBuilder(String.valueOf(Commons.goToMiddleBottomBorderFromWestBackwards()))).append("lbrbbrbl").append(Commons.generateCommand(48, "b")).append("lbrbl").append(Commons.generateCommand(49, "b")).append("lbrbbrbl").append(Commons.generateCommand(48, "b")).append("lbrbl").append(Commons.generateCommand(48, "b")).append("lbrbbrbl").append(Commons.generateCommand(49, "b")).append("lbrbl").append(Commons.generateCommand(48, "b")).append("lbrbbrbl").append(Commons.generateCommand(49, "b")).toString()), Matchers.anyOf(Matchers.equalToIgnoringCase("(0,0,N)(50,0)(99,0)(99,50)(99,99)(50,99)(0,99)(0,50)"), Matchers.equalToIgnoringCase("(49,0,W)(50,0)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
}