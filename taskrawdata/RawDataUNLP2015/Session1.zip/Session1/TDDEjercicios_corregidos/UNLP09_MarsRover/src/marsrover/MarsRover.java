package marsrover;

import java.util.ArrayList;
import java.util.HashMap;

public class MarsRover {
	
	int ancho, alto;
	String obstacles;
	HashMap<String, Integer> posicion;
	char facing;
	

	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		this.setAncho(x);
		this.setAlto(y);
		this.setObstacles(obstacles);
		this.setPosicion(new HashMap<String, Integer>());
		this.posicion.put("x", 0);
		this.posicion.put("y", 0);
		this.setFacing('N');
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		String obstaculosEncontrados = "";
		char[] comandos = command.toCharArray();
		for(char comando: comandos){
			if( (comando=='r') || (comando=='l'))
				this.cambiarDireccion(comando);
			else{
				if(comando=='f') obstaculosEncontrados = this.movermeAlFrente(obstaculosEncontrados);
				else obstaculosEncontrados = this.movermeEnReversa(obstaculosEncontrados);
			}
		}
		return "("+this.getPosicion().get("x")+","+this.getPosicion().get("y")+","+this.getFacing()+")"+obstaculosEncontrados;
	}
	
	public String movermeAlFrente(String obstaculosEncontrados){
		//metodo que mueve al frente al marsRover si puede, devolviendo el obstaculo en caso contrario
		int yDeseado = this.getPosicion().get("y");
		int xDeseado = this.getPosicion().get("x");
		ArrayList<Integer> pos = this.obtenerPosObjetivoFrente(xDeseado, yDeseado);
		xDeseado = pos.get(0);
		yDeseado = pos.get(1);
		
		if(this.getObstacles().contains("("+xDeseado+","+yDeseado+")")){
			if(!(obstaculosEncontrados.contains("("+xDeseado+","+yDeseado+")")))
				obstaculosEncontrados=obstaculosEncontrados.concat("("+xDeseado+","+yDeseado+")");
		}
			
		else{
			this.getPosicion().put("y", yDeseado);
			this.getPosicion().put("x", xDeseado);
		}
		return  obstaculosEncontrados;
	}
	
	public String movermeEnReversa(String obstaculosEncontrados){
		//metodo que mueve en reversa al marsRover si puede, devolviendo el obstaculo en caso contrario
		int yDeseado = this.getPosicion().get("y");
		int xDeseado = this.getPosicion().get("x");
		ArrayList<Integer> pos = this.obtenerPosObjetivoReversa(xDeseado, yDeseado);
		xDeseado = pos.get(0);
		yDeseado = pos.get(1);
		
		if(this.getObstacles().contains("("+xDeseado+","+yDeseado+")")){
			if(!(obstaculosEncontrados.contains("("+xDeseado+","+yDeseado+")")))
				obstaculosEncontrados=obstaculosEncontrados.concat("("+xDeseado+","+yDeseado+")");
		}
			
		else{
			this.getPosicion().put("y", yDeseado);
			this.getPosicion().put("x", xDeseado);
		}
		return  obstaculosEncontrados;
	}

	public ArrayList<Integer> obtenerPosObjetivoFrente(int x, int y){
		//metodo que dado un x y un y, devuelve el x e y destinos si se moviera
		//el marsrover al frente
		ArrayList<Integer> result = new ArrayList<Integer>();
		if(this.getFacing()=='E') 
			x=x+1;
		else{
			if(this.getFacing()=='W')
				x=x-1;
			else{
				if(this.getFacing()=='N')
					y=y+1;
				else y=y-1;
			}
		}
		if(x==this.getAncho()) x=0;
		else{
			if(x<0) x=this.getAncho()-1;
		}
		if(y==this.getAlto()) y=0;
		else{
			if(y<0) y=this.getAlto()-1;
		}
		result.add(x);
		result.add(y);
		return result;
	}
	
	public ArrayList<Integer> obtenerPosObjetivoReversa(int x, int y){
		//metodo que dado un x y un y, devuelve el x e y destinos si se moviera
		//el marsrover en reversa
		ArrayList<Integer> result = new ArrayList<Integer>();
		if(this.getFacing()=='E') 
			x=x-1;
		else{
			if(this.getFacing()=='W')
				x=x+1;
			else{
				if(this.getFacing()=='N')
					y=y-1;
				else y=y+1;
			}
		}
		if(x==this.getAncho()) x=0;
		else{
			if(x<0) x=this.getAncho()-1;
		}
		if(y==this.getAlto()) y=0;
		else{
			if(y<0) y=this.getAlto()-1;
		}
		result.add(x);
		result.add(y);
		return result;
	}
	
	public void cambiarDireccion(char dire){
		//metodo que en base al input r o l, cambia la direccion del marsover
		if(dire=='r'){
			switch (this.getFacing()) {
			case 'N':
				this.setFacing('E');
				break;
			case 'S':
				this.setFacing('W');
				break;
			case 'E':
				this.setFacing('S');
				break;
			case 'W':
				this.setFacing('N');
				break;
			default:
				break;
			}
		}else{ //la dire es l
			switch (this.getFacing()) {
			case 'N':
				this.setFacing('W');
				break;
			case 'S':
				this.setFacing('E');
				break;
			case 'E':
				this.setFacing('N');
				break;
			case 'W':
				this.setFacing('S');
				break;
			default:
				break;
			}
		}
	}
	
	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
		if( (x<this.getAncho()) && (x>0))
			this.posicion.put("x", x);
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
		if( (y<this.getAlto()) && (y>0))
			this.posicion.put("y", y);
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		if((direction=='N') || (direction=='S') || (direction=='E') || (direction=='W'))
			this.facing=direction;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}
	
	public String getObstacles() {
		return obstacles;
	}

	public void setObstacles(String obstacles) {
		this.obstacles = obstacles;
	}

	public HashMap<String, Integer> getPosicion() {
		return posicion;
	}

	public void setPosicion(HashMap<String, Integer> posicion) {
		this.posicion = posicion;
	}

	public char getFacing() {
		return facing;
	}
	
	
}

