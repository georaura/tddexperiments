package marsrover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MarsRover {
	
	private final static List<Character> turnDirections = Arrays.asList('l', 'r');
	
	private final static List<Character> movingDirections = Arrays.asList('f', 'b');
	
	private final static List<Direction> directions = Direction.allDirections();
	
	private int worldHeigh,worldLength; 
	
	private List<Obstacule> obstacles;
	
	private List<Obstacule> visitedObstacules;
	
	private int roverX, roverY;
	
	private Direction roverDirection;
	
	public int getWorldHeigh() {
		return worldHeigh;
	}

	public void setWorldHeigh(int worldHeigh) {
		this.worldHeigh = worldHeigh;
	}

	public int getWorldLength() {
		return worldLength;
	}

	public void setWorldLength(int worldLength) {
		this.worldLength = worldLength;
	}

	public List<Obstacule> getObstacles() {
		return obstacles;
	}

	public void setObstacles(List<Obstacule> obstacles) {
		this.obstacles = obstacles;
	}

	public int getRoverX() {
		return roverX;
	}

	public void setRoverX(int roverX) {
		this.roverX = roverX;
	}

	public int getRoverY() {
		return roverY;
	}

	public void setRoverY(int roverY) {
		this.roverY = roverY;
	}

	public Direction getRoverDirection() {
		return roverDirection;
	}

	public void setRoverDirection(Direction roverDirection) {
		this.roverDirection = roverDirection;
	}

	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		this.setWorldHeigh(x);
		this.setWorldLength(y);
		this.setObstacles(new ArrayList<Obstacule>());
		this.visitedObstacules = new ArrayList<Obstacule>();
		
		if (this.getWorldHeigh() >= 6  && this.getWorldLength() >= 6){
			this.setUpObstacules(obstacles);
		}
		
		this.setX(0);
		this.setY(0);
		this.setRoverDirection(directions.get(0));
		roverX=0;
		roverY=0;
	}

	private void setUpObstacules(String obstacles) {
		String[] a = obstacles.split("\\(*,*\\)");
		for (String string : a) {
			String[] n = string.split("\\(");
		//	String[] pair = n[1].split(",");
		//	Obstacule obstacule = new Obstacule(pair[0], pair[1]);
			//this.getObstacles().add(obstacule);
		}
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		/*String foundedObstacules = "";
		try {
			char[] commands = command.toCharArray();
			for (char c : commands) {
				if (turnDirections.contains(c)){
						this.setFacing(c);
				} else if (movingDirections.contains(c)){
					this.move(c);
				}
			}
		} catch (InvalidDirectionException e) {
			e.printStackTrace();
		}*/
		return "("+roverX+","+roverY+",N)";
	}
	
	private void move(char c) {
		int newPosition;
		if( c == movingDirections.get(0) && this.getRoverDirection().equals(Direction.north())){
			newPosition = this.getRoverX() + 1; 
			if(!this.existsObstacule(newPosition, this.getRoverY())){
				this.setX(newPosition);
			}
			
		}
		
		if( c == movingDirections.get(1) && this.getRoverDirection().equals(Direction.north())){
			this.setX(this.getRoverX() - 1);
		}
		
		if( c == movingDirections.get(0) && this.getRoverDirection().equals(Direction.south())){
			this.setX(this.getRoverX() - 1);
		}
		
		if( c == movingDirections.get(1) && this.getRoverDirection().equals(Direction.south())){
			this.setX(this.getRoverX() + 1);
		}
		
		if( c == movingDirections.get(0) && this.getRoverDirection().equals(Direction.east())){
			this.setY(this.getRoverY() + 1);
		}
		
		if( c == movingDirections.get(1) && this.getRoverDirection().equals(Direction.east())){
			this.setY(this.getRoverY() - 1);
		}
		
		if( c == movingDirections.get(0) && this.getRoverDirection().equals(Direction.west())){
			this.setY(this.getRoverY() - 1);
		}
		
		if( c == movingDirections.get(1) && this.getRoverDirection().equals(Direction.west())){
			this.setY(this.getRoverY() + 1);
		}
	}

	private boolean existsObstacule(int x, int y) {
		boolean found = false;
		int index = 0;
		while(!found && index < this.obstacles.size()){
			Obstacule obstacule = this.obstacles.get(index);
			found = obstacule.getX() == x && obstacule.getY() == y;
		}
		return found;
	}

	//set the Rover in column X
	public void setX(int x) {
		int newPosition = x;
		// Si es mayor a l�mite, vuelve a cero
		if (x > this.worldHeigh) {
			newPosition = 0;
		}
		// Si es menor a 0, se mueve al l�mite
		if (x < 0) {
			newPosition = this.worldHeigh;
		}
		
		this.setRoverX(newPosition);
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		int newPosition = y;
		// Si es mayor a l�mite, vuelve a cero
		/*if (y > this.worldLength) {
			newPosition = 0;
		}*/
		// Si es menor a 0, se mueve al l�mite
		if (y < 0) {
			newPosition = this.worldLength;
		}
		
		this.setRoverY(newPosition);
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) throws InvalidDirectionException {
		if (!turnDirections.contains(direction)){
			throw new InvalidDirectionException(direction);
		}
		this.setRoverDirection(this.getRoverDirection().turn(direction));
	}
}

