package marsrover;

import java.util.Arrays;
import java.util.List;

public class Direction {

	private Direction left, right;
	
	private String name;
	
	public Direction() {
	}
	
	public static Direction north(){
		return allDirections().get(0);
	}
	
	public static Direction east(){
		return allDirections().get(1);
	}
	
	public static Direction south(){
		return allDirections().get(2);
	}
	
	public static Direction west(){
		return allDirections().get(3);
	}
	
	public static List<Direction> allDirections(){
		Direction north  = new Direction();
		Direction east = new Direction();
		Direction south = new Direction();
		Direction west = new Direction();
		
		north.left = west;
		north.right = east;
		north.name = "NORTH";
		
		east.left = north;
		east.right = south;
		east.name = "EAST";
		
		south.left = east;
		south.right = west;
		south.name = "SOUTH";
		
		west.left = south;
		west.right = north;
		west.name = "WEST";
		
		return Arrays.asList(north, east, south, west);
	}
	
	/**
	 * Retorna la direcci�n correspondiente
	 * @param direction
	 * @return
	 */
	public Direction turn(char direction){
		if (direction == 'l'){
			return this.left;
		} else{
			return this.right;
		}
	}

	@Override
	public String toString() {
		return "Direction [name=" + name + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Direction other = (Direction) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
}
