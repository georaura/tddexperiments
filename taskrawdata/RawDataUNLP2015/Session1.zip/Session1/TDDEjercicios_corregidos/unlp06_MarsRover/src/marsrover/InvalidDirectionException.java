package marsrover;

public class InvalidDirectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private char direction;
	
	public char getDirection(){
		return this.direction;
	}
	
	public InvalidDirectionException(char direction) {
		super();
		this.direction = direction;
	}

}
