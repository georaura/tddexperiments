package bowling;

public class EndedGameException extends Exception {

	public EndedGameException() {
		super();
	}

	public EndedGameException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
