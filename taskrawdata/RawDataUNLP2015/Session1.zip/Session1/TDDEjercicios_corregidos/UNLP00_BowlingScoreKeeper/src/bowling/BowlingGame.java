package bowling;

import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	// a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;

	private int firstStrike = 0;
	private int secondStrike = 0;

	public BowlingGame() {
	}

	public void addFrame(Frame frame) throws EndedGameException {
		if (this.getTurn() < 10) {
			frames.add(frame);
		} else {
			//throw new EndedGameException("El juego termin�");
			System.out.println("El juego termin�");
		}
	}

	public void setBonus(int firstThrow, int secondThrow) {
		// to be implemented
	}

	public int score() {
		int score = 0;
		for (int i = 0; i < this.getTurn(); i++) {
			score = score + this.frames.get(i).score();
			if ((this.frames.get(i).isStrike()) && (i <= 8)) {
				score = score + this.frames.get(i + 1).score();
				firstStrike = secondStrike;
				secondStrike = i;
			} else if ((this.frames.get(i).isSpare()) && (i <= 8)) {
				score = score + this.frames.get(i + 1).getThrow1();
			}
		}
		if (this.twoStrikesInARow()) {
			score = score + 10
					+ (this.frames.get(secondStrike + 1).getThrow1())
					+ (this.frames.get(secondStrike + 1).score());
		}
		return score;
	}

	public boolean isNextFrameBonus() {
		// to be implemented
		return false;
	}

	public int getTurn() {
		return this.frames.size();
	}

	public boolean twoStrikesInARow() {
		return ((secondStrike - firstStrike) == 1);
	}
}
