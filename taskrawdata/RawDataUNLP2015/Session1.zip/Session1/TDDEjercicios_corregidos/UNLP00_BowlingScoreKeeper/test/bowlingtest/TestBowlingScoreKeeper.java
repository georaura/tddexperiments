package bowlingtest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;

public class TestBowlingScoreKeeper {
	BowlingGame bg;
	Frame f;
	@Before
	public void Instancia(){
		bg= new BowlingGame();
		f = new Frame();
	}
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}

	@Test
	public void inicioFrame() {
		f= new Frame(0,0);
	}
	@Test
	public void inicioFramecon12() {
		f= new Frame(1,2);
	}
//	@Test
//	public void framelista() {
//		f= new Frame(4,5);
//		bg.addFrame(f);				
//	}
	@Test
	public void framescore() {
		f= new Frame(4,5);
		//bg.addFrame(f);	
		assertEquals(9, f.score());
	}
	@Test
	public void framescoreTotal() throws Exception {
		f= new Frame(4,5);
		try {
			bg.addFrame(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		bg.addFrame(new Frame(3,5));	
		
		assertEquals(17, bg.score());
	}
	@Test
	public void maxframe() throws Exception {
			
		try{
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
			bg.addFrame(new Frame(3,5));
	

			fail("mas frame de los que admite");
		}catch(Exception e){
			e.getMessage();
		}
		
	}
	

}
