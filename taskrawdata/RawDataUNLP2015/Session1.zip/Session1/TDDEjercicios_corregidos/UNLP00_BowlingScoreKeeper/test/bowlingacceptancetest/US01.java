package bowlingacceptancetest;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import bowling.Frame;


public class US01 {

	@Test
	public void testEmptyFrameIsCreated() {
		Frame f = new Frame();
		assertNotNull(f);
	}

	@Test
	public void testFrameWithScoreIsCreated() throws Exception {
		Frame f = new Frame(1,2);
		 try
	        {
			 assertNotNull(f);
	        }
	        catch(Exception e)
	        {
	            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
	        }
	
	}
	
	@Test
	public void testFrameIsCreatedWithCorrectName(){
		Frame f  = new Frame();
		try
        {
			assertEquals("Frame", f.getClass().getSimpleName());
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
}
