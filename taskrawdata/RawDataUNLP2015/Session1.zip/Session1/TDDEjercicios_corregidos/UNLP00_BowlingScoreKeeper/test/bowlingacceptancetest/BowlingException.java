package bowlingacceptancetest;

public class BowlingException extends Exception {

}
