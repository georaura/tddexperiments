package marsrover;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MarsRover {
	
	private int x;
	private int y;
	private char facing;
	
	private int planetSizeX;
	private int planetSizeY;
	
	private Map<Integer, Set<Integer>> obstacles;
	private List<String> foundObstacles;
	
	//set the Rover in column X
	public void setX(int x) {
		this.x = x;
	}
	
	public int getX(){
		return this.x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		this.y = y;
	}
	
	public int getY(){
		return this.y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		this.facing = direction;
	}
	
	public char getFacing() {
		return this.facing;
	}

	public int getPlanetSizeX() {
		return planetSizeX;
	}

	public void setPlanetSizeX(int planetSizeX) {
		this.planetSizeX = planetSizeX;
	}

	public int getPlanetSizeY() {
		return planetSizeY;
	}

	public void setPlanetSizeY(int planetSizeY) {
		this.planetSizeY = planetSizeY;
	}
	
	public Map<Integer, Set<Integer>> getObstacles() {
		return obstacles;
	}

	public void setObstacles(Map<Integer, Set<Integer>> obstacles) {
		this.obstacles = obstacles;
	}

	public List<String> getFoundObstacles() {
		return foundObstacles;
	}

	public void setFoundObstacles(List<String> foundObstacles) {
		this.foundObstacles = foundObstacles;
	}

	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		
		this.setPlanetSizeX(x);
		this.setPlanetSizeY(y);
		
		this.initializePosition();
		this.initializeObstacles(obstacles);
		
	}
	
	private void initializePosition() {
		this.setX(0);
		this.setY(0);
		this.setFacing('N');
	}
	
	private void initializeObstacles(String obstacles) {
		this.setFoundObstacles(new ArrayList<String>());
		Map<Integer, Set<Integer>> map = new HashMap<Integer, Set<Integer>>();
		if (!obstacles.isEmpty()) {
			for (String splitResult : obstacles.split("\\)")) {
				splitResult = splitResult.replace("(", "").replace(")", "");
				//this.setUpObstacles(map, Integer.valueOf(splitResult.substring(0, 1)), Integer.valueOf(splitResult.substring(2, 3)));
			}
		}
		
		this.setObstacles(map);
	}
	
	private void setUpObstacles(Map<Integer, Set<Integer>> map, Integer x, Integer y) {
		if (!map.containsKey(x)) {
			map.put(x, new HashSet<Integer>());
		}
		
		map.get(x).add(y);
	}
	
	public String executeCommand(String command){
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		for (int i = 0; i < command.length(); i++) {
			executeCommand(command.charAt(i));
		}
		
		return printResult();
	}
	
	private String printResult() {
		return this.printPosition() + this.printObstacles();
	}
	
	private String printPosition() {
		return "(" + this.getX() + "," + this.getY() + "," + this.getFacing() + ")";
	}
	
	private String printObstacles() {
		String result = "";
		for (String each : this.getFoundObstacles()) {
			result += each;
		}
		
		return result;
	}
	
	private void executeCommand(char command) {
		switch (command) {
			case 'l': turnLeft();
					break;
			case 'r': turnRight();
				break;
			case 'f': moveForward();
				break;
			case 'b': moveBackward();
				break;
				
			default : break;
		}
	}
	
	private void turnLeft() {
		switch (this.facing) {
			case 'N': this.setFacing('W');
					break;
			case 'W': this.setFacing('S');
				break;
			case 'S': this.setFacing('E');
				break;
			case 'E': this.setFacing('N');
				break;
			default : break;
		}
	}
	
	private void turnRight() {
		switch (this.facing) {
			case 'N': this.setFacing('E');
					break;
			case 'E': this.setFacing('S');
				break;
			case 'S': this.setFacing('W');
				break;
			case 'W': this.setFacing('N');
				break;
			default : break;
		}
	}
	
	private void moveForward() {
		switch (this.facing) {
			case 'N': moveNorth(); 	
				break;
			case 'E': moveEast();
				break;
			case 'S': moveSouth();
				break;
			case 'W': moveWest();
				break;
			default : break;
		}
	}
	
	private void moveBackward() {
		switch (this.facing) {
			case 'N': moveSouth();
					break;
			case 'E': moveWest();
				break;
			case 'S': moveNorth();
				break;
			case 'W': moveEast();
				break;
			default : break;
		}
	}
	
	private void moveNorth() {
		int newPosY = this.getY() + 1;
		if (newPosY >= this.getPlanetSizeY()) {
			newPosY = 0;
		}
		this.moveTo(null, newPosY);
	}
	
	private void moveEast() {
		int newPosX = this.getX() + 1;
		if (newPosX >= this.getPlanetSizeX()) {
			newPosX = 0;
		}
		this.moveTo(newPosX, null);
	}
	
	private void moveSouth() {
		int newPosY = this.getY() - 1;
		if (newPosY < 0) {
			newPosY = this.getPlanetSizeY() - 1;
		}
		this.moveTo(null, newPosY);
	}
	
	private void moveWest() {
		int newPosX = this.getX() - 1;
		if (newPosX < 0) {
			newPosX = this.getPlanetSizeX() - 1;
		}
		this.moveTo(newPosX, null);
	}
	
	private void moveTo(Integer x, Integer y) {
		if (x == null) {
			x = this.getX();
		}
		if (y == null) {
			y = this.getY();
		}
		
		if (thereIsAObstacle(x, y)) {
			addFoundObstacle(x, y);
		} else {
			this.setX(x);
			this.setY(y);
		}
	}
	
	private boolean thereIsAObstacle(Integer x, Integer y) {
		if (!this.getObstacles().containsKey(x)) {
			return false;
		}
		return this.getObstacles().get(x).contains(y);
	}
	
	private void addFoundObstacle(Integer x, Integer y) {
		String obstable = "(" + x + "," + y + ")";
		if (!this.getFoundObstacles().contains(obstable)) {
			this.getFoundObstacles().add(obstable);
		}
	}
	
}

