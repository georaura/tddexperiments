package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	public BowlingGame(){
		this.bonus = new Frame();
	}
	
	public void addFrame(Frame frame){
		this.frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		Frame bon = new Frame(firstThrow, secondThrow);
		this.bonus = bon;
	}
	
	public int score(){
		int gameScore = 0;
		try{
		for(int i=0; i < this.frames.size(); i++)
		{
			int tmp = 0;
			if(this.frames.get(i).isStrike())
				tmp = this.frames.get(i+1).score();
			else {	
				if(this.frames.get(i).isSpare())
				{
					tmp += this.frames.get(i+1).score();
				}
			}
			gameScore += this.frames.get(i).score() + tmp;
		}
		}
		catch(Exception e){
			System.out.println("Error en el �ndice del arreglo");
		}
		return gameScore;
	}
	
	public boolean isNextFrameBonus(){
		return false;
	}
	
	public Frame getFrame(int pos)
	{
		return this.frames.get(pos);
	}
	
	
}
