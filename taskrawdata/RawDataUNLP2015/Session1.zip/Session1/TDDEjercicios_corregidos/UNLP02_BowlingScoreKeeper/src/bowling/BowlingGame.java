package bowling;
import java.util.ArrayList;
//import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
//import java.util.NoSuchElementException;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	private Frame currentFrame;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame){
		//to be implemented
		this.frames.add(frame);
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
		
	}
	
	public int score(){
		//to be implemented
		int totalScore = 0;
		//System.out.println("cantidad de frames: "+this.frames.size());
		ListIterator<Frame> itr = this.frames.listIterator();
		while (itr.hasNext()) {
			Frame f = itr.next();
			totalScore += this.getFrameScore(f);
			//System.out.println(f.isLastFrame());
			if ( (this.isLastFrame(f)) && ( (f.isSpare()) || (f.isStrike()) ) )
				while (itr.hasNext()) 
					itr.next();
			//System.out.println(totalScore);
		}		
		return totalScore;
	}
	
	public boolean isNextFrameBonus(){
		//to be implemented
		return ((this.currentFrame.isSpare()) || (this.currentFrame.isStrike()));
	}
	
	public int getFrameBonus(Frame frame) {
		/**System.out.println(frame.getThrow1());
		System.out.println(frame.getThrow2());
		System.out.println(frame.isSpare());**/
		
		if (frame.isSpare()) {
			try{
				return (this.getNextFrame(frame).getThrow1());
			}
			catch(Exception e){
				System.out.println("Error en el �ndice del arreglo");
			}
		}
		else
			if (frame.isStrike()) {
				if (this.getNextFrame(frame) != null) {
					if (this.getNextFrame(frame).isStrike())
						try{
							return (this.getNextFrame(frame).getThrow1()+this.getNextToNextFrame(frame).getThrow1());
							}
						catch(Exception e){
							System.out.println("Error en el �ndice del arreglo");
						}
					else
						try{
							return (this.getNextFrame(frame).getThrow1()+this.getNextFrame(frame).getThrow2());
						}
						catch(Exception e){
							System.out.println("Error en el �ndice del arreglo");
						}
				}
				else return 0;
			}
			else
				return 0;
		return 0;
		
		
		
	}
	
	public int getFrameScore(Frame frame) {
		return (frame.getThrow1()+frame.getThrow2()+this.getFrameBonus(frame));
		
	}
	
	public Frame getNextFrame(Frame frame) {
		
		
		/**ListIterator<Frame> itr = this.frames.listIterator();
		boolean cont = true;
		while ((itr.hasNext()) && (cont)) {
			Frame f = itr.next();
			cont = (f == frame);
		}**/
		//return itr.previous();
		try {
			return frames.get(this.frames.indexOf(frame)+1);
		}
		catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	
	public Frame getNextToNextFrame(Frame frame) {
		
		
		/**ListIterator<Frame> itr = this.frames.listIterator();
		boolean cont = true;
		while ((itr.hasNext()) && (cont)) {
			Frame f = itr.next();
			cont = (f == frame);
		}**/
		//return itr.previous();
		return frames.get(this.frames.indexOf(frame)+2);
	}
	
	public boolean isLastFrame(Frame frame) {
		//System.out.println("indice del frame "+this.frames.indexOf(frame));
		return (this.frames.indexOf(frame) == 9);
		
	}
	
	public void setCurrentFrame(Frame frame) {
		this.currentFrame = frame;
	}
}
