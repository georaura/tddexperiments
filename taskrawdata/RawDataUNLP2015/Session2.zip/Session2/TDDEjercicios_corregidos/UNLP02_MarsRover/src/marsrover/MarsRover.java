package marsrover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MarsRover {
	
	int x, y; //grid
	int xRobot, yRobot;
	char robotDirection;
	int indexRobotDirection = 0;
	String directions = "NESW";
	List<String> obstacles;
	public MarsRover() {}
	
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		obstacles = obstacles.replace(")", " ").replace("(", " ").replace("  ", "/").replace(" ", "");
		this.obstacles = new ArrayList<String>(Arrays.asList(obstacles.split("/")));
		this.x = x-1;
		this.y = y-1;
		this.land();
	}
	
	public String executeCommand(String command){
		String foundObstacles = "";	
		String found;
		for (int i = 0; i<command.length(); i++) {
			switch (command.charAt(i)) {
				case 'r': this.girarALaDerecha();
						break;
				case 'l': this.girarALaIzquierda();
						break;
				case 'f': this.moverHaciaAdelante();
						break;		
				case 'b': this.moverHaciaAtras();
						break;	
			}
			found = this.getPossibleObstacle();
			if ((found != "") && (!foundObstacles.contains(found)))
				foundObstacles += this.getPossibleObstacle();
		}
		return "("+String.valueOf(this.xRobot)+","+String.valueOf(this.yRobot)+","+this.robotDirection+")"+foundObstacles;
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
	}
	
	private String getPossibleObstacle() {
		if (this.mapHasObstacleAt(xRobot, yRobot)) 
			return "("+this.xRobot+","+this.yRobot+")";
		return "";
	}

	private void moverHaciaAtras() {
		switch (this.robotDirection) {
			case 'N': this.yRobot = this.modulus(this.yRobot-1, this.y+1);
					break;
			case 'S': this.yRobot = this.modulus(this.yRobot+1, this.y+1);
					break;
			case 'E': this.xRobot = this.modulus(this.xRobot-1, this.x+1);
					break;		
			case 'W': this.xRobot = this.modulus(this.xRobot+1, this.x+1);
					break;	
		}
		
	}

	private void moverHaciaAdelante() {
		switch (this.robotDirection) {
			case 'N': this.yRobot = this.modulus(this.yRobot+1, this.y+1);
					break;
			case 'S': this.yRobot = this.modulus(this.yRobot-1, this.y+1);
					break;
			case 'E': this.xRobot = this.modulus(this.xRobot+1, this.x+1);
					break;		
			case 'W': this.xRobot = this.modulus(this.xRobot-1, this.x+1);
					break;	
		}
		
	}

	private void girarALaIzquierda() {
		if (this.indexRobotDirection == 0) {
			this.robotDirection = this.directions.charAt(3);
			this.indexRobotDirection = 3;
			}
		else {
			this.indexRobotDirection--;
			this.robotDirection = this.directions.charAt(this.indexRobotDirection);
		}
		
	}

	private void girarALaDerecha() {
		if (this.indexRobotDirection == 3) {
			this.robotDirection = this.directions.charAt(0);
			this.indexRobotDirection = 0;
		}
		else {
			this.indexRobotDirection++;
			this.robotDirection = this.directions.charAt(this.indexRobotDirection);
		}		
		
	}

	//set the Rover in column X
	public void setX(int x) {
		this.xRobot = x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		this.yRobot = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		this.robotDirection = direction;
	}

	public boolean planetSize(int i, int j) {
		return ((this.x == i-1) && (this.y == j-1));
	}
	
	public void land() {
		this.xRobot = 0;
		this.yRobot = 0;
		this.robotDirection = 'N';
	}	
	
	private int modulus(int x, int n) {
		int r = x % n;
		if (r < 0)
			return (r += n);
		else return r;
	}

	public boolean mapHasObstacleAt(int i, int j) {
		String obstacle = String.valueOf(i)+","+String.valueOf(j);
		return this.obstacles.contains(obstacle);
	}
	
}

