package bowlingacceptancetest;

public class InvalidInput extends Exception {

}
