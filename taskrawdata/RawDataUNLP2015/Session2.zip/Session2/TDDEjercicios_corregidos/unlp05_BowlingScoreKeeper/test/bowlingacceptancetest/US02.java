package bowlingacceptancetest;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import bowling.Frame;

public class US02 {

	@Test
	public void testFrameScore() throws Exception  {
		Frame f = new Frame(2,4);
		try
        {
			assertEquals(6, f.score());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		f = new Frame(0,0);
		try
        {
			assertEquals(0, f.score());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	@Test
	public void testAllPinsFrameScore() throws Exception {
		Frame f = new Frame(10,0);
		try
        {
			assertEquals(10, f.score());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	
	// Commented by Oscar
	// Exceptions are not taught neither enforced in the experiment
	@Ignore
	@Test
	public void testExceptionMoreThan10PinsPerFrame() throws Exception {
		Frame f = new Frame(12,12);
		f.score();
	}
}
