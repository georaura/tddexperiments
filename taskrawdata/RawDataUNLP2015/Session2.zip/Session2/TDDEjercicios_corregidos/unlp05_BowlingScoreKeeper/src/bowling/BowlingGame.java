package bowling;

import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	// a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;

	public BowlingGame() {
	}

	public void addFrame(Frame frame) {
		this.frames.add(frame);
	}

	public void setBonus(int firstThrow, int secondThrow) {
		// Ponemos 0 porque s�lo una bola extra le es permitida al obtener un
		// spare o strike en el �ltimo frame.
		bonus = new Frame(firstThrow, 0);
		// Trato al bonus como un frame mas.
		this.addFrame(bonus);
	}

	public int score() {
		// total de pins volteados (entre todos los frames) + bonuses por frame
		int score = 0;
		for (int i = 0; i < frames.size(); i++) {
			Frame currentFrame = frames.get(i);
			score = score + currentFrame.score();


			if (frames.size() > (i+1)) {
				// deber�a en caso de que i < 10, o i==10 y el anterior frame fue strike o spare.
				Frame nextFrame = frames.get(i + 1);
				if (currentFrame.isSpare()) {
					score = score + nextFrame.getThrow1();
				} else if (currentFrame.isStrike()) {
					score = score + nextFrame.getThrow1()
							+ nextFrame.getThrow2();
				}
			}

		}

		return score;
	}

	public boolean isNextFrameBonus() {
		// to be implemented
		return false;
	}
}
