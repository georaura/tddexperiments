package marsrover;

public class MarsRover {
	
	private boolean[][] grid;
	private int direction; //N=0, E=1, S=2, w=3
	private int posx;
	private int posy;
	
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
		this.grid = new boolean[x][y];
		this.direction = 0;
		this.posx = 0;
		this.posy = 0;
		setObstacles(obstacles);
	}

	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given 
		 * the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		char d = 'N'; //N=0, E=1, S=2, w=3
		if(direction==0)
			d='N';
		if(direction==1)
			d='E';
		if(direction==2)
			d='S';
		if(direction==3)
			d='W';
		if(!command.isEmpty()){
		String obs = new String();
		char com = command.charAt(0);
		if (com == 'f' || com == 'b')
			move(com);
		else
			changeDirection(com);
		}
		return "("+posx+","+posy+","+d+")";
	}
	
	private void setObstacles(String obs)
	{
		int x, y;
		obs = obs.replace('(', ',');
		obs = obs.replace(')', ',');
		obs = obs.replaceAll(",", "");
		for(int i=0; i < obs.length()/2; i++)
		{
			x=Character.getNumericValue(obs.charAt(i));
			y=Character.getNumericValue(obs.charAt(i+1));
			this.grid[x][y] = true;
		}
	}
	
	private void changeDirection(char d)
	{
		if(d == 'r') {
			switch (this.direction){
				case 0: this.setFacing('E'); break;
				case 1: this.setFacing('W'); break;
				case 2: this.setFacing('S'); break;
				case 3: this.setFacing('N'); break;
			}
		}
		else {
			switch (this.direction){ //left
				case 0: this.setFacing('W'); break;
				case 1: this.setFacing('E'); break;
				case 2: this.setFacing('N'); break;
				case 3: this.setFacing('S'); break;
			}
		}
	}
	
	private void move(char m)
	{
		int x, y;
		if(m == 'f') {
			x = this.getX() + 1;
			y = this.getY() + 1;
			if(this.grid[x][y] == true)
				this.setFacing(1);
			
		}
		else {
			this.setX(this.getX() - 1);
			this.setY(this.getY() - 1);
		}
	}
	
	//set the Rover in column X
	public void setX(int x) {
		this.posx = x;
	}
	
	//set the Rover in row Y
	public int getY() {
		return this.posy;
	}
	
	//set the Rover in column X
	public int getX() {
		return this.posx;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		this.posy = y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(int direction) {
		this.direction = direction;
	}
	
	public int getFacing() {
		return this.direction;
	}
}

