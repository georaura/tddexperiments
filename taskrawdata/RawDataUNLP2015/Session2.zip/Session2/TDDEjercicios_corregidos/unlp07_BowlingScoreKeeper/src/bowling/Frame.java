package bowling;


public class Frame {
	
	private int firstThrow;
	private int secondThrow;
	
	private Frame nextFrame;
	
	private boolean isLastFrame = false;
	private boolean isBonusFrame = false;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		this.secondThrow = secondThrow;
	}
	
	public static Frame getLastFrame(int firstThrow, int secondThrow, Frame previousFrame){
		Frame lastFrame = new Frame(firstThrow, secondThrow);
		lastFrame.setLastFrame(true);
		
		previousFrame.setNextFrame(lastFrame);
		
		return lastFrame;
	}
	
	public static Frame getBonusFrame(int firstThrow, int secondThrow, Frame previousFrame){
		Frame lastFrame = new Frame(firstThrow, secondThrow);
		lastFrame.setBonusFrame(true);
		
		previousFrame.setNextFrame(lastFrame);
		
		return lastFrame;
	}
	
	//getters
	 public int getThrow1() {
        return firstThrow;
    }

    public int getThrow2() {
        return secondThrow;
    }
    
	public Frame getNextFrame() {
		return nextFrame;
	}

	public void setNextFrame(Frame nextFrame) {
		this.nextFrame = nextFrame;
	}
	
	public void setLastFrame(boolean isLastFrame) {
		this.isLastFrame = isLastFrame;
	}

	public boolean isBonusFrame() {
		return isBonusFrame;
	}

	public void setBonusFrame(boolean isBonusFrame) {
		this.isBonusFrame = isBonusFrame;
	}

	//the score of a single frame
	public int score(){
		return this.getThrow1() + this.getThrow2();
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		return this.getThrow1() == 10;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		return this.getThrow1() < 10 && this.getThrow1() + this.getThrow2() == 10;
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		return this.isLastFrame;
	}

	//bonus throws
	public int bonus() {
		if (!this.isBonusFrame()) {
			if (this.isSpare()) {
				return nextFrame.getThrow1();
			}
			if (this.isStrike()) {
				if (this.isLastFrame()) {
					return nextFrame.score();
				}
				
				if (nextFrame.isStrike()) {
					return nextFrame.score() + nextFrame.getNextFrameFirstThrow();
				}
				
				return nextFrame.score();
			}
		}
		
		return 0;
	}
	
	private int getNextFrameFirstThrow() {
		return this.getNextFrame().getThrow1();
	}

	public int getTotalScore() {
		if (this.isBonusFrame()) {
			return 0;
		}
		return this.score() + this.bonus();
	}

}
