package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	private Frame lastFrameAdded = null; 
	
	public List<Frame> getFrames() {
		return frames;
	}

	public void setFrames(List<Frame> frames) {
		this.frames = frames;
	}

	public Frame getBonus() {
		return bonus;
	}

	public void setBonus(Frame bonus) {
		this.getLastFrameAdded().setNextFrame(bonus);
		bonus.setBonusFrame(true);
		this.bonus = bonus;
	}

	public BowlingGame() {}
	
	public void addFrame(Frame frame) {
		if (this.getLastFrameAdded() != null) {
			this.getLastFrameAdded().setNextFrame(frame);
		}
		
		if (isNextFrameBonus()) {
			this.setBonus(frame);
		} else {
			if (isNextFrameLast()) {
				frame.setLastFrame(true);
			}
			this.getFrames().add(frame);
		}
		this.setLastFrameAdded(frame);
	}
	
	public void addFrame(int firstThrow, int secondThrow) {
		this.addFrame(new Frame(firstThrow, secondThrow));
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		this.setBonus(new Frame(firstThrow, secondThrow));
	}
	
	public int score(){
		int result = 0;
		for (Frame each : this.getFrames()) {
			result += each.getTotalScore();
		}
		
		return result;
	}
	
	public boolean isNextFrameLast(){
		return this.getFrames().size() == 9;
	}
	
	public boolean isNextFrameBonus(){
		return this.getFrames().size() == 10;
	}

	private Frame getLastFrameAdded() {
		return lastFrameAdded;
	}

	private void setLastFrameAdded(Frame lastFrameAdded) {
		this.lastFrameAdded = lastFrameAdded;
	}
}
