package marsrover;

import java.util.ArrayList;
import java.util.List;

public class MarsRover {

	private int x;
	private int y;

	private Status currentStatus;

	private List<Obstacule> obstacles = new ArrayList<Obstacule>();

	public MarsRover(int x, int y, String obstacles) {
		/*
		 * x and y represent the size of the grid. Obstacles is a String
		 * formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no
		 * white spaces.
		 * 
		 * Example use: MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")
		 * //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8)
		 */

		this.setX(x);
		this.setY(y);
		currentStatus = new Status(0, 0, "N", this);
		this.configureObstacles(obstacles);
	}

	public String executeCommand(String command) {

		/*
		 * The command string is composed of "f" (forward), "b" (backward), "l"
		 * (left) and "r" (right) Example: The rover is on a 100x100 grid at
		 * location (0, 0) and facing NORTH. The rover is given the commands
		 * "ffrff" and should end up at (2, 2) facing East.
		 * 
		 * The return string is in the format:
		 * "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)" Where x and y are
		 * the final coordinates, facing is the current direction the rover is
		 * pointing to (N,S,W,E). The return string should also contain a list
		 * of coordinates of the encountered obstacles. No white spaces.
		 */

		for (char instrucion : command.toCharArray()) {
			this.executeOneCommand(String.valueOf(instrucion));
		}

		return this.getCurrentStatus().toString();
	}

	// set the Rover in column X
	public void setX(int x) {
		// to be implemented
		this.x = x;
	}

	// set the Rover in row Y
	public void setY(int y) {
		// to be implemented
		this.y = y;
	}

	// set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		// to be implemented
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public Status getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Status currentStatus) {
		this.currentStatus = currentStatus;
	}

	/**
	 * PRECONDICION: En command viene s�lo una instrucci�n.
	 * 
	 * @param command
	 */
	private void executeOneCommand(String command) {
		if (command.equals("")) {
			// Es el landing status
			this.getCurrentStatus().landing();
		} else if (command.equals("r")) {
			this.getCurrentStatus().turnRight();
		} else if (command.equals("l")) {
			this.getCurrentStatus().turnLeft();
		} else if (command.equals("f")) {
			this.getCurrentStatus().forward();
		} else if (command.equals("b")) {
			this.getCurrentStatus().backward();
		}
	}

	public String getStrObstacles() {
		String result = "";
		for (Obstacule obs: this.obstacles) {
			result = result.concat(obs.toString());
		}
		
		return result;
	}

	/**
	 * 
	 * @param strObstacles
	 */
	private void configureObstacles(String strObstacles) {
		if (!strObstacles.equals("")) {
			strObstacles = strObstacles.replace('(', ',');
			strObstacles = strObstacles.replace(')', ',');
			String[] numbers = strObstacles.split(",");

			boolean esCoorX = true;
			int obstacleX = 0;
			int obstacleY = 0;
			for (String number : numbers) {
				if (!number.equals("")) {
					int num = Integer.valueOf(number);
					if (esCoorX) {
						obstacleX = num;
						esCoorX = false;
					} else {
						obstacleY = num;
						this.obstacles.add(new Obstacule(obstacleX, obstacleY));
						esCoorX = true;
					}
				}
			}
		}

	}

	public List<Obstacule> getObstacles() {
		return obstacles;
	}

}
