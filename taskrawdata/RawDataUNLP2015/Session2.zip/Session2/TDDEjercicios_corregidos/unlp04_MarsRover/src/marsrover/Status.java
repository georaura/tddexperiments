package marsrover;

/**
 * 
 * @author postgrado
 * 
 */
public class Status {

	// Es la coordenada x en el planeta, por defecto 0
	private int x = 0;

	// Es la coordenada y en el planeta, por defecto 0
	private int y = 0;

	// Es la orientacion del bichito, puede ser 'E'. 'W', 'N', 'S'. Por defecto
	// 'N'
	private String orientation = "N";

	private MarsRover marsRover;

	public Status(int x, int y, String orientation, MarsRover marsRover) {
		this.x = x;
		this.y = y;
		this.orientation = orientation;
		this.marsRover = marsRover;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getOrientation() {
		return orientation;
	}

	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}

	public void landing() {
		this.x = 0;
		this.y = 0;
		this.orientation = "N";
	}

	public void turnRight() {
		if (this.orientation.equals("N")) {
			this.orientation = "E";
		} else if (this.orientation.equals("E")) {
			this.orientation = "S";
		} else if (this.orientation.equals("S")) {
			this.orientation = "W";
		} else {
			// La orientaci�n es Oeste "W"
			this.orientation = "N";
		}
	}

	public void turnLeft() {
		if (this.orientation.equals("N")) {
			this.orientation = "W";
		} else if (this.orientation.equals("W")) {
			this.orientation = "S";
		} else if (this.orientation.equals("S")) {
			this.orientation = "E";
		} else {
			// La orientaci�n es Oeste "E"
			this.orientation = "N";
		}
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		sb.append(x).append(",").append(y).append(",").append(this.orientation);
		sb.append(")");

		return sb.toString();
	}

	public void forward() {
		if (this.orientation.equals("N")) {
				this.y = this.y + 1;
		} else if (this.orientation.equals("E")) {
				this.x = this.x + 1;
		} else if (this.orientation.equals("S")) {
				this.y = this.y - 1;
		} else {
			// La orientaci�n es Oeste "W"
				this.x = this.x - 1;
		}

		this.checkLimits();
	}

	public void backward() {
		if (this.orientation.equals("N")) {
			this.y = this.y - 1;
		} else if (this.orientation.equals("E")) {
			this.x = this.x - 1;
		} else if (this.orientation.equals("S")) {
			this.y = this.y + 1;
		} else {
			// La orientaci�n es Oeste "W"
			this.x = this.x + 1;
		}

		this.checkLimits();
	}

	/**
	 * Acomoda los l�mites de x e y si para no caerme del planeta.
	 */
	private void checkLimits() {
		if (this.y > marsRover.getY()) {
			this.y = 0;
		} else if (this.y < 0) {
			this.y = 99;
		}

		if (this.x > marsRover.getX()) {
			this.x = 0;
		} else if (this.x < 0) {
			this.x = 99;
		}
	}

	private boolean hayObstaculo(int x, int y) {
		for (Obstacule obs : marsRover.getObstacles()) {
			if (obs.esObstaculo(x, y)) {
				return true;
			}
		}

		return false;
	}
}
