package marsrover;

/**
 * 
 * @author postgrado
 *
 */
public class Obstacule {

	private int x;
	
	private int y;
	
	public Obstacule(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		sb.append(x).append(",").append(y);
		sb.append(")");

		return sb.toString();
	}	
	
	/**
	 * 
	 * @return
	 */
	public boolean esObstaculo(int x, int y) {
		return (this.x == x) && (this.y == y);
	}
}
