package marsroveracceptancetest;

import org.junit.Statistical;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;


public class AllTestsPlugin {
	
	public AllTestsPlugin() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Statistical es=  Statistical.getInstance();
		es.initSendStatics();
		Result result = JUnitCore.runClasses(US01.class,US02.class,US03.class,US04.class,US05.class,
				US06.class,US07.class,US08.class,US09.class,US10.class,US11.class);
		
	    for (Failure failure : result.getFailures()) {
	      System.out.println(failure.toString());
	    }
	}

}
