package marsroveracceptancetest;

import marsrover.MarsRover;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US09
{

    public US09()
    {
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingForwardRight()
    {
        String rightEdgeObstacle = Commons.generateObstacleInPosition(99, 50);
        MarsRover roverR = new MarsRover(100, 100, rightEdgeObstacle);
        try
        {
            MatcherAssert.assertThat(roverR.executeCommand(Commons.goToMiddleRightBorderFromWest()), Matchers.anyOf(Matchers.equalToIgnoringCase("(98,50,N)(99,50)"), Matchers.equalToIgnoringCase("(98,50,E)(99,50)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat(roverT.executeCommand(Commons.goToMiddleTopBorderFromWest()), Matchers.anyOf(Matchers.equalToIgnoringCase("(49,99,N)(50,99)"), Matchers.equalToIgnoringCase("(49,99,E)(50,99)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat(roverB.executeCommand(Commons.goToMiddleBottomBorderFromWest()), Matchers.anyOf(Matchers.equalToIgnoringCase("(49,0,N)(50,0)"), Matchers.equalToIgnoringCase("(49,0,E)(50,0)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheCornersOfThePlanetWhileMovingBackwardsRight()
    {
        String topRightCornerObstacle = Commons.generateObstacleInPosition(99, 99);
        String bottomRightCornerObstacle = Commons.generateObstacleInPosition(99, 0);
        MarsRover roverR = new MarsRover(100, 100, topRightCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(98,99,W)(99,99)", Matchers.is(Matchers.equalToIgnoringCase(roverR.executeCommand(Commons.goToTopRightCornerFromWestBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover roverT = new MarsRover(100, 100, bottomRightCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(98,0,W)(99,0)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToBottomRightCornerFromWestBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingBackwardRight()
    {
        String rightEdgeObstacle = Commons.generateObstacleInPosition(99, 50);
        MarsRover roverR = new MarsRover(100, 100, rightEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(98,50,W)(99,50)", Matchers.is(Matchers.equalToIgnoringCase(roverR.executeCommand(Commons.goToMiddleRightBorderFromWestBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(49,99,W)(50,99)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToMiddleTopBorderFromWestBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(49,0,W)(50,0)", Matchers.is(Matchers.equalToIgnoringCase(roverB.executeCommand(Commons.goToMiddleBottomBorderFromWestBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
}