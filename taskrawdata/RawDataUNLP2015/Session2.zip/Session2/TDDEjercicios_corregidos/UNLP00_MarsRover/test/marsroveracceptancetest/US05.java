package marsroveracceptancetest;

import marsrover.MarsRover;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class US05
{

    public US05()
    {
    }

    @Before
    public void setUp()
    {
        rover = new MarsRover(100, 100, "");
    }

    @Test
    public void moveLeftInsideGridOnClearPathNorthBounded()
    {
        rover.executeCommand("fffffrffffffffff");
        rover.executeCommand("ll");
        try
        {
            MatcherAssert.assertThat("(9,5,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(10,5,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void moveLeftInsideGridOnClearPathSouthBounded()
    {
        rover.executeCommand("fffffrffffffffff");
        rover.executeCommand("rr");
        try
        {
            MatcherAssert.assertThat("(9,5,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(10,5,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void moveRightInsideGridOnClearPathNorthBounded()
    {
        rover.executeCommand("fffffr");
        try
        {
            MatcherAssert.assertThat("(5,5,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("fffff"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(4,5,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void moveRightInsideGridOnClearPathSouthBounded()
    {
        rover.executeCommand("fffffrffffffffff");
        rover.executeCommand("rf");
        rover.executeCommand("l");
        try
        {
            MatcherAssert.assertThat("(11,4,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(10,4,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    MarsRover rover;
}