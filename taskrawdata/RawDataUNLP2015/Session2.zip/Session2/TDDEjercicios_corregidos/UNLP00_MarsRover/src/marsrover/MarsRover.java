package marsrover;

public class MarsRover {

	private String directions = "NESW";
	// dimensiones y obstaculos del planeta
	private int xLimit;
	private int yLimit;
	private String obstcles;

	// posision y direccion del mars rover
	private int xPosition;
	private int yPosition;
	private char facing;

	public int getxLimit() {
		return xLimit;
	}

	public void setxLimit(int xLimit) {
		this.xLimit = xLimit;
	}

	public int getyLimit() {
		return yLimit;
	}

	public void setyLimit(int yLimit) {
		this.yLimit = yLimit;
	}

	public String getObstcles() {
		return obstcles;
	}

	public void setObstcles(String obstcles) {
		this.obstcles = obstcles;
	}

	public int getxPosition() {
		return xPosition;
	}

	public int getyPosition() {
		return yPosition;
	}

	public char getFacing() {
		return facing;
	}

	public MarsRover(int x, int y, String obstacles) {
		/*
		 * x and y represent the size of the grid. Obstacles is a String
		 * formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no
		 * white spaces.
		 * 
		 * Example use: MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")
		 * //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8)
		 */
		super();
		this.setX(0);
		this.setY(0);
		this.setFacing('N');
		this.setxLimit(x);
		this.setyLimit(y);
		this.setObstcles(obstacles);
	}

	public String executeCommand(String command) {

		/*
		 * The command string is composed of "f" (forward), "b" (backward), "l"
		 * (left) and "r" (right) Example: The rover is on a 100x100 grid at
		 * location (0, 0) and facing NORTH. The rover is given the commands
		 * "ffrff" and should end up at (2, 2) facing East.
		 * 
		 * The return string is in the format:
		 * "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)" Where x and y are
		 * the final coordinates, facing is the current direction the rover is
		 * pointing to (N,S,W,E). The return string should also contain a list
		 * of coordinates of the encountered obstacles. No white spaces.
		 */
		for (char single : command.toCharArray()) {
			if (this.isDirectionChange(single)) {
				this.changeDirection(single);
			} else {
				this.move(single);
			}
		}
		String result = "(" + this.getxPosition() + "," + this.getyPosition()
				+ "," + this.getFacing() + ")";
		return result;
	}

	private void changeDirection(char single) {
		int newDirection;
		if (single == 'r' && (this.getFacing() != 'W')) {
			this.setFacing(directions.charAt(directions.indexOf(getFacing()) + 1));
		} else if (single == 'l' && (this.getFacing() != 'N')) {
			this.setFacing(directions.charAt(directions.indexOf(getFacing()) - 1));
		} else if (single == 'r' && (this.getFacing() == 'W')) {
			this.setFacing('N');
		} else {
			this.setFacing('W');
		}
	}

	private boolean isDirectionChange(char single) {
		return (single == 'r' || single == 'l');
	}

	private void move(char single) {
		if (single == 'f') {
			this.moveForeward();
		}
		else {
			this.moveBackward();
		}
	}

	private void moveBackward() {
		if (this.getFacing()=='N'&& this.getyPosition()==0) {
			this.setY(this.getyLimit());
		}
		else if (this.getFacing()=='S'&& this.getyPosition()==this.getyLimit()) {
			this.setX(0);
		}
		else if (this.getFacing()=='E'&& this.getxPosition()==0) {
			this.setX(this.getxLimit());
		}
		else if (this.getFacing()=='W'&& this.getxPosition()==this.getxLimit()) {
			this.setX(0);
		}
		else if (this.getFacing()=='N') {
			this.setY(getyPosition()-1);
		}
		else if (this.getFacing()=='E') {
			this.setX(getxPosition()-1);
		}
		else if (this.getFacing()=='S') {
			this.setY(getyPosition()+1);
		}
		else if (this.getFacing()=='N') {
			this.setX(getxPosition()+1);
		}
	}

	private void moveForeward() {
		if (this.getFacing()=='N'&& this.getyPosition()==this.getyLimit()) {
			this.setY(0);
		}
		else if (this.getFacing()=='S'&& this.getyPosition()==0) {
			this.setX(this.getyLimit());
		}
		else if (this.getFacing()=='E'&& this.getxPosition()==this.getxLimit()) {
			this.setX(0);
		}
		else if (this.getFacing()=='W'&& this.getxPosition()==0) {
			this.setX(this.getxLimit());
		}
		else if (this.getFacing()=='N') {
			this.setY(getyPosition()+1);
		}
		else if (this.getFacing()=='E') {
			this.setX(getxPosition()+1);
		}
		else if (this.getFacing()=='S') {
			this.setY(getyPosition()-1);
		}
		else if (this.getFacing()=='N') {
			this.setX(getxPosition()-1);
		}
	}

	// set the Rover in column X
	public void setX(int x) {
		xPosition = x;
	}

	// set the Rover in row Y
	public void setY(int y) {
		yPosition = y;
	}

	// set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		facing = direction;
	}

}
