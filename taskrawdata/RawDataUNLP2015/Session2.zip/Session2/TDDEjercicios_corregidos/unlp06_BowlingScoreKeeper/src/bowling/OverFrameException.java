package bowling;

public class OverFrameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OverFrameException(String string) {
		super(string);
	}

}
