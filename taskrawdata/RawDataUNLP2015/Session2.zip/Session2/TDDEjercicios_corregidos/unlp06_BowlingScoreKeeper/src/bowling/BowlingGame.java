package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	//a bowling game is made of (at least) 10 frames
	private List<Frame> frames = new ArrayList<Frame>();
	private Frame bonus;
	
	public BowlingGame(){}
	
	public void addFrame(Frame frame) throws OverFrameException{
		
		
		if (this.framesSize() < 10){
			this.setUpNextFrame(frame);
			this.frames.add(frame);
		} else {
			if(bonus == null && this.framesSize() == 10  && frame.isLastFrame()){
				this.setUpNextFrame(frame);
				this.bonus = frame;
			} else {
				//throw new OverFrameException("Frame de m�s");
				System.out.println("Frame de m�s");
			
			}
		}
		
	}
	
	public void setBonus(int firstThrow, int secondThrow) {
		//to be implemented
	}
	
	public int score(){
		int score = 0;
		try{
		if (!this.frames.isEmpty()){
			for (Frame frame : this.frames) {
				score += frame.score();
			}
		}
		}
		catch(Exception e){
			System.out.println("Error en el �ndice del arreglo");
		}
		return score;
	}
	
	public boolean isNextFrameBonus(){
		return false;
	}
	
	public int framesSize(){
		int framesSize = this.frames.size();
		if (this.bonus != null){
			framesSize ++;
		}
		return framesSize;
	}
	
	/**
	 * Obtiene el �ltimo frame de la lista
	 * @return
	 */
	private Frame getLastFrame(){
		if(!this.frames.isEmpty()){
			return this.frames.get(this.frames.size() - 1);
		}
		return null;
	}
	
	/**
	 * Agrega como siguiente frame al frame pasado por par�metro al �ltimo de la lista
	 * @param frame
	 */
	private void setUpNextFrame(Frame frame) {
		Frame lastFrame = this.getLastFrame();
		if (lastFrame != null){
			lastFrame.setNext(frame);
		}
	}
}
