package bowling;


public class Frame {
	private int firstThrow;
	private int secondThrow;
	private int thirdThrow;
	
	private boolean isLastFrame = false;
	private Frame next;
	private int bonus = 0;
	
	public Frame(){
		this.firstThrow = 0;
		this.secondThrow = 0;
	}
	
	public Frame(int firstThrow, int secondThrow){
		this.firstThrow = firstThrow;
		this.secondThrow = secondThrow;
	}
	//getters
	public int getThrow1() {
		return firstThrow;
	}

     public int getThrow2() {
        return secondThrow;
    }
    
     public int getThrow3() {
 		return thirdThrow;
 	}
     
     public void setThrow3(int thirdThrow){
    	 this.thirdThrow = thirdThrow;
     }
     
	//the score of a single frame
	public int score(){
		this.setUpBonus();
		if (this.isLastFrame){
			return this.getThrow1() + this.bonus;
		}
		return this.getThrow1() + this.getThrow2() + this.bonus;
	}
	
   	//returns whether the frame is a strike or not
	public boolean isStrike(){
		return this.getThrow1() == 10;
	}
	
	//return whether a frame is a spare or not
	public boolean isSpare(){
		if (this.isStrike()){
			return false;
		} else {
			return this.getThrow1() + this.getThrow2() == 10;
		}
	}

	//return whether this is the last frame of the match
	public boolean isLastFrame(){
		return this.isLastFrame;
	}

	//bonus throws
	public int bonus(){
		return this.bonus;
	}

	public void setAsLastFrame() {
		this.isLastFrame = true;
	}

	public Frame getNext() {
		return next;
	}

	public void setNext(Frame next) {
		this.next = next;
	}

	public void setUpBonus() {
		if (this.isSpare()){
			if (!this.isLastFrame()){
				this.bonus = this.getNext().getThrow1();
			} else {
				this.bonus = this.getThrow3();
			}
		}
		if (this.isStrike()){
			if(!this.isLastFrame()){
				this.bonus = this.getThrow2() + this.getNext().getThrow1();
			} else {
				this.bonus = this.getThrow2() + this.getThrow3();
			}
		}	
	}

}
