package bowlingacceptancetest;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;

public class US03 {

	@Test
	public void testGameWithFramesIsCreated() throws Exception {
		BowlingGame game = new BowlingGame();
		for (int i = 0; i < 10; i++) {
			game.addFrame(new Frame(i,i));
		}
		
		try
        {
			assertNotNull(game);
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	
	@Test
	public void testEmptyGameIsCreated(){
		BowlingGame game = new BowlingGame();
		try
        {
			assertNotNull(game);
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	
	// Commented by Oscar
	// Class name is irrelevant in the context of our experiment
	@Ignore
	@Test 
	public void testGameObjectIsCreated(){
		BowlingGame game = new BowlingGame();
		try
        {
			assertEquals("BowlingGame", game.getClass().getSimpleName());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	
	}
}
