package bowling;

import java.util.ArrayList;

public class BowlingGame {
	int cantFrames = 10;
	public ArrayList<Frame> listaFrames;
	public Frame frameActualFrame;
		public BowlingGame() {
			listaFrames = new ArrayList<Frame>();
	    } 

	    public void setBonus(int firstThrow, int secondThrow) {
	        // to be implemented
	    	if (!isGameFinished()==true) {
	    		Frame frameNew = new Frame(firstThrow,secondThrow);
		    	addFrame(frameNew);
		    	frameActualFrame = frameNew;
			}
	    	
	    }

	    public int score() {
	    	// to be implemented
	    	int score = 0;
	    	for (int i = 0; i < listaFrames.size(); i++) {
	    		
//				score += listaFrames(i).score();
	    		score = listaFrames.get(i).score();
			}
	        return score;
	    }

	    public boolean isNextFrameBonus() {
	        // to be implemented
	        return false;
	    }

	    public boolean isGameFinished() {
	    	// to be implemented
	    	boolean isGameFinished = false;
	    	if (listaFrames.size() >= cantFrames) {
	    		isGameFinished = true;
	    	}
	        return isGameFinished;
	    }

		public void addFrame(Frame frame) {
			// to be implemented
			listaFrames.add(frame);
		}


}
