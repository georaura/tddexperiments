package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US11
{

    public US11()
    {
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnNorthWhileGoingForward()
    {
        MarsRover rover = new MarsRover(100, 100, "(0,99)");
        MatcherAssert.assertThat("(0,0,S)(0,99)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("llf"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnSouthWhileGoingForward()
    {
        MarsRover rover = new MarsRover(100, 100, "(1,0)");
        rover.executeCommand(Commons.goToTopLeftCornerFromSouth());
        rover.executeCommand("rfl");
        MatcherAssert.assertThat("(1,99,N)(1,0)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnNorthWhileGoingBackward()
    {
        MarsRover rover = new MarsRover(100, 100, "(0,99)");
        MatcherAssert.assertThat("(0,0,N)(0,99)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
    }
    
    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnSouthWhileGoingBackward()
    {
        MarsRover rover = new MarsRover(100, 100, "(1,0)");
        rover.executeCommand(Commons.goToTopLeftCornerFromSouth());
        rover.executeCommand("rfl");
        MatcherAssert.assertThat("(1,99,S)(1,0)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("llb"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnWestGoingForward()
    {
        MarsRover rover = new MarsRover(100, 100, "(0,30)");
        rover.executeCommand("r");
        rover.executeCommand(Commons.generateCommand(99, "f"));
        rover.executeCommand("l");
        rover.executeCommand(Commons.generateCommand(30, "f"));
        rover.executeCommand("r");
        MatcherAssert.assertThat("(99,30,E)(0,30)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnWestGoingBackward()
    {
        MarsRover rover = new MarsRover(100, 100, "(0,30)");
        rover.executeCommand("r");
        rover.executeCommand(Commons.generateCommand(99, "f"));
        rover.executeCommand("l");
        rover.executeCommand(Commons.generateCommand(30, "f"));
        rover.executeCommand("r");
        MatcherAssert.assertThat("(99,30,W)(0,30)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("llb"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnEastGoingForward()
    {
        MarsRover rover = new MarsRover(100, 100, "(99,30)");
        rover.executeCommand(Commons.generateCommand(30, "f"));
        rover.executeCommand("l");
        MatcherAssert.assertThat("(0,30,W)(99,30)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
    }

    @Test
    public void roverEncountersAnObstacleWhenTriesToSpawnEastGoingBackward()
    {
        MarsRover rover = new MarsRover(100, 100, "(99,30)");
        rover.executeCommand(Commons.generateCommand(30, "f"));
        rover.executeCommand("l");
        MatcherAssert.assertThat("(0,30,E)(99,30)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("llb"))));
    }
}