package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US10
{

    public US10()
    {
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingForwardLeft()
    {
        String leftEdgeObstacle = Commons.generateObstacleInPosition(0, 50);
        MarsRover roverL = new MarsRover(100, 100, leftEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(1,50,N)(0,50)", Matchers.is(Matchers.equalToIgnoringCase(roverL.executeCommand(Commons.goToMiddleLeftBorderCommandFromEast()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(51,99,N)(50,99)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToMiddleTopBorderFromEast()))));

        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(51,0,N)(50,0)", Matchers.is(Matchers.equalToIgnoringCase(roverB.executeCommand(Commons.goToMiddleBottomBorderFromEast()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheCornersOfThePlanetWhileMovingForwardLeft()
    {
        String topLeftCornerObstacle = Commons.generateObstacleInPosition(0, 99);
        MarsRover roverL = new MarsRover(100, 100, topLeftCornerObstacle);
        MatcherAssert.assertThat("(1,99,W)(0,99)", Matchers.is(Matchers.equalToIgnoringCase(roverL.executeCommand(Commons.goToTopLeftCornerFromEast()))));
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingBackwardLeft()
    {
        String leftEdgeObstacle = Commons.generateObstacleInPosition(0, 50);
        MarsRover roverL = new MarsRover(100, 100, leftEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(1,50,E)(0,50)", Matchers.is(Matchers.equalToIgnoringCase(roverL.executeCommand(Commons.goToMiddleLeftBorderCommandFromEastBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(51,99,E)(50,99)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand((new StringBuilder(String.valueOf(Commons.goToTopRightCornerFromSouth()))).append("r").append(Commons.generateCommand(49, "b")).toString()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(51,0,E)(50,0)", Matchers.is(Matchers.equalToIgnoringCase(roverB.executeCommand(Commons.goToMiddleBottomBorderFromEastBackwards()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
}