package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test; 

public class US01
{

    @Before
    public void setup()
    {
        this.rover = new MarsRover(100, 100, "");
    }

    @Test
    public void theRoverStaysAtOriginOnceLandedAndExecutedAnEmptyCommand()
    {
        MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand(""))));
    }

    MarsRover rover;
}