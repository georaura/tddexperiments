package tdd.training.espe;
public class MarsRover {
	
	public char direccion;
	public int x;
	public int y;
	public int matriz[][];
	
	public MarsRover(){
		
	}
	
	public MarsRover(int x, int y, String obstacles){
		
		matriz = new int[x][y];
		
		obstacles=obstacles.replace("(", "");
		obstacles=obstacles.replace(")", "");
		
		 String[] values= obstacles.split(",");
		
		 for(int z=0; z<values.length; z++){
			 int valor=0;
			 try{
				 valor=Integer.parseInt(values[z]);
			 }
			 catch(Exception e){
				 System.out.print(e);
			 }
			 if(valor<10){
				 this.cargaObstaculo(0, valor);
			 }else{
				 String numero=valor+"";
				 this.cargaObstaculo(Integer.parseInt(numero.substring(0)), Integer.parseInt(numero.substring(1)));
			 }
		 }
		
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	}
	
	
	public String executeCommand(String command){
		
		 
		if(command.equalsIgnoreCase("")){
			setX(0);
			setY(0);
		}else{
			
		}
		
				
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		
		return "("+x+","+y+","+direccion+")";
	}
	
	//set the Rover in column X
	public void setX(int px) {
		x = px;
	}
	
	//set the Rover in row Y
	public void setY(int py) {
		y = py;
	}
	
	public void cargaObstaculo(int px,int py) {
		try{
		this.matriz[px][py]=1;
		}
		catch(Exception e){
			
		}
	}
		
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		this.direccion=direction;
	}
	
}