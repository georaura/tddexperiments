package tdd.training.espe;

public class MarsRover {
	public int[][] Planet;
	public int[] location;
	public String facing;
	
	public MarsRover(int x, int y, String obstacles){
		Planet=new int[x][y];
		facing="N";
		location=new int[]{0,0};
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	}
	
	public String executeCommand(String command){
		
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		if(command.equals(""))
			return "("+location[0]+","+location[1]+","+facing+")";
		
		for(int i=0;i<command.length();i++)
		{
			char direction=command.charAt(0);
			command=command.substring(1,(command.length()));
			if(direction=='l'||direction=='r')
			{
				setFacing(direction);
			}
			else if(direction=='f'||direction=='b')
			{
				avanzar(direction);
			}
		}
		
		return "("+location[0]+","+location[1]+","+facing+")";
	}
	
	//set the Rover in column X
	public void setX(int x) {
		//to be implemented
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		//to be implemented
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		//to be implemented
		switch (direction) {
		case 'r':
			switch (this.facing) {
			case "N":
				this.facing="E";
				break;
			case "E":
				this.facing="S";
				break;
			case "S":
				this.facing="W";
				break;
			case "W":
				this.facing="N";
				break;
			}
			break;
			
		case 'l':
			switch (this.facing) {
			case "N":
				this.facing="W";
				break;
			case "E":
				this.facing="N";
				break;
			case "S":
				this.facing="E";
				break;
			case "W":
				this.facing="S";
				break;
			}
			break;

		default:
			break;
		}
	}
	
//set the Rover's avance to f or b
public void avanzar(char direction) {
	//to be implemented
		this.location[(this.facing=="N"||this.facing=="S"?1:0)]+=1*(direction=='f'?1:-1);
}

}
