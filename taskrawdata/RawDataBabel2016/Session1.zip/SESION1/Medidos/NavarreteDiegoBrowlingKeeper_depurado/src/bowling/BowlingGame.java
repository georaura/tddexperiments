package bowling;
import java.util.ArrayList;
import java.util.List;

public class BowlingGame {
	
	List<Frame> Jugadas; 
	int totalScore;
	boolean termino;
	boolean esStrike;
	boolean esSpare;

    public BowlingGame() {
    	// to be implemented
    	 Jugadas=new ArrayList<Frame>();
    	 totalScore=0;
    	 termino=false;
    } 

    public void setBonus(int firstThrow, int secondThrow) {
        // to be implemented
    	int suma= firstThrow+  secondThrow;
    	if(firstThrow==10|| secondThrow==10 ){
    		esStrike=true;	
    	}
    	
    	if(suma==10){
    		esSpare=true;
    	}

    
    }

    public int score() {
    	
    
    	// to be implemented
        return 0;
    }

    public boolean isNextFrameBonus() {
        // to be implemented
    
        return false;
        
    }

    public boolean isGameFinished() {
    	
    	if(Jugadas.size()==10){
    		termino=true;
    	}else{
    		termino=false;
    	}
    	// to be implemented
        return termino;
        
    }

	public void addFrame(Frame frame) {
		
		// to be implemented
		if(Jugadas.size()<11){
		Jugadas.add(frame);
		}
		
	}
}
