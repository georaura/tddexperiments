package bowling;

public class Frame {

	int getThrow1;
	int getThrow2;
	int frameNumber;
	public Frame() {
		frameNumber = 0;
	}

    public Frame(int i, int j) {
    	getThrow1 += i;
    	getThrow2 += j;
    	getThrow1();
    	frameNumber ++;
	}
    
    public int score() {
        if((getThrow1() + getThrow2) == 10){
        	BowlingGame bowl = new BowlingGame();
        	bowl.addFrame(this);
        	return 10;
        }else{
        	return getThrow1() + getThrow2();
        }
    }

	public int getThrow1() {
		//getThrow2();
		return getThrow1;
	}

	public int getThrow2() {
		//score();
		return getThrow2;
	}
}
