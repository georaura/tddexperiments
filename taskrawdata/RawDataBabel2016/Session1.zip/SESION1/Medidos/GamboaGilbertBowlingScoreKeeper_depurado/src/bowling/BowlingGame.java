package bowling;
public class BowlingGame {

	int result = 0;
	int frameNumber;
	
    public BowlingGame() {
    	frameNumber = 0;
    } 

    public void setBonus(int firstThrow, int secondThrow) {
        Frame frame = new Frame();
        if(isNextFrameBonus() == true){
        	if(frame.getThrow1() == 10 || frame.getThrow2() == 10){
        		result = firstThrow + secondThrow;
        		score();
        	}else{
        		result = firstThrow;
        		score();
        	}
        }
    }

    public int score() {
        return result;
    }

    public boolean isNextFrameBonus() {
    	Frame frame = new Frame();
        if(frame.score() == 10){
        	return true;
        } else {
        	return false;
        }
    }

    public boolean isGameFinished() {
    	if(frameNumber == 10){
    		return true;
        }else{
        	return false;
        }
    }

	public void addFrame(Frame frame) {
		if(isGameFinished() == false){
			setBonus(frame.getThrow1(), frame.getThrow2());
		}
	}
}
