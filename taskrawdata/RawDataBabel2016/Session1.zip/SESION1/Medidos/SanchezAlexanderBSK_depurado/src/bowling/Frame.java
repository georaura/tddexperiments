package bowling;

public class Frame {
	int i;
	int j;
	public Frame() {
		i=0;
		j=0;
	}

    public Frame(int i, int j) {
    	this.i=i;
    	this.j=j;
	}
    
    public int score() {
    	//to be implemented
        return i+j;
    }

	public int getThrow1() {
		//to be implemented
		return i;
	}

	public int getThrow2() {
		//to be implemented
		return j;
	}
}