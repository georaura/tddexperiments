package tdd.training.espe;
public class MarsRover {
	int matriz [][];
	int posX = 0;
	int posY = 0;
	char f = 'N';
	String miPosicion = "";
	public MarsRover(int x, int y, String obstacles){
	/*	x and y represent the size of the grid.
	 *  Obstacles is a String formatted as follows: "(o1_x,o1_y)(o2_x,o2_y)...(on_x,on_y)" with no white spaces. 
	 *  
		Example use:
		MarsRover rover = new MarsRover(100,100,"(5,5)(7,8)")  //A 100x100 grid with two obstacles at coordinates (5,5) and (7,8) 
	 */
	 matriz  = new int [x][y];
	}
	
	public String executeCommand(String command){
		setX(0);
		setY(0);
		setFacing('N');
		/* The command string is composed of "f" (forward), "b" (backward), "l" (left) and "r" (right)
		 * Example: 
		 * The rover is on a 100x100 grid at location (0, 0) and facing NORTH. The rover is given the commands "ffrff" and should end up at (2, 2) facing East.
		 
		 * The return string is in the format: "(x,y,facing)(o1_x,o1_y)(o2_x,o2_y)..(on_x,on_y)"  
		 * Where x and y are the final coordinates, facing is the current direction the rover is pointing to (N,S,W,E).
		 * The return string should also contain a list of coordinates of the encountered obstacles. No white spaces.
		 */
		for(int i = 1; i<= command.length(); i++){
			switch (command.substring(i-1, i)){
			case "f":
				mover('f');
		        break;
		 
			case "l":
				rotar('l');
		       break;
			case "r":
				rotar('r');
		       break;
			case "b":
				mover('b');
		       break;
		    default:
		    	System.out.println("No ley�");
		        break; 
				
			}
			
		}
		
		 String posicion = "("+String.valueOf(posX)+","+String.valueOf(posY)+","+f+")";
		 System.out.println(posicion);
		return posicion;
	}
	
	//set the Rover in column X
	public void setX(int x) {
		posX = posX + x;
	}
	
	//set the Rover in row Y
	public void setY(int y) {
		posY =posY + y;
	}
	
	//set the Rover's direction to N, S, E, W
	public void setFacing(char direction) {
		f = direction;
	}
	
	public void mover(char direction){
	
		switch (f){
		case 'N':
			if(direction == 'f'){setY(1);}else{setY(-1);}
			break;
		case 'S':
			if(direction == 'f'){setY(-1);}else{setY(1);}
			break;
		case 'W':
			if(direction == 'f'){setX(1);}else{setX(-1);}
			break;
		case 'E':
			if(direction == 'f'){setX(-1);}else{setX(1);}
			break;
		
		}
		
	}
    public void rotar(char face){
		
		setFacing(face);
	}
	
}
