package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;

// Referenced classes of package marsroveracceptancetest:
//            Commons

public class US07
{

    public US07()
    {
    }
    
    @Test    
    public void theRoverEncountersAnObstacleOnTheEdgesOfThePlanetWhileMovingForward()
    {
        String topEdgeObstacle = Commons.generateObstacleInPosition(50, 99);
        MarsRover roverT = new MarsRover(100, 100, topEdgeObstacle);
        try
        {
            MatcherAssert.assertThat("(50,98,N)(50,99)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToMiddleTopBorderFromSouth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomEdgeObstacle = Commons.generateObstacleInPosition(50, 0);
        MarsRover roverB = new MarsRover(100, 100, bottomEdgeObstacle);
        try
        {
            MatcherAssert.assertThat(roverB.executeCommand(Commons.goToMiddleBottomBorderFromNorth()), Matchers.anyOf(Matchers.equalToIgnoringCase("(50,1,N)(50,0)"), Matchers.equalToIgnoringCase("(50,1,S)(50,0)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncountersAnObstacleOnTheCornersOfThePlanetWhileMovingForward()
    {
        String topLeftCornerObstacle = Commons.generateObstacleInPosition(0, 99);
        MarsRover roverL = new MarsRover(100, 100, topLeftCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(0,98,N)(0,99)", Matchers.is(Matchers.equalToIgnoringCase(roverL.executeCommand(Commons.goToTopLeftCornerFromSouth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String topRightCornerObstacle = Commons.generateObstacleInPosition(99, 99);
        MarsRover roverR = new MarsRover(100, 100, topRightCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(99,98,N)(99,99)", Matchers.is(Matchers.equalToIgnoringCase(roverR.executeCommand(Commons.goToTopRightCornerFromSouth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        String bottomRightCornerObstacle = Commons.generateObstacleInPosition(99, 0);
        MarsRover roverT = new MarsRover(100, 100, bottomRightCornerObstacle);
        try
        {
            MatcherAssert.assertThat("(99,1,S)(99,0)", Matchers.is(Matchers.equalToIgnoringCase(roverT.executeCommand(Commons.goToBottomRightCornerFromNorth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
    
    @Test
    public void theRoverEncountersAnObstacleInTheMiddleOfThePlanetWhileMovingForward()
    {
        String middleObstacle = Commons.generateObstacleInPosition(50, 50);
        MarsRover rover = new MarsRover(100, 100, middleObstacle);
        MarsRover rover2 = new MarsRover(100, 100, middleObstacle);
        MarsRover rover3 = new MarsRover(100, 100, middleObstacle);
        MarsRover rover4 = new MarsRover(100, 100, middleObstacle);
        try
        {
            MatcherAssert.assertThat("(49,50,E)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand(Commons.goToMiddleOfPlanetFromWest()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(50,51,S)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover2.executeCommand(Commons.goToMiddleOfPlanetFromNorth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(51,50,W)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover3.executeCommand(Commons.goToMiddleOfPlanetFromEast()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(50,49,N)(50,50)", Matchers.is(Matchers.equalToIgnoringCase(rover4.executeCommand(Commons.goToMiddleOfPlanetFromSouth()))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncounters2ObstaclesInARowFromLanding()
    {
        String firstObstacle = Commons.generateObstacleInPosition(0, 1);
        String secondObstacle = Commons.generateObstacleInPosition(1, 0);
        MarsRover rover = new MarsRover(100, 100, (new StringBuilder(String.valueOf(firstObstacle))).append(secondObstacle).toString());
        MatcherAssert.assertThat(rover.executeCommand("frfl"), Matchers.anyOf(Matchers.equalToIgnoringCase("(0,0,N)(0,1)(1,0)"), Matchers.equalToIgnoringCase("(0,0,N)(0,1)")));
    }

    @Test
    public void theRoverEncounters2ObstaclesInARow()
    {
        String firstHorizontalObstacle = Commons.generateObstacleInPosition(1, 1);
        String secondHorizontalObstacle = Commons.generateObstacleInPosition(3, 1);
        String firstVerticalObstacle = Commons.generateObstacleInPosition(1, 0);
        String secondVerticalObstacle = Commons.generateObstacleInPosition(1, 2);
        MarsRover roverH = new MarsRover(100, 100, (new StringBuilder(String.valueOf(firstHorizontalObstacle))).append(secondHorizontalObstacle).toString());
        try
        {
            MatcherAssert.assertThat(roverH.executeCommand("rflfrflfrflf"), Matchers.anyOf(Matchers.equalToIgnoringCase("(2,2,N)(1,1)(3,1)"), Matchers.equalToIgnoringCase("(1,0,N)(1,1)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover roverV = new MarsRover(100, 100, (new StringBuilder(String.valueOf(firstVerticalObstacle))).append(secondVerticalObstacle).toString());
        try
        {
            MatcherAssert.assertThat(roverV.executeCommand("rflfrflfrfl"), Matchers.anyOf(Matchers.equalToIgnoringCase("(2,1,N)(1,0)(1,2)"), Matchers.equalToIgnoringCase("(0,0,E)(1,0)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverEncounters3ObstaclesInARow()
    {
        String obstacle11 = Commons.generateObstacleInPosition(1, 1);
        String obstacle22 = Commons.generateObstacleInPosition(2, 2);
        String obstacle31 = Commons.generateObstacleInPosition(3, 1);
        String obstacle20 = Commons.generateObstacleInPosition(2, 0);
        MarsRover rover1 = new MarsRover(100, 100, (new StringBuilder(String.valueOf(obstacle11))).append(obstacle22).append(obstacle31).toString());
        try
        {
            MatcherAssert.assertThat(rover1.executeCommand("rfflfrflflfr"), Matchers.anyOf(Matchers.equalToIgnoringCase("(2,1,N)(3,1)(2,2)(1,1)"), Matchers.equalToIgnoringCase("(2,1,E)(3,1)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover rover2 = new MarsRover(100, 100, (new StringBuilder(String.valueOf(obstacle20))).append(obstacle22).append(obstacle31).toString());
        try
        {
            MatcherAssert.assertThat(rover2.executeCommand("rflfrfrflflf"), Matchers.anyOf(Matchers.equalToIgnoringCase("(2,1,N)(2,0)(3,1)(2,2)"), Matchers.equalToIgnoringCase("(2,1,S)(2,0)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        MarsRover rover3 = new MarsRover(100, 100, (new StringBuilder(String.valueOf(obstacle11))).append(obstacle20).append(obstacle31).toString());
        try
        {
            MatcherAssert.assertThat(rover3.executeCommand("ffrffrfrflflfl"), Matchers.anyOf(Matchers.equalToIgnoringCase("(2,1,N)(1,1)(2,0)(3,1)"), Matchers.equalToIgnoringCase("(2,1,W)(1,1)")));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
}