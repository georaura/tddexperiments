package tdd.training.espe;


public class Commons
{

    public Commons()
    {
    }

    static String goToMiddleOfPlanetFromSouthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleBottomBorderFromWest()))).append("rr").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromEastBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleRightBorderFromSouth()))).append("r").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromNorthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleTopBorderFromWest()))).append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromWestBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleLeftBorderCommandFromSouth()))).append("l").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromSouth()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleBottomBorderFromWest()))).append(generateCommand(50, "f")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromEast()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleRightBorderFromSouth()))).append("l").append(generateCommand(50, "f")).toString();
        return command;
    }

    static String goToMiddleOfPlanetFromNorth()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleTopBorderFromWest()))).append("ll").append(generateCommand(50, "f")).toString();
        return command;
    }

    static String goToBottomRightCornerFromNorthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCorner()))).append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToBottomRightCornerFromWestBackwards()
    {
        String command = (new StringBuilder("l")).append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToTopRightCornerFromSouthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToBottomRightCornerFromWest()))).append("r").append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToTopRightCornerFromWestBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopLeftCornerFromSouth()))).append("l").append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToTopLeftCornerFromEastBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCornerFromSouth()))).append("r").append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToTopLeftCornerFromSouthBackwards()
    {
        String command = (new StringBuilder("ll")).append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToBottomRightCornerFromNorth()
    {
        String command = (new StringBuilder("fr")).append(generateCommand(99, "f")).append("rf").toString();
        return command;
    }

    static String goToBottomRightCornerFromWest()
    {
        return (new StringBuilder(String.valueOf(goToBottomRightCorner()))).append("r").toString();
    }

    static String goToTopRightCornerFromSouth()
    {
        String command = (new StringBuilder(String.valueOf(goToBottomRightCorner()))).append(generateCommand(99, "f")).toString();
        return command;
    }

    static String goToTopRightCornerFromWest()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCorner()))).append("r").toString();
        return command;
    }

    static String goToTopLeftCornerFromEast()
    {
        String command = (new StringBuilder("rfl")).append(generateCommand(99, "f")).append("lf").toString();
        return command;
    }

    static String goToMiddleBottomBorderFromNorthBackwards()
    {
        String command = (new StringBuilder("fr")).append(generateCommand(50, "f")).append("lb").toString();
        return command;
    }

    static String goToMiddleBottomBorderFromEastBackwards()
    {
        String command = (new StringBuilder("fr")).append(generateCommand(99, "f")).append("rfl").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleBottomBorderFromWestBackwards()
    {
        String command = (new StringBuilder("l")).append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleTopBorderFromSouthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleBottomBorder()))).append("rr").append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToMiddleTopBorderFromEastBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCorner()))).append("r").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleTopBorderFromWestBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopLeftCornerFromSouth()))).append("l").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleTopBorderFromWest()
    {
        String command = (new StringBuilder(String.valueOf(generateCommand(99, "f")))).append("r").append(generateCommand(50, "f")).append("l").toString();
        return command;
    }

    static String goToMiddleRightBorderFromSouthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToBottomRightCorner()))).append("rr").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleRightBorderFromNorthBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCorner()))).append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleRightBorderFromWestBackwards()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleLeftBorderCommandFromSouth()))).append("l").append(generateCommand(99, "b")).toString();
        return command;
    }

    static String goToMiddleLeftBorderCommandFromEastBackwards()
    {
        String command = (new StringBuilder("rfl")).append(generateCommand(50, "f")).append("rb").toString();
        return command;
    }

    static String goToMiddleBottomBorderFromNorth()
    {
        String command = (new StringBuilder("fr")).append(generateCommand(50, "f")).append("rfll").toString();
        return command;
    }

    static String goToMiddleBottomBorderFromEast()
    {
        String command = (new StringBuilder("fr")).append(generateCommand(99, "f")).append("lbl").append(generateCommand(50, "f")).append("r").toString();
        return command;
    }

    static String goToMiddleBottomBorderFromWest()
    {
        String command = (new StringBuilder("r")).append(generateCommand(50, "f")).append("l").toString();
        return command;
    }

    static String goToMiddleTopBorderFromSouth()
    {
        String command = (new StringBuilder(String.valueOf(goToMiddleBottomBorder()))).append(generateCommand(99, "f")).toString();
        return command;
    }

    static String goToMiddleTopBorderFromEast()
    {
        String command = (new StringBuilder(String.valueOf(goToBottomRightCorner()))).append(generateCommand(99, "f")).append("l").append(generateCommand(50, "f")).append("r").toString();
        return command;
    }

    static String generateObstacleInPosition(int x, int y)
    {
        String obstacle = (new StringBuilder("(")).append(x).append(",").append(y).append(")").toString();
        return obstacle;
    }

    static String goToMiddleBottomBorder()
    {
        String command = (new StringBuilder("r")).append(generateCommand(50, "f")).append("l").toString();
        return command;
    }

    static String goToMiddleRightBorderFromWest()
    {
        String command = (new StringBuilder(String.valueOf(generateCommand(50, "f")))).append("r").append(generateCommand(99, "f")).append("l").toString();
        return command;
    }

    static String goToMiddleRightBorderFromNorth()
    {
        String command = (new StringBuilder(String.valueOf(goToTopRightCorner()))).append("rr").append(generateCommand(50, "f")).append("ll").toString();
        return command;
    }

    static String goToMiddleRightBorderFromSouth()
    {
        String command = (new StringBuilder(String.valueOf(goToBottomRightCorner()))).append(generateCommand(50, "f")).toString();
        return command;
    }

    static String goToBottomRightCorner()
    {
        String command = (new StringBuilder("r")).append(generateCommand(99, "f")).append("l").toString();
        return command;
    }

    static String goToTopLeftCornerFromSouth()
    {
        String command = generateCommand(99, "f");
        return command;
    }

    static String goToTopRightCorner()
    {
        String command = (new StringBuilder(String.valueOf(generateCommand(99, "f")))).append("r").append(generateCommand(99, "f")).append("l").toString();
        return command;
    }

    static String goToMiddleOfPlanetFromWest()
    {
        String command = (new StringBuilder(String.valueOf(generateCommand(50, "f")))).append("r").append(generateCommand(50, "f")).toString();
        return command;
    }

    static String generateCommand(int times, String symbol)
    {
        String command = "";
        for(int i = 0; i < times; i++)
            command = (new StringBuilder(String.valueOf(command))).append(symbol).toString();

        return command;
    }

    static String goToMiddleLeftBorderCommandFromSouth()
    {
        String command = generateCommand(50, "f");
        return command;
    }

    static String goToMiddleLeftBorderCommandFromSouthBackwards()
    {
        String command = (new StringBuilder("rr")).append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleLeftBorderCommandNorth()
    {
        String command = (new StringBuilder("rfl")).append(generateCommand(99, "f")).append("lfl").append(generateCommand(50, "f")).append("rr").toString();
        return command;
    }

    static String goToMiddleLeftBorderCommandNorthBackwards()
    {
        String command = (new StringBuilder("rfl")).append(generateCommand(99, "f")).append("lfr").append(generateCommand(50, "b")).toString();
        return command;
    }

    static String goToMiddleLeftBorderCommandFromEast()
    {
        String command = (new StringBuilder("rfl")).append(generateCommand(50, "f")).append("lfr").toString();
        return command;
    }
}