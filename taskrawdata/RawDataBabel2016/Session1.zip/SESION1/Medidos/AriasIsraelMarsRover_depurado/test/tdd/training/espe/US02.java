package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class US02
{

    public US02()
    {
    }
    @Before
    public void setUp()
    {
        rover = new MarsRover(100, 100, "");
    }

    @Test
    public void theRoverMovesForwardOnceLanding()
    {
        try
        {
            MatcherAssert.assertThat("(0,1,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,2,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverMovesBackwardsnceLanding()
    {
        rover.executeCommand("f");
        MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("b"))));
    }

    @Test
    public void theRoverShouldChangeFacingTWhenGivenATurnCommandAfterLanding()
    {
        try
        {
            MatcherAssert.assertThat("(0,0,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("l"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,0,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("rr"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverFacesSouthAfterLandingAndExecutingATurnCommandToTimesInARow()
    {
        try
        {
            MatcherAssert.assertThat("(0,0,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("rr"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("ll"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverFacesWestAfterLandingAndExecutingALeftCommandThreeTimesInARow()
    {
        MatcherAssert.assertThat("(0,0,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("lll"))));
    }

    @Test
    public void theRoverFacesEastAfterLandingAndExecutingARightCommandThreeTimesInARow()
    {
        MatcherAssert.assertThat("(0,0,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("rrr"))));
    }
    
    @Test
    public void theRoverIsFacingTheSameDirectionAfterExecutingFourTimesTheSameTurnCommand()
    {
        try
        {
            MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("llll"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,0,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("rrrr"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    MarsRover rover;
}