package tdd.training.espe;


import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class US03
{

    public US03()
    {
    }

    @Before
    public void startUp()
    {
        rover = new MarsRover(100, 100, "");
    }

    @Test
    public void theRoverMovesForwardNorthBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        try
        {
            MatcherAssert.assertThat("(0,10,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand(command))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,11,N)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverMovesForwardSouthBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("ll");
        try
        {
            MatcherAssert.assertThat("(0,5,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("fffff"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(0,4,S)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }
    
    @Test
    public void theRoverMovesForwardWestBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("r");
        rover.executeCommand("fffff");
        rover.executeCommand("ll");
        try
        {
            MatcherAssert.assertThat("(3,10,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("ff"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(2,10,W)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

    @Test
    public void theRoverMovesForwardEastBoundedOnceLanding()
    {
        String command = generateCommand(10, "f");
        rover.executeCommand(command);
        rover.executeCommand("r");
        rover.executeCommand("fffff");
        try
        {
            MatcherAssert.assertThat("(10,10,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("fffff"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
        try
        {
            MatcherAssert.assertThat("(11,10,E)", Matchers.is(Matchers.equalToIgnoringCase(rover.executeCommand("f"))));
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
    }

   
    private String generateCommand(int times, String symbol)
    {
        String command = "";
        for(int i = 0; i < times; i++)
            command = (new StringBuilder(String.valueOf(command))).append(symbol).toString();

        return command;
    }

    MarsRover rover;
}