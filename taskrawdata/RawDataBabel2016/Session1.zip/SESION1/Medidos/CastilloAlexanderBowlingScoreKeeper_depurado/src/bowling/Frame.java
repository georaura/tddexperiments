package bowling;

public class Frame {

	 public int thorow1;
	 public int thorow2;
    
    public Frame() {
	}

   public Frame(int i, int j) {
   	this.thorow1=i;
   	this.thorow2=j;
	}
   
   public int score() {
       return (this.thorow1+this.thorow2);
   }

	public int getThrow1() {
		return this.thorow1;
	}

	public int getThrow2() {
		return this.thorow2;
	}
}