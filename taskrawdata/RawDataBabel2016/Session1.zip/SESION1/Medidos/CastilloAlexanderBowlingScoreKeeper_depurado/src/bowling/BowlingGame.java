package bowling;
import java.util.ArrayList;
import java.util.List;


public class BowlingGame {
	
	public final List<Frame> List_frames;
	public int frameCounter;
     private static final int MAX_FRAMES = 10;
     private static final int MAX_PINS = 10;

    public BowlingGame() {
    	List_frames = new ArrayList<Frame>(MAX_FRAMES);
        this.frameCounter=-1;
    } 

    public void setBonus(int firstThrow, int secondThrow) {
    	this.frameCounter++;
    	if(!isGameFinished()){
    		this.addFrame(new Frame(firstThrow, secondThrow)); 
    	}
    }

    public int score() {
    	int total_points=0;
    	 for (int i = 0; i < this.List_frames.size(); i++) {
             total_points=total_points+this.List_frames.get(i).score();
         }
        return total_points;
    }

    public boolean isNextFrameBonus() {
    	if(this.List_frames.get(this.frameCounter-1).getThrow1()==this.MAX_PINS){ 		
    		return true;
    	}else{
    		if(this.List_frames.get(this.frameCounter-1).score()==this.MAX_PINS){ 		
    		return true;
    		}}
        return false;
    }

    public boolean isGameFinished() {
    	if(this.frameCounter==this.MAX_FRAMES){
    		return true;
    	}
        return false;
    }

	public void addFrame(Frame frame) {
		this.List_frames.add(frame);	
	}
}
