package bowlingacceptancetest;
import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;




public class US07 {

	@Test
	public void testSpareAfterStrikeAtTheBeginningForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(1,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
	
		try
        {
			assertEquals(70, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	@Test
	public void testSpareAfterStrikeAtTheBeginningContent() throws Exception  {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(0,10));
		game.addFrame(new Frame(1,2));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
	
		try
        {
			assertEquals(72, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareAfterStrikeInTheMiddleForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(4,5));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(3,7));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(99, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareAfterStrikeInTheMiddleContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(3,5));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(2,5));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(92, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareAfterStrikeInTheMiddleZeroBoniForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(1,5));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));

		try
        {
			assertEquals(55, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareAfterStrikeInTheMiddleZeroBoniContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(1,5));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(1,4));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));

		try
        {
			assertEquals(60, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }


	}
	@Test
	public void testSpareAfterStrikeAtTheBeginningZeroBoniContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		try
        {
			assertEquals(68, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}

	@Test
	public void testDoubleStrikeDoubleSpareForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(0,10));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(91, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	
	public void testStrikeAfterSpareAtTheBeginningForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(70, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}

	public void testStrikeAfterSpareAtTheBeginningContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(0,10));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,2));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(74, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	
	public void testStrikeAfterSpareInTheMiddleForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(4,5));
		game.addFrame(new Frame(2,4));
		game.addFrame(new Frame(3,7));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(2,6));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(85, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	
	public void testStrikeAfterSpareInTheMiddleContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(5,1));
		game.addFrame(new Frame(7,2));
		game.addFrame(new Frame(1,7));
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));

		try
        {
			assertEquals(82, game.score());      
		}
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }


	}

	public void testStrikeAfterSpareAtTheBeginningZeroBoniContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(68, game.score());
		}
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}

	public void testStrikeAfterSpareAtTheBeginningZeroBoniForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(68, game.score());
		}
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
		
	}
	
	public void testDoubleSpareDoubleStrikeForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(89, game.score());
		}
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}

	public void testDoubleSpareDoubleStrikeContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(1,9));
		game.addFrame(new Frame(2,8));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(10,0));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		try
        {
			assertEquals(95, game.score());
		}
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}


}
