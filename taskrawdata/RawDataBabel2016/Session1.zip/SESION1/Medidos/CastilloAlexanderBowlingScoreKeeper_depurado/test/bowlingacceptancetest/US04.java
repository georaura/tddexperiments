package bowlingacceptancetest;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;





public class US04 {

	@Test
	public void testAddFrame() throws Exception  {
		BowlingGame game = new BowlingGame();
		Frame frame1 = new Frame(1, 0);
		game.addFrame(frame1);
		
		Frame frameTest = new Frame(frame1.getThrow1(), frame1.getThrow2());
		try
        {
			assertEquals(frame1.getThrow1(), frameTest.getThrow1());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		try
        {
			assertEquals(frame1.getThrow2(), frameTest.getThrow2());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
		
		
	}

	@Test
	public void testGetFrame() throws Exception {
		BowlingGame game = new BowlingGame();
		Frame frame1 = new Frame(1, 2);
		Frame frame2 = new Frame(5, 4);
		Frame frame3 = new Frame(4, 3);
		game.addFrame(frame1);
		game.addFrame(frame2);
		game.addFrame(frame3);
		try
        {
			assertEquals(frame1.getThrow1(), new Frame(frame1.getThrow1(), frame1.getThrow2()).getThrow1());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		try
        {
			assertEquals(frame1.getThrow2(), new Frame(frame1.getThrow1(), frame1.getThrow2()).getThrow2());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		try
        {
			assertEquals(frame2.getThrow1(), new Frame(frame2.getThrow1(), frame2.getThrow2()).getThrow1());
			
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
		try
        {
			assertEquals(frame2.getThrow2(), new Frame(frame2.getThrow1(), frame2.getThrow2()).getThrow2());
				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		try
        {
			assertEquals(frame3.getThrow1(), new Frame(frame3.getThrow1(), frame3.getThrow2()).getThrow1());
				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		try
        {
			assertEquals(frame3.getThrow2(), new Frame(frame3.getThrow1(), frame3.getThrow2()).getThrow2());
				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		
		
		
	}
	
	// Commented by Oscar
	// No reason for the try-catch block. I'd remove it
	@Test
	public void testGameScore() throws Exception{
		BowlingGame game = new BowlingGame();
		
		try {
			game.addFrame(new Frame(1, 2));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		assertEquals(3, game.score());
		
		game.addFrame(new Frame(2, 3));
		try
        {
			assertEquals(8, game.score());
						
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		game.addFrame(new Frame(5, 4));
		try
        {
			assertEquals(17, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	

}
