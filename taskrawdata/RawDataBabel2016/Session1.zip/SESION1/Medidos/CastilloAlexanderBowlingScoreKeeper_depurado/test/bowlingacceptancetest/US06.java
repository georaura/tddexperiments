package bowlingacceptancetest;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import bowling.BowlingGame;
import bowling.Frame;



public class US06 {

	@Test
	public void testStartWithASpareForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(5,5));
		game.addFrame(new Frame(2,5));
		game.addFrame(new Frame(1,1));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(59, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
		
	}
	@Test
	public void testStartWithASpareContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(4,6));
		game.addFrame(new Frame(2,5));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(57, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
	
	}
	@Test
	public void testSpareWithFirstThrowZeroForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(0,10));
		game.addFrame(new Frame(2,4));
		game.addFrame(new Frame(5,5));
		game.addFrame(new Frame(1,8));
		game.addFrame(new Frame(0,5));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(67, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareInTheMiddleForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(4,5));
		game.addFrame(new Frame(2,4));
		game.addFrame(new Frame(5,5));
		game.addFrame(new Frame(1,8));
		game.addFrame(new Frame(0,5));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
	
		try
        {
			assertEquals(64, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}
	@Test
	public void testSpareInTheMiddleContent() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(5,1));
		game.addFrame(new Frame(7,2));
		game.addFrame(new Frame(0,10));
		game.addFrame(new Frame(0,1));
		game.addFrame(new Frame(0,5));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(55, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}

	@Test
	public void testSingleSpareZeroBonusForm() throws Exception   {
		BowlingGame game = new BowlingGame();
		game.addFrame(new Frame(5,5));
		game.addFrame(new Frame(0,0));
		game.addFrame(new Frame(1,1));
		game.addFrame(new Frame(4,2));
		game.addFrame(new Frame(8,0));
		game.addFrame(new Frame(2,3));
		game.addFrame(new Frame(1,3));
		game.addFrame(new Frame(1,6));
		game.addFrame(new Frame(2,0));
		game.addFrame(new Frame(5,1));
		
		try
        {
			assertEquals(50, game.score());				
        }
        catch(Exception e)
        {
            Assert.fail((new StringBuilder("We were not expecting an exception: ")).append(e.toString()).toString(), true);
        }
		
	}



}
