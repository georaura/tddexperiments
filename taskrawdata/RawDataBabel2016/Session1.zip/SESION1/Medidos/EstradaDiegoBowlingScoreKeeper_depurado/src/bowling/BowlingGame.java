package bowling;
import java.awt.List;
import java.util.Random;

public class BowlingGame {
	int acumulado=0;
	Frame actualFrame;
	List frames=new List();
	int contadorFrames=0;
	int firstThrow=0;
	int secondThrow=0;
	//geoaura@gmail.com
	
	Random rand = new Random();

    public BowlingGame() {
    	// to be implemented
    	//tiro 1 y 2
    	//fue bono? si->establezco tipoBonus,  no->
    	//sumo 1 a cantidadFramesJugados
    	//acumulo de acuerdo al bono
    	
    	////tiro 1 y 2  veo si debo acumular bono, si->almaceno bono y score y agrego frame, seteo t1 y t2, seteo tipobono
    	
    	//haybono?si->acumulo,tipoBono=0, no->xx
    	//fue bono? si->establezco tipoBonus,.. no->
    	// sumo 1 a cantidadFramesJugados
    	//acumulo de acuerdo al bono
    	
    	
    	while(!isGameFinished() && contadorFrames<=10)
    	{
	    	if(actualFrame==null){
	    		actualFrame=new Frame();
	    	}
	    	
	    	firstThrow=rand.nextInt(10)+1;
	    	secondThrow=rand.nextInt(10)+1;//tiro 1 y 2 
	    	
	    	if(actualFrame.tipoBonus>0){//veo si debo acumular bono
	    		setBonus(firstThrow, secondThrow);
	    	}
	    	
	    	if(isNextFrameBonus()){
	    		establecerTipoBono(actualFrame);
	    	}
    	
	    	contadorFrames++;
    	}
    	
    } 
    
    public int establecerTipoBono(Frame frame)
    {
    	if (frame.getThrow1()==10)
    		return frame.tipoBonus=2;
    	else if(frame.getThrow1()+frame.getThrow2()==10)
    		return frame.tipoBonus=1;
    	else return frame.tipoBonus=0;
    }

    public void setBonus(int firstThrow, int secondThrow) {//si->almaceno bono y score y agrego frame
        // to be implemented
    	switch (actualFrame.tipoBonus) {
		case 1:
			actualFrame.scoreFrame+=firstThrow;
			break;
		case 2:
			actualFrame.scoreFrame+=(firstThrow+secondThrow);
			break;

		default:
			break;
		}
    	
    	actualFrame.score();
    	addFrame(actualFrame=new Frame());
    }

    public int score() {
    	// to be implemented
        return 0;
    }

    public boolean isNextFrameBonus() {
        // to be implemented
    	return (actualFrame.Throw1==10||actualFrame.getThrow1()+actualFrame.getThrow2()==10);
    }

    public boolean isGameFinished() {
    	// to be implemented
    	
        return false;
    }

	public void addFrame(Frame frame) {
		// to be implemented
		frame.Throw1=firstThrow;
    	frame.Throw2=secondThrow;	
	}
}
